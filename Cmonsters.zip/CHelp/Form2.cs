﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CHelp
{
    public partial class Main : Form
    {
        ///connects to database
        /// ///////////
        
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;
        string con = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22U45;User ID=ISYS4283SP22U45;password=GohogsUA1";
        private object objMain;

        public Main()
        {
            InitializeComponent();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you Sure you want to Logout?", "System Message", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dialogResult == DialogResult.Yes)
            {

                Form F3 = new Form1();
                F3.ShowDialog();





            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }

        private void btnexit2_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you Sure you want to Exit?", "System Message", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet4.student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.dataSet4.student);
            // TODO: This line of code loads data into the 'dataSet3.Course' table. You can move, or remove it, as needed.
            this.courseTableAdapter.Fill(this.dataSet3.Course);
            // TODO: This line of code loads data into the 'dataSet2.instructor' table. You can move, or remove it, as needed.
            this.instructorTableAdapter.Fill(this.dataSet2.instructor);
            // TODO: This line of code loads data into the 'dataSet1.enroll' table. You can move, or remove it, as needed.
            this.enrollTableAdapter.Fill(this.dataSet1.enroll);
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT studentid FROM student";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                cbosid.Items.Add(datareader[0].ToString());
            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ////////////
            ///course cbo
            connection = new SqlConnection(con);
            connection.Open();
            string sql2 = "SELECT courseid FROM course";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                cbocourse.Items.Add(datareader[0].ToString());
            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ///////////
            ///cbo instructor
            connection = new SqlConnection(con);
            connection.Open();
            string sql3 = "SELECT instructorid FROM instructor";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                cboinstructor.Items.Add(datareader[0].ToString());
            }
            connection.Close();
            datareader.Close();
            command.Dispose();
        }

        private void cbosid_SelectedIndexChanged(object sender, EventArgs e)
        {
            //////////
            ///////cbo box 
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT lastname, firstname, gender, dataofbirth, initialregistrationdate FROM Student where studentid = '" + cbosid.SelectedItem.ToString()+"'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtlast.Text = datareader[0].ToString();
                txtfirst.Text = datareader[1].ToString();
                txtgender.Text = datareader[2].ToString();
                txtdate.Text = datareader[4].ToString();
                txtdob.Text = datareader[3].ToString();

            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ///////
            ///dgv
            connection = new SqlConnection(con);
            connection.Open();
            string sql2 = "Select * from Student S INNER JOIN enroll E  ON S.studentid = E.studentid INNER JOIN course C ON C.courseid = E.courseid WHERE S.studentid = '" + cbosid.SelectedItem.ToString() + "'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvstudent.DataSource = ds.Tables[0];
            connection.Close();
            datareader.Close();
            command.Dispose();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            /////fuzzy search txt
            /////////////
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT lastname, firstname, gender, dataofbirth, initialregistrationdate FROM student where studentid LIKE '%" + textBox1.Text + "%'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtlast.Text = datareader[0].ToString();
                txtfirst.Text = datareader[1].ToString();
                txtgender.Text = datareader[2].ToString();
                txtdate.Text = datareader[4].ToString();
                txtdob.Text = datareader[3].ToString();

            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ///////
            ///Dgv student connection
            connection = new SqlConnection(con);
            connection.Open();
            string sql2 = "Select * from Student S INNER JOIN enroll E  ON S.studentid = E.studentid INNER JOIN course C ON C.courseid = E.courseid WHERE S.studentid = '" + cbosid.SelectedItem.ToString() + "'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvstudent.DataSource = ds.Tables[0];
            connection.Close();
            datareader.Close();
            command.Dispose();
            ////////
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            ////////// insert button
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "INSERT into Student VALUES (@LName, @FName, @Gender, @DOB, @Date)";
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@LName", txtlast.Text);
            command.Parameters.AddWithValue("@FName", txtfirst.Text);
            command.Parameters.AddWithValue("@Gender", txtgender.Text);
            command.Parameters.AddWithValue("@DOB", txtdob.Text);
            command.Parameters.AddWithValue("@Date", txtdate.Text);

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully done it", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ////////// update student button
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "UPDATE Student Set lastname= @LName, firstname= @FName, gender= @Gender, dataofbirth= @DOB, initialregistrationdate= @Date WHERE studentid = @sid";
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@LName", txtlast.Text);
            command.Parameters.AddWithValue("@FName", txtfirst.Text);
            command.Parameters.AddWithValue("@Gender", txtgender.Text);
            command.Parameters.AddWithValue("@DOB", txtdob.Text);
            command.Parameters.AddWithValue("@Date", txtdate.Text);
            command.Parameters.AddWithValue("sid", cbosid.SelectedItem.ToString());

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully updated", "congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "DELETE FROM Student WHERE studentid = @sid";
            command = new SqlCommand(sql, connection);

            command.Parameters.AddWithValue("sid", cbosid.SelectedItem.ToString());

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully Deleted an item", "congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void cbocourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            ///////cbo box 
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT course_name, course_description, instructorid FROM course WHERE courseid = '" + cbocourse.SelectedItem.ToString() + "'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtname.Text = datareader[0].ToString();
                txtdesc.Text = datareader[1].ToString();
                txttid.Text = datareader[2].ToString();
               

            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            //////////
            ///course dgv
            connection = new SqlConnection(con);
            connection.Open();
            string sql2 = "Select * from Student S INNER JOIN enroll E  ON S.studentid = E.studentid INNER JOIN course C ON C.courseid = E.courseid WHERE S.studentid = '" + cbosid.SelectedItem.ToString() + "'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvclass.DataSource = ds.Tables[0];
            connection.Close();
            datareader.Close();
            command.Dispose();
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            /////fuzzy search txt
            /////////////
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT course_name, course_description, instructorid, FROM Course where courseid LIKE '%" + textBox12.Text + "%'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtname.Text = datareader[0].ToString();
                txtdesc.Text = datareader[1].ToString();
                txttid.Text = datareader[2].ToString();
           

            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ///////
            ///Dgv student connection
            connection = new SqlConnection(con);
            connection.Open();
            string sql2 = "Select *from Student S INNER JOIN enroll E  ON S.studentid = E.studentid INNER JOIN course C ON C.courseid = E.courseid WHERE S.studentid = '" + cbosid.SelectedItem.ToString() + "'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvstudent.DataSource = ds.Tables[0];
            connection.Close();
            datareader.Close();
            command.Dispose();
            ////////
        }

        private void btnin_Click(object sender, EventArgs e)
        {
            ////////// insert button
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "INSERT into Course VALUES (@Name, @des, @tid)";
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@Name", txtname.Text);
            command.Parameters.AddWithValue("@des", txtdesc.Text);
            command.Parameters.AddWithValue("@tid", txttid.Text);

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully done it", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btnup_Click(object sender, EventArgs e)
        {
            ////////// update student button
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "UPDATE course Set course_name= @Name, course_description = @des, instructorid = @tid WHERE courseid = @cid";
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@name", txtname.Text);
            command.Parameters.AddWithValue("@des", txtdesc.Text);
            command.Parameters.AddWithValue("@tid", txttid.Text);
            command.Parameters.AddWithValue("@cid", cbocourse.SelectedItem.ToString());
            

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully updated", "congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "DELETE FROM course WHERE courseid = @cid";
            command = new SqlCommand(sql, connection);

            command.Parameters.AddWithValue("cid", cbocourse.SelectedItem.ToString());

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully Deleted an item", "congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void cboinstructor_SelectedIndexChanged(object sender, EventArgs e)
        {
            ///////cbo box 
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT lastname, firstname, gender, dateofhire FROM instructor WHERE instructorid = '" + cboinstructor.SelectedItem.ToString() + "'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtilast.Text = datareader[0].ToString();
                txtifirst.Text = datareader[1].ToString();
                txtigen.Text = datareader[2].ToString();
                txthire.Text = datareader[3].ToString();


            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            //////////
            ///instructor dgv
            connection = new SqlConnection(con);
            connection.Open();
            string sql2 = "Select * from Student S INNER JOIN enroll E  ON S.studentid = E.studentid INNER JOIN course C ON C.courseid = E.courseid WHERE S.studentid = '" + cboinstructor.SelectedItem.ToString() + "'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvclass.DataSource = ds.Tables[0];
            connection.Close();
            datareader.Close();
            command.Dispose();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ////////// insert button
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "INSERT into Instructor VALUES (@LastName, @FirstName, @Gender, @dateofhire)";
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@LastName", txtilast.Text);
            command.Parameters.AddWithValue("@FirstName", txtifirst.Text);
            command.Parameters.AddWithValue("@Gender", txtigen.Text);
            command.Parameters.AddWithValue("@dateofhire", txthire.Text);

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully done it", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btnu_Click(object sender, EventArgs e)
        {
            ////////// update student button
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "UPDATE instructor Set lastname= @LastName, firstname = @FirstName, Gender = @Gender, dateofhire = @dateofhire WHERE instructorid = @Iid";
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@LastName", txtilast.Text);
            command.Parameters.AddWithValue("@FirstName", txtifirst.Text);
            command.Parameters.AddWithValue("@Gender", txtigen.Text);
            command.Parameters.AddWithValue("@dateofhire", txthire.Text);
            command.Parameters.AddWithValue("@Iid", cboinstructor.SelectedItem.ToString());


            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully updated", "congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "DELETE FROM instructor WHERE instructorid = @Iid";
            command = new SqlCommand(sql, connection);

            command.Parameters.AddWithValue("Iid", cboinstructor.SelectedItem.ToString());

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully Deleted an item", "congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void cboenroll_SelectedIndexChanged(object sender, EventArgs e)
        {
            ///////cbo box 
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT enrolldate, class_startdate, class_enddate, numberofcredits, studentid, courseid FROM enrollid WHERE enrollid = '" + cboenroll.SelectedItem.ToString() + "'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtedate.Text = datareader[0].ToString();
                txtstart.Text = datareader[1].ToString();
                txtend.Text = datareader[2].ToString();
                txtcredits.Text = datareader[3].ToString();
                txtstuid.Text = datareader[4].ToString();
                txtcouid.Text = datareader[5].ToString();


            }
            connection.Close();
            datareader.Close();
            command.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ////////// insert button
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "INSERT into enroll VALUES (@enrolldate, @class_startdate, @class_enddate, @numberofcredits, @studentid, @courseid)";
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@enrolldate", txtedate.Text);
            command.Parameters.AddWithValue("@class_startdate", txtstart.Text);
            command.Parameters.AddWithValue("@class_enddate", txtend.Text);
            command.Parameters.AddWithValue("@numberofcredits", txtcredits.Text);
            command.Parameters.AddWithValue("@studentid", txtstuid.Text);
            command.Parameters.AddWithValue("@coursid", txtcouid.Text);

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully done it", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ////////// update student button
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "UPDATE instructor Set enrolldate= @enrolldate, class_startdate = @class_startdate, class_enddate = @class_enddate, numberofcredits = @ numberofcredits, studentid = @studentid, courseid = @courseid WHERE enrollid = @Eid";
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@enrolldate", txtedate.Text);
            command.Parameters.AddWithValue("@class_startdate", txtstart.Text);
            command.Parameters.AddWithValue("@Class_enddate", txtend.Text);
            command.Parameters.AddWithValue("@numberofcredits", txtcredits.Text);
            command.Parameters.AddWithValue("@studentid", txtstuid.Text);
            command.Parameters.AddWithValue("@couid", txtcouid.Text);
            command.Parameters.AddWithValue("@Eid", cboenroll.SelectedItem.ToString());


            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully updated", "congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(con);
            connection.Open();
            int answer;
            string sql = "DELETE FROM enroll WHERE enrollid = @Eid";
            command = new SqlCommand(sql, connection);

            command.Parameters.AddWithValue("Eid", cboenroll.SelectedItem.ToString());

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("You have successfully Deleted an item", "congrats", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {
            /////fuzzy search txt
            /////////////
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT lastname, firstname, gender, dateofhire, FROM instructor where instructorid LIKE '%" + textBox18.Text + "%'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtilast.Text = datareader[0].ToString();
                txtifirst.Text = datareader[1].ToString();
                txtigen.Text = datareader[2].ToString();
                txthire.Text = datareader[3].ToString();
                


            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ///////
            ///Dgv student connection
            connection = new SqlConnection(con);
            connection.Open();
            string sql2 = "Select *from Student S INNER JOIN enroll E  ON S.studentid = E.studentid INNER JOIN course C ON C.courseid = E.courseid WHERE S.studentid = '" + cbosid.SelectedItem.ToString() + "'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvstudent.DataSource = ds.Tables[0];
            connection.Close();
            datareader.Close();
            command.Dispose();
            ////////
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            /////fuzzy search txt
            /////////////
            connection = new SqlConnection(con);
            connection.Open();
            string sql = "SELECT enrolldate, class_startdate, class_enddate, numberofcredits, studentid, courseid, FROM enroll where enrollid LIKE '%" + textBox7.Text + "%'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtedate.Text = datareader[0].ToString();
                txtstart.Text = datareader[1].ToString();
                txtend.Text = datareader[2].ToString();
                txtcredits.Text = datareader[3].ToString();
                txtstuid.Text = datareader[4].ToString();
                txtcouid.Text = datareader[5].ToString();


            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ///////
            ///Dgv student connection
            connection = new SqlConnection(con);
            connection.Open();
            string sql2 = "Select *from Student S INNER JOIN enroll E  ON S.studentid = E.studentid INNER JOIN course C ON C.courseid = E.courseid WHERE S.studentid = '" + cbosid.SelectedItem.ToString() + "'";
            var da = new SqlDataAdapter(sql2, connection);
            var ds = new DataSet();
            da.Fill(ds);
            dgvstudent.DataSource = ds.Tables[0];
            connection.Close();
            datareader.Close();
            command.Dispose();
            ////////
        }
    }
    }
    

