﻿
namespace CHelp
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.btnlogout = new System.Windows.Forms.Button();
            this.btnexit2 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btninsert = new System.Windows.Forms.Button();
            this.txtdate = new System.Windows.Forms.TextBox();
            this.txtdob = new System.Windows.Forms.TextBox();
            this.txtgender = new System.Windows.Forms.TextBox();
            this.txtfirst = new System.Windows.Forms.TextBox();
            this.txtlast = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cbosid = new System.Windows.Forms.ComboBox();
            this.dgvstudent = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btndel = new System.Windows.Forms.Button();
            this.btnup = new System.Windows.Forms.Button();
            this.btnin = new System.Windows.Forms.Button();
            this.txttid = new System.Windows.Forms.TextBox();
            this.txtdesc = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.cbocourse = new System.Windows.Forms.ComboBox();
            this.dgvclass = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.btnu = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.txthire = new System.Windows.Forms.TextBox();
            this.txtigen = new System.Windows.Forms.TextBox();
            this.txtifirst = new System.Windows.Forms.TextBox();
            this.txtilast = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.cboinstructor = new System.Windows.Forms.ComboBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtstuid = new System.Windows.Forms.TextBox();
            this.txtcredits = new System.Windows.Forms.TextBox();
            this.txtend = new System.Windows.Forms.TextBox();
            this.txtstart = new System.Windows.Forms.TextBox();
            this.txtedate = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.cboenroll = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataSet1 = new CHelp.DataSet1();
            this.enrollBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.enrollTableAdapter = new CHelp.DataSet1TableAdapters.enrollTableAdapter();
            this.enrollidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.enrolldateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classstartdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classenddateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberofcreditsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtcouid = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.dataSet2 = new CHelp.DataSet2();
            this.instructorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.instructorTableAdapter = new CHelp.DataSet2TableAdapters.instructorTableAdapter();
            this.instructoridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateofhireDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataSet3 = new CHelp.DataSet3();
            this.courseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.courseTableAdapter = new CHelp.DataSet3TableAdapters.CourseTableAdapter();
            this.courseidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coursenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coursedescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.instructoridDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataSet4 = new CHelp.DataSet4();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentTableAdapter = new CHelp.DataSet4TableAdapters.studentTableAdapter();
            this.studentidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataofbirthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.initialregistrationdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label23 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvstudent)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvclass)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enrollBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // btnlogout
            // 
            this.btnlogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.Location = new System.Drawing.Point(222, 880);
            this.btnlogout.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(150, 67);
            this.btnlogout.TabIndex = 5;
            this.btnlogout.Text = "Logout";
            this.btnlogout.UseVisualStyleBackColor = true;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // btnexit2
            // 
            this.btnexit2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit2.Location = new System.Drawing.Point(27, 880);
            this.btnexit2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnexit2.Name = "btnexit2";
            this.btnexit2.Size = new System.Drawing.Size(158, 67);
            this.btnexit2.TabIndex = 4;
            this.btnexit2.Text = "Exit";
            this.btnexit2.UseVisualStyleBackColor = true;
            this.btnexit2.Click += new System.EventHandler(this.btnexit2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 13);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(2449, 857);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.btndelete);
            this.tabPage1.Controls.Add(this.btnupdate);
            this.tabPage1.Controls.Add(this.btninsert);
            this.tabPage1.Controls.Add(this.txtdate);
            this.tabPage1.Controls.Add(this.txtdob);
            this.tabPage1.Controls.Add(this.txtgender);
            this.tabPage1.Controls.Add(this.txtfirst);
            this.tabPage1.Controls.Add(this.txtlast);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.cbosid);
            this.tabPage1.Controls.Add(this.dgvstudent);
            this.tabPage1.Location = new System.Drawing.Point(8, 39);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(2433, 810);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Student";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(40, 431);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(194, 42);
            this.label9.TabIndex = 15;
            this.label9.Text = "Registration";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(40, 365);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(171, 42);
            this.label8.TabIndex = 14;
            this.label8.Text = "Birth Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(40, 310);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 42);
            this.label7.TabIndex = 13;
            this.label7.Text = "Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(40, 252);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(179, 42);
            this.label6.TabIndex = 12;
            this.label6.Text = "First Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(40, 194);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 42);
            this.label5.TabIndex = 11;
            this.label5.Text = "Last Name";
            // 
            // btndelete
            // 
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.Location = new System.Drawing.Point(388, 537);
            this.btndelete.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(158, 67);
            this.btndelete.TabIndex = 10;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(216, 537);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(158, 67);
            this.btnupdate.TabIndex = 9;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btninsert
            // 
            this.btninsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninsert.Location = new System.Drawing.Point(48, 537);
            this.btninsert.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(158, 67);
            this.btninsert.TabIndex = 7;
            this.btninsert.Text = "Insert";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // txtdate
            // 
            this.txtdate.Location = new System.Drawing.Point(284, 440);
            this.txtdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(178, 31);
            this.txtdate.TabIndex = 8;
            // 
            // txtdob
            // 
            this.txtdob.Location = new System.Drawing.Point(284, 383);
            this.txtdob.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtdob.Name = "txtdob";
            this.txtdob.Size = new System.Drawing.Size(178, 31);
            this.txtdob.TabIndex = 7;
            // 
            // txtgender
            // 
            this.txtgender.Location = new System.Drawing.Point(284, 319);
            this.txtgender.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtgender.Name = "txtgender";
            this.txtgender.Size = new System.Drawing.Size(178, 31);
            this.txtgender.TabIndex = 6;
            // 
            // txtfirst
            // 
            this.txtfirst.Location = new System.Drawing.Point(284, 262);
            this.txtfirst.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtfirst.Name = "txtfirst";
            this.txtfirst.Size = new System.Drawing.Size(178, 31);
            this.txtfirst.TabIndex = 5;
            // 
            // txtlast
            // 
            this.txtlast.Location = new System.Drawing.Point(284, 206);
            this.txtlast.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtlast.Name = "txtlast";
            this.txtlast.Size = new System.Drawing.Size(178, 31);
            this.txtlast.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(391, 49);
            this.label1.TabIndex = 3;
            this.label1.Text = "Search for a student";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(228, 96);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(178, 31);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // cbosid
            // 
            this.cbosid.FormattingEnabled = true;
            this.cbosid.Location = new System.Drawing.Point(36, 96);
            this.cbosid.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbosid.Name = "cbosid";
            this.cbosid.Size = new System.Drawing.Size(144, 33);
            this.cbosid.TabIndex = 1;
            this.cbosid.SelectedIndexChanged += new System.EventHandler(this.cbosid_SelectedIndexChanged);
            // 
            // dgvstudent
            // 
            this.dgvstudent.AutoGenerateColumns = false;
            this.dgvstudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvstudent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentidDataGridViewTextBoxColumn1,
            this.lastnameDataGridViewTextBoxColumn1,
            this.firstnameDataGridViewTextBoxColumn1,
            this.genderDataGridViewTextBoxColumn1,
            this.dataofbirthDataGridViewTextBoxColumn,
            this.initialregistrationdateDataGridViewTextBoxColumn});
            this.dgvstudent.DataSource = this.studentBindingSource;
            this.dgvstudent.Location = new System.Drawing.Point(492, 0);
            this.dgvstudent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvstudent.Name = "dgvstudent";
            this.dgvstudent.RowHeadersWidth = 82;
            this.dgvstudent.RowTemplate.Height = 33;
            this.dgvstudent.Size = new System.Drawing.Size(1285, 382);
            this.dgvstudent.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.SeaShell;
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.btndel);
            this.tabPage2.Controls.Add(this.btnup);
            this.tabPage2.Controls.Add(this.btnin);
            this.tabPage2.Controls.Add(this.txttid);
            this.tabPage2.Controls.Add(this.txtdesc);
            this.tabPage2.Controls.Add(this.txtname);
            this.tabPage2.Controls.Add(this.textBox12);
            this.tabPage2.Controls.Add(this.cbocourse);
            this.tabPage2.Controls.Add(this.dgvclass);
            this.tabPage2.Location = new System.Drawing.Point(8, 39);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(2433, 810);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Class";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 13);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(374, 49);
            this.label2.TabIndex = 26;
            this.label2.Text = "Search for a course";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(26, 321);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(206, 42);
            this.label12.TabIndex = 25;
            this.label12.Text = "Instructor ID";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(26, 263);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(186, 42);
            this.label13.TabIndex = 24;
            this.label13.Text = "Description";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(26, 206);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(193, 42);
            this.label14.TabIndex = 23;
            this.label14.Text = "Class Name";
            // 
            // btndel
            // 
            this.btndel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndel.Location = new System.Drawing.Point(356, 508);
            this.btndel.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(158, 67);
            this.btndel.TabIndex = 22;
            this.btndel.Text = "Delete";
            this.btndel.UseVisualStyleBackColor = true;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // btnup
            // 
            this.btnup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnup.Location = new System.Drawing.Point(186, 508);
            this.btnup.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnup.Name = "btnup";
            this.btnup.Size = new System.Drawing.Size(158, 67);
            this.btnup.TabIndex = 21;
            this.btnup.Text = "Update";
            this.btnup.UseVisualStyleBackColor = true;
            this.btnup.Click += new System.EventHandler(this.btnup_Click);
            // 
            // btnin
            // 
            this.btnin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnin.Location = new System.Drawing.Point(6, 508);
            this.btnin.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnin.Name = "btnin";
            this.btnin.Size = new System.Drawing.Size(158, 67);
            this.btnin.TabIndex = 18;
            this.btnin.Text = "Insert";
            this.btnin.UseVisualStyleBackColor = true;
            this.btnin.Click += new System.EventHandler(this.btnin_Click);
            // 
            // txttid
            // 
            this.txttid.Location = new System.Drawing.Point(240, 333);
            this.txttid.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttid.Name = "txttid";
            this.txttid.Size = new System.Drawing.Size(178, 31);
            this.txttid.TabIndex = 17;
            // 
            // txtdesc
            // 
            this.txtdesc.Location = new System.Drawing.Point(240, 273);
            this.txtdesc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtdesc.Name = "txtdesc";
            this.txtdesc.Size = new System.Drawing.Size(178, 31);
            this.txtdesc.TabIndex = 16;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(240, 217);
            this.txtname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(178, 31);
            this.txtname.TabIndex = 15;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(240, 100);
            this.textBox12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(178, 31);
            this.textBox12.TabIndex = 13;
            this.textBox12.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // cbocourse
            // 
            this.cbocourse.FormattingEnabled = true;
            this.cbocourse.Location = new System.Drawing.Point(48, 100);
            this.cbocourse.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbocourse.Name = "cbocourse";
            this.cbocourse.Size = new System.Drawing.Size(144, 33);
            this.cbocourse.TabIndex = 12;
            this.cbocourse.SelectedIndexChanged += new System.EventHandler(this.cbocourse_SelectedIndexChanged);
            // 
            // dgvclass
            // 
            this.dgvclass.AutoGenerateColumns = false;
            this.dgvclass.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvclass.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.courseidDataGridViewTextBoxColumn1,
            this.coursenameDataGridViewTextBoxColumn,
            this.coursedescriptionDataGridViewTextBoxColumn,
            this.instructoridDataGridViewTextBoxColumn1});
            this.dgvclass.DataSource = this.courseBindingSource;
            this.dgvclass.Location = new System.Drawing.Point(558, 77);
            this.dgvclass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvclass.Name = "dgvclass";
            this.dgvclass.RowHeadersWidth = 82;
            this.dgvclass.RowTemplate.Height = 33;
            this.dgvclass.Size = new System.Drawing.Size(892, 414);
            this.dgvclass.TabIndex = 11;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.btnu);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.txthire);
            this.tabPage3.Controls.Add(this.txtigen);
            this.tabPage3.Controls.Add(this.txtifirst);
            this.tabPage3.Controls.Add(this.txtilast);
            this.tabPage3.Controls.Add(this.textBox18);
            this.tabPage3.Controls.Add(this.cboinstructor);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(8, 39);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Size = new System.Drawing.Size(2433, 810);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Instructor";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(20, 362);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(160, 42);
            this.label11.TabIndex = 27;
            this.label11.Text = "Hire Date";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(20, 304);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(125, 42);
            this.label15.TabIndex = 26;
            this.label15.Text = "Gender";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(20, 246);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(179, 42);
            this.label16.TabIndex = 25;
            this.label16.Text = "First Name";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(20, 188);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(177, 42);
            this.label17.TabIndex = 24;
            this.label17.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 15);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(438, 49);
            this.label3.TabIndex = 23;
            this.label3.Text = "Search for a instructor";
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(364, 537);
            this.button7.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(158, 67);
            this.button7.TabIndex = 22;
            this.button7.Text = "Delete";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnu
            // 
            this.btnu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnu.Location = new System.Drawing.Point(184, 537);
            this.btnu.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnu.Name = "btnu";
            this.btnu.Size = new System.Drawing.Size(158, 67);
            this.btnu.TabIndex = 21;
            this.btnu.Text = "Update";
            this.btnu.UseVisualStyleBackColor = true;
            this.btnu.Click += new System.EventHandler(this.btnu_Click);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(16, 537);
            this.button9.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(158, 67);
            this.button9.TabIndex = 18;
            this.button9.Text = "Insert";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // txthire
            // 
            this.txthire.Location = new System.Drawing.Point(266, 377);
            this.txthire.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txthire.Name = "txthire";
            this.txthire.Size = new System.Drawing.Size(178, 31);
            this.txthire.TabIndex = 19;
            // 
            // txtigen
            // 
            this.txtigen.Location = new System.Drawing.Point(266, 313);
            this.txtigen.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtigen.Name = "txtigen";
            this.txtigen.Size = new System.Drawing.Size(178, 31);
            this.txtigen.TabIndex = 17;
            // 
            // txtifirst
            // 
            this.txtifirst.Location = new System.Drawing.Point(266, 256);
            this.txtifirst.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtifirst.Name = "txtifirst";
            this.txtifirst.Size = new System.Drawing.Size(178, 31);
            this.txtifirst.TabIndex = 16;
            // 
            // txtilast
            // 
            this.txtilast.Location = new System.Drawing.Point(266, 198);
            this.txtilast.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtilast.Name = "txtilast";
            this.txtilast.Size = new System.Drawing.Size(178, 31);
            this.txtilast.TabIndex = 15;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(208, 92);
            this.textBox18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(178, 31);
            this.textBox18.TabIndex = 13;
            this.textBox18.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // cboinstructor
            // 
            this.cboinstructor.FormattingEnabled = true;
            this.cboinstructor.Location = new System.Drawing.Point(20, 90);
            this.cboinstructor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboinstructor.Name = "cboinstructor";
            this.cboinstructor.Size = new System.Drawing.Size(144, 33);
            this.cboinstructor.TabIndex = 12;
            this.cboinstructor.SelectedIndexChanged += new System.EventHandler(this.cboinstructor_SelectedIndexChanged);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.instructoridDataGridViewTextBoxColumn,
            this.lastnameDataGridViewTextBoxColumn,
            this.firstnameDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.dateofhireDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.instructorBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(678, 138);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 82;
            this.dataGridView3.RowTemplate.Height = 33;
            this.dataGridView3.Size = new System.Drawing.Size(1082, 518);
            this.dataGridView3.TabIndex = 11;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.MintCream;
            this.tabPage4.Controls.Add(this.pictureBox4);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.txtcouid);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.button1);
            this.tabPage4.Controls.Add(this.button2);
            this.tabPage4.Controls.Add(this.button3);
            this.tabPage4.Controls.Add(this.txtstuid);
            this.tabPage4.Controls.Add(this.txtcredits);
            this.tabPage4.Controls.Add(this.txtend);
            this.tabPage4.Controls.Add(this.txtstart);
            this.tabPage4.Controls.Add(this.txtedate);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.textBox7);
            this.tabPage4.Controls.Add(this.cboenroll);
            this.tabPage4.Controls.Add(this.dataGridView1);
            this.tabPage4.Location = new System.Drawing.Point(8, 39);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage4.Size = new System.Drawing.Size(2433, 810);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Enroll";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(50, 428);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 42);
            this.label4.TabIndex = 32;
            this.label4.Text = "Student ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(50, 362);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(199, 42);
            this.label10.TabIndex = 31;
            this.label10.Text = "Credit hours";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(50, 307);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(156, 42);
            this.label18.TabIndex = 30;
            this.label18.Text = "End Date";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(50, 249);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(164, 42);
            this.label19.TabIndex = 29;
            this.label19.Text = "Start Date";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(50, 191);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(177, 42);
            this.label20.TabIndex = 28;
            this.label20.Text = "Enroll date";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(398, 534);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 67);
            this.button1.TabIndex = 27;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(226, 534);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(158, 67);
            this.button2.TabIndex = 26;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(58, 534);
            this.button3.Margin = new System.Windows.Forms.Padding(6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(158, 67);
            this.button3.TabIndex = 24;
            this.button3.Text = "Insert";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtstuid
            // 
            this.txtstuid.Location = new System.Drawing.Point(294, 437);
            this.txtstuid.Margin = new System.Windows.Forms.Padding(4);
            this.txtstuid.Name = "txtstuid";
            this.txtstuid.Size = new System.Drawing.Size(178, 31);
            this.txtstuid.TabIndex = 25;
            // 
            // txtcredits
            // 
            this.txtcredits.Location = new System.Drawing.Point(294, 380);
            this.txtcredits.Margin = new System.Windows.Forms.Padding(4);
            this.txtcredits.Name = "txtcredits";
            this.txtcredits.Size = new System.Drawing.Size(178, 31);
            this.txtcredits.TabIndex = 23;
            // 
            // txtend
            // 
            this.txtend.Location = new System.Drawing.Point(294, 316);
            this.txtend.Margin = new System.Windows.Forms.Padding(4);
            this.txtend.Name = "txtend";
            this.txtend.Size = new System.Drawing.Size(178, 31);
            this.txtend.TabIndex = 22;
            // 
            // txtstart
            // 
            this.txtstart.Location = new System.Drawing.Point(294, 259);
            this.txtstart.Margin = new System.Windows.Forms.Padding(4);
            this.txtstart.Name = "txtstart";
            this.txtstart.Size = new System.Drawing.Size(178, 31);
            this.txtstart.TabIndex = 21;
            // 
            // txtedate
            // 
            this.txtedate.Location = new System.Drawing.Point(294, 203);
            this.txtedate.Margin = new System.Windows.Forms.Padding(4);
            this.txtedate.Name = "txtedate";
            this.txtedate.Size = new System.Drawing.Size(178, 31);
            this.txtedate.TabIndex = 20;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(40, 26);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(138, 49);
            this.label21.TabIndex = 19;
            this.label21.Text = "Enroll";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(238, 93);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(178, 31);
            this.textBox7.TabIndex = 18;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // cboenroll
            // 
            this.cboenroll.FormattingEnabled = true;
            this.cboenroll.Location = new System.Drawing.Point(46, 93);
            this.cboenroll.Margin = new System.Windows.Forms.Padding(4);
            this.cboenroll.Name = "cboenroll";
            this.cboenroll.Size = new System.Drawing.Size(144, 33);
            this.cboenroll.TabIndex = 17;
            this.cboenroll.SelectedIndexChanged += new System.EventHandler(this.cboenroll_SelectedIndexChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.enrollidDataGridViewTextBoxColumn,
            this.enrolldateDataGridViewTextBoxColumn,
            this.classstartdateDataGridViewTextBoxColumn,
            this.classenddateDataGridViewTextBoxColumn,
            this.numberofcreditsDataGridViewTextBoxColumn,
            this.studentidDataGridViewTextBoxColumn,
            this.courseidDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.enrollBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(492, 16);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1156, 512);
            this.dataGridView1.TabIndex = 16;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // enrollBindingSource
            // 
            this.enrollBindingSource.DataMember = "enroll";
            this.enrollBindingSource.DataSource = this.dataSet1;
            // 
            // enrollTableAdapter
            // 
            this.enrollTableAdapter.ClearBeforeFill = true;
            // 
            // enrollidDataGridViewTextBoxColumn
            // 
            this.enrollidDataGridViewTextBoxColumn.DataPropertyName = "enrollid";
            this.enrollidDataGridViewTextBoxColumn.HeaderText = "enrollid";
            this.enrollidDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.enrollidDataGridViewTextBoxColumn.Name = "enrollidDataGridViewTextBoxColumn";
            this.enrollidDataGridViewTextBoxColumn.Width = 200;
            // 
            // enrolldateDataGridViewTextBoxColumn
            // 
            this.enrolldateDataGridViewTextBoxColumn.DataPropertyName = "enrolldate";
            this.enrolldateDataGridViewTextBoxColumn.HeaderText = "enrolldate";
            this.enrolldateDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.enrolldateDataGridViewTextBoxColumn.Name = "enrolldateDataGridViewTextBoxColumn";
            this.enrolldateDataGridViewTextBoxColumn.Width = 200;
            // 
            // classstartdateDataGridViewTextBoxColumn
            // 
            this.classstartdateDataGridViewTextBoxColumn.DataPropertyName = "class_startdate";
            this.classstartdateDataGridViewTextBoxColumn.HeaderText = "class_startdate";
            this.classstartdateDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.classstartdateDataGridViewTextBoxColumn.Name = "classstartdateDataGridViewTextBoxColumn";
            this.classstartdateDataGridViewTextBoxColumn.Width = 200;
            // 
            // classenddateDataGridViewTextBoxColumn
            // 
            this.classenddateDataGridViewTextBoxColumn.DataPropertyName = "class_enddate";
            this.classenddateDataGridViewTextBoxColumn.HeaderText = "class_enddate";
            this.classenddateDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.classenddateDataGridViewTextBoxColumn.Name = "classenddateDataGridViewTextBoxColumn";
            this.classenddateDataGridViewTextBoxColumn.Width = 200;
            // 
            // numberofcreditsDataGridViewTextBoxColumn
            // 
            this.numberofcreditsDataGridViewTextBoxColumn.DataPropertyName = "numberofcredits";
            this.numberofcreditsDataGridViewTextBoxColumn.HeaderText = "numberofcredits";
            this.numberofcreditsDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.numberofcreditsDataGridViewTextBoxColumn.Name = "numberofcreditsDataGridViewTextBoxColumn";
            this.numberofcreditsDataGridViewTextBoxColumn.Width = 200;
            // 
            // studentidDataGridViewTextBoxColumn
            // 
            this.studentidDataGridViewTextBoxColumn.DataPropertyName = "studentid";
            this.studentidDataGridViewTextBoxColumn.HeaderText = "studentid";
            this.studentidDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.studentidDataGridViewTextBoxColumn.Name = "studentidDataGridViewTextBoxColumn";
            this.studentidDataGridViewTextBoxColumn.Width = 200;
            // 
            // courseidDataGridViewTextBoxColumn
            // 
            this.courseidDataGridViewTextBoxColumn.DataPropertyName = "courseid";
            this.courseidDataGridViewTextBoxColumn.HeaderText = "courseid";
            this.courseidDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.courseidDataGridViewTextBoxColumn.Name = "courseidDataGridViewTextBoxColumn";
            this.courseidDataGridViewTextBoxColumn.Width = 200;
            // 
            // txtcouid
            // 
            this.txtcouid.Location = new System.Drawing.Point(294, 493);
            this.txtcouid.Margin = new System.Windows.Forms.Padding(4);
            this.txtcouid.Name = "txtcouid";
            this.txtcouid.Size = new System.Drawing.Size(178, 31);
            this.txtcouid.TabIndex = 33;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(51, 486);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(160, 42);
            this.label22.TabIndex = 34;
            this.label22.Text = "CourseID";
            // 
            // dataSet2
            // 
            this.dataSet2.DataSetName = "DataSet2";
            this.dataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // instructorBindingSource
            // 
            this.instructorBindingSource.DataMember = "instructor";
            this.instructorBindingSource.DataSource = this.dataSet2;
            // 
            // instructorTableAdapter
            // 
            this.instructorTableAdapter.ClearBeforeFill = true;
            // 
            // instructoridDataGridViewTextBoxColumn
            // 
            this.instructoridDataGridViewTextBoxColumn.DataPropertyName = "instructorid";
            this.instructoridDataGridViewTextBoxColumn.HeaderText = "instructorid";
            this.instructoridDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.instructoridDataGridViewTextBoxColumn.Name = "instructoridDataGridViewTextBoxColumn";
            this.instructoridDataGridViewTextBoxColumn.Width = 200;
            // 
            // lastnameDataGridViewTextBoxColumn
            // 
            this.lastnameDataGridViewTextBoxColumn.DataPropertyName = "lastname";
            this.lastnameDataGridViewTextBoxColumn.HeaderText = "lastname";
            this.lastnameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.lastnameDataGridViewTextBoxColumn.Name = "lastnameDataGridViewTextBoxColumn";
            this.lastnameDataGridViewTextBoxColumn.Width = 200;
            // 
            // firstnameDataGridViewTextBoxColumn
            // 
            this.firstnameDataGridViewTextBoxColumn.DataPropertyName = "firstname";
            this.firstnameDataGridViewTextBoxColumn.HeaderText = "firstname";
            this.firstnameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.firstnameDataGridViewTextBoxColumn.Name = "firstnameDataGridViewTextBoxColumn";
            this.firstnameDataGridViewTextBoxColumn.Width = 200;
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            this.genderDataGridViewTextBoxColumn.Width = 200;
            // 
            // dateofhireDataGridViewTextBoxColumn
            // 
            this.dateofhireDataGridViewTextBoxColumn.DataPropertyName = "dateofhire";
            this.dateofhireDataGridViewTextBoxColumn.HeaderText = "dateofhire";
            this.dateofhireDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.dateofhireDataGridViewTextBoxColumn.Name = "dateofhireDataGridViewTextBoxColumn";
            this.dateofhireDataGridViewTextBoxColumn.Width = 200;
            // 
            // dataSet3
            // 
            this.dataSet3.DataSetName = "DataSet3";
            this.dataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // courseBindingSource
            // 
            this.courseBindingSource.DataMember = "Course";
            this.courseBindingSource.DataSource = this.dataSet3;
            // 
            // courseTableAdapter
            // 
            this.courseTableAdapter.ClearBeforeFill = true;
            // 
            // courseidDataGridViewTextBoxColumn1
            // 
            this.courseidDataGridViewTextBoxColumn1.DataPropertyName = "courseid";
            this.courseidDataGridViewTextBoxColumn1.HeaderText = "courseid";
            this.courseidDataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.courseidDataGridViewTextBoxColumn1.Name = "courseidDataGridViewTextBoxColumn1";
            this.courseidDataGridViewTextBoxColumn1.Width = 200;
            // 
            // coursenameDataGridViewTextBoxColumn
            // 
            this.coursenameDataGridViewTextBoxColumn.DataPropertyName = "course_name";
            this.coursenameDataGridViewTextBoxColumn.HeaderText = "course_name";
            this.coursenameDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.coursenameDataGridViewTextBoxColumn.Name = "coursenameDataGridViewTextBoxColumn";
            this.coursenameDataGridViewTextBoxColumn.Width = 200;
            // 
            // coursedescriptionDataGridViewTextBoxColumn
            // 
            this.coursedescriptionDataGridViewTextBoxColumn.DataPropertyName = "course_description";
            this.coursedescriptionDataGridViewTextBoxColumn.HeaderText = "course_description";
            this.coursedescriptionDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.coursedescriptionDataGridViewTextBoxColumn.Name = "coursedescriptionDataGridViewTextBoxColumn";
            this.coursedescriptionDataGridViewTextBoxColumn.Width = 200;
            // 
            // instructoridDataGridViewTextBoxColumn1
            // 
            this.instructoridDataGridViewTextBoxColumn1.DataPropertyName = "instructorid";
            this.instructoridDataGridViewTextBoxColumn1.HeaderText = "instructorid";
            this.instructoridDataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.instructoridDataGridViewTextBoxColumn1.Name = "instructoridDataGridViewTextBoxColumn1";
            this.instructoridDataGridViewTextBoxColumn1.Width = 200;
            // 
            // dataSet4
            // 
            this.dataSet4.DataSetName = "DataSet4";
            this.dataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "student";
            this.studentBindingSource.DataSource = this.dataSet4;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // studentidDataGridViewTextBoxColumn1
            // 
            this.studentidDataGridViewTextBoxColumn1.DataPropertyName = "studentid";
            this.studentidDataGridViewTextBoxColumn1.HeaderText = "studentid";
            this.studentidDataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.studentidDataGridViewTextBoxColumn1.Name = "studentidDataGridViewTextBoxColumn1";
            this.studentidDataGridViewTextBoxColumn1.Width = 200;
            // 
            // lastnameDataGridViewTextBoxColumn1
            // 
            this.lastnameDataGridViewTextBoxColumn1.DataPropertyName = "lastname";
            this.lastnameDataGridViewTextBoxColumn1.HeaderText = "lastname";
            this.lastnameDataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.lastnameDataGridViewTextBoxColumn1.Name = "lastnameDataGridViewTextBoxColumn1";
            this.lastnameDataGridViewTextBoxColumn1.Width = 200;
            // 
            // firstnameDataGridViewTextBoxColumn1
            // 
            this.firstnameDataGridViewTextBoxColumn1.DataPropertyName = "firstname";
            this.firstnameDataGridViewTextBoxColumn1.HeaderText = "firstname";
            this.firstnameDataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.firstnameDataGridViewTextBoxColumn1.Name = "firstnameDataGridViewTextBoxColumn1";
            this.firstnameDataGridViewTextBoxColumn1.Width = 200;
            // 
            // genderDataGridViewTextBoxColumn1
            // 
            this.genderDataGridViewTextBoxColumn1.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn1.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.genderDataGridViewTextBoxColumn1.Name = "genderDataGridViewTextBoxColumn1";
            this.genderDataGridViewTextBoxColumn1.Width = 200;
            // 
            // dataofbirthDataGridViewTextBoxColumn
            // 
            this.dataofbirthDataGridViewTextBoxColumn.DataPropertyName = "dataofbirth";
            this.dataofbirthDataGridViewTextBoxColumn.HeaderText = "dataofbirth";
            this.dataofbirthDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.dataofbirthDataGridViewTextBoxColumn.Name = "dataofbirthDataGridViewTextBoxColumn";
            this.dataofbirthDataGridViewTextBoxColumn.Width = 200;
            // 
            // initialregistrationdateDataGridViewTextBoxColumn
            // 
            this.initialregistrationdateDataGridViewTextBoxColumn.DataPropertyName = "initialregistrationdate";
            this.initialregistrationdateDataGridViewTextBoxColumn.HeaderText = "initialregistrationdate";
            this.initialregistrationdateDataGridViewTextBoxColumn.MinimumWidth = 10;
            this.initialregistrationdateDataGridViewTextBoxColumn.Name = "initialregistrationdateDataGridViewTextBoxColumn";
            this.initialregistrationdateDataGridViewTextBoxColumn.Width = 200;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1754, 428);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(552, 378);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1561, 35);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(558, 596);
            this.pictureBox2.TabIndex = 27;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1767, 108);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(610, 527);
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(1799, 638);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(168, 25);
            this.label23.TabIndex = 29;
            this.label23.Text = "Professor knight";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(1703, 390);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(618, 431);
            this.pictureBox4.TabIndex = 35;
            this.pictureBox4.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(2354, 1044);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnlogout);
            this.Controls.Add(this.btnexit2);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvstudent)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvclass)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enrollBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.courseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Button btnexit2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dgvstudent;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btninsert;
        private System.Windows.Forms.TextBox txtdate;
        private System.Windows.Forms.TextBox txtdob;
        private System.Windows.Forms.TextBox txtgender;
        private System.Windows.Forms.TextBox txtfirst;
        private System.Windows.Forms.TextBox txtlast;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox cbosid;
        private System.Windows.Forms.Button btndel;
        private System.Windows.Forms.Button btnup;
        private System.Windows.Forms.Button btnin;
        private System.Windows.Forms.TextBox txttid;
        private System.Windows.Forms.TextBox txtdesc;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.ComboBox cbocourse;
        private System.Windows.Forms.DataGridView dgvclass;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnu;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox txthire;
        private System.Windows.Forms.TextBox txtigen;
        private System.Windows.Forms.TextBox txtifirst;
        private System.Windows.Forms.TextBox txtilast;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.ComboBox cboinstructor;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtstuid;
        private System.Windows.Forms.TextBox txtcredits;
        private System.Windows.Forms.TextBox txtend;
        private System.Windows.Forms.TextBox txtstart;
        private System.Windows.Forms.TextBox txtedate;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.ComboBox cboenroll;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource enrollBindingSource;
        private DataSet1TableAdapters.enrollTableAdapter enrollTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn enrollidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn enrolldateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn classstartdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn classenddateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberofcreditsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseidDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtcouid;
        private System.Windows.Forms.Label label22;
        private DataSet2 dataSet2;
        private System.Windows.Forms.BindingSource instructorBindingSource;
        private DataSet2TableAdapters.instructorTableAdapter instructorTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn instructoridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateofhireDataGridViewTextBoxColumn;
        private DataSet3 dataSet3;
        private System.Windows.Forms.BindingSource courseBindingSource;
        private DataSet3TableAdapters.CourseTableAdapter courseTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn coursenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn coursedescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn instructoridDataGridViewTextBoxColumn1;
        private DataSet4 dataSet4;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private DataSet4TableAdapters.studentTableAdapter studentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataofbirthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn initialregistrationdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}