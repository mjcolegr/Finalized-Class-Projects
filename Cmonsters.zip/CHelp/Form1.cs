﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CHelp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {

            SqlConnection sqlcon = new SqlConnection(@"Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22U45;Persist Security Info=True;User ID=ISYS4283SP22U45;Password=GohogsUA1");
            string query = "Select * from LOGIN where username = '" + txtusername.Text.Trim() + "' and password = '" + txtpassword.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count == 1)
            {
                Main objMain = new Main();
                this.Hide();
                objMain.Show();

            }
            else
            {
                MessageBox.Show("Check your username and password", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       
    }
}
