﻿
namespace WindowsFormsApp1
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnViewPrevious = new System.Windows.Forms.Button();
            this.lblLoadMoney = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblReceiptLink = new System.Windows.Forms.Label();
            this.txtReceiptLink = new System.Windows.Forms.TextBox();
            this.btnSubmitExpense = new System.Windows.Forms.Button();
            this.txtExpenseDescription = new System.Windows.Forms.TextBox();
            this.lblExpenseDescription = new System.Windows.Forms.Label();
            this.dtpExpenseDate = new System.Windows.Forms.DateTimePicker();
            this.lblDollarAmount = new System.Windows.Forms.Label();
            this.txtExpenseAmount = new System.Windows.Forms.TextBox();
            this.lblTransactionDate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.lblExpenseDetails = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblLast4 = new System.Windows.Forms.Label();
            this.txtLastFourofCard = new System.Windows.Forms.TextBox();
            this.btnSubmitRequest = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCurrentBalance = new System.Windows.Forms.TextBox();
            this.lblHealthcare = new System.Windows.Forms.Label();
            this.loadmoneydescript = new System.Windows.Forms.TextBox();
            this.lblProvideReasoning = new System.Windows.Forms.Label();
            this.txtamtadd = new System.Windows.Forms.TextBox();
            this.lblFileExpenses = new System.Windows.Forms.Label();
            this.btnUploadReceipt = new System.Windows.Forms.Button();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.lblUsernamePassed = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.dateTimePickerfileexpenses = new System.Windows.Forms.DateTimePicker();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnViewPrevious
            // 
            this.btnViewPrevious.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnViewPrevious.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F);
            this.btnViewPrevious.ForeColor = System.Drawing.Color.White;
            this.btnViewPrevious.Location = new System.Drawing.Point(839, 36);
            this.btnViewPrevious.Name = "btnViewPrevious";
            this.btnViewPrevious.Size = new System.Drawing.Size(203, 37);
            this.btnViewPrevious.TabIndex = 12;
            this.btnViewPrevious.Text = "View Previous Expenses";
            this.btnViewPrevious.UseVisualStyleBackColor = false;
            this.btnViewPrevious.Click += new System.EventHandler(this.btnViewPrevious_Click);
            // 
            // lblLoadMoney
            // 
            this.lblLoadMoney.AutoSize = true;
            this.lblLoadMoney.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoadMoney.ForeColor = System.Drawing.Color.White;
            this.lblLoadMoney.Location = new System.Drawing.Point(51, 16);
            this.lblLoadMoney.Name = "lblLoadMoney";
            this.lblLoadMoney.Size = new System.Drawing.Size(302, 25);
            this.lblLoadMoney.TabIndex = 12;
            this.lblLoadMoney.Text = "Load Money Onto Corporate Card";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.groupBox2.Controls.Add(this.lblReceiptLink);
            this.groupBox2.Controls.Add(this.txtReceiptLink);
            this.groupBox2.Controls.Add(this.btnSubmitExpense);
            this.groupBox2.Controls.Add(this.txtExpenseDescription);
            this.groupBox2.Controls.Add(this.lblExpenseDescription);
            this.groupBox2.Controls.Add(this.dtpExpenseDate);
            this.groupBox2.Controls.Add(this.lblDollarAmount);
            this.groupBox2.Controls.Add(this.txtExpenseAmount);
            this.groupBox2.Controls.Add(this.lblTransactionDate);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.lblExpenseDetails);
            this.groupBox2.Location = new System.Drawing.Point(286, 124);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(328, 450);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            // 
            // lblReceiptLink
            // 
            this.lblReceiptLink.AutoSize = true;
            this.lblReceiptLink.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblReceiptLink.ForeColor = System.Drawing.Color.White;
            this.lblReceiptLink.Location = new System.Drawing.Point(14, 319);
            this.lblReceiptLink.Name = "lblReceiptLink";
            this.lblReceiptLink.Size = new System.Drawing.Size(190, 21);
            this.lblReceiptLink.TabIndex = 88;
            this.lblReceiptLink.Text = "Paste the receipt link here:";
            // 
            // txtReceiptLink
            // 
            this.txtReceiptLink.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceiptLink.Location = new System.Drawing.Point(14, 343);
            this.txtReceiptLink.Multiline = true;
            this.txtReceiptLink.Name = "txtReceiptLink";
            this.txtReceiptLink.Size = new System.Drawing.Size(285, 30);
            this.txtReceiptLink.TabIndex = 89;
            // 
            // btnSubmitExpense
            // 
            this.btnSubmitExpense.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnSubmitExpense.Font = new System.Drawing.Font("Segoe UI Semibold", 12F);
            this.btnSubmitExpense.ForeColor = System.Drawing.Color.White;
            this.btnSubmitExpense.Location = new System.Drawing.Point(78, 388);
            this.btnSubmitExpense.Name = "btnSubmitExpense";
            this.btnSubmitExpense.Size = new System.Drawing.Size(175, 49);
            this.btnSubmitExpense.TabIndex = 87;
            this.btnSubmitExpense.Text = "Submit Expense";
            this.btnSubmitExpense.UseVisualStyleBackColor = false;
            this.btnSubmitExpense.Click += new System.EventHandler(this.btnSubmitExpense_Click);
            // 
            // txtExpenseDescription
            // 
            this.txtExpenseDescription.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.txtExpenseDescription.Location = new System.Drawing.Point(10, 233);
            this.txtExpenseDescription.Multiline = true;
            this.txtExpenseDescription.Name = "txtExpenseDescription";
            this.txtExpenseDescription.Size = new System.Drawing.Size(285, 76);
            this.txtExpenseDescription.TabIndex = 77;
            // 
            // lblExpenseDescription
            // 
            this.lblExpenseDescription.AutoSize = true;
            this.lblExpenseDescription.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblExpenseDescription.ForeColor = System.Drawing.Color.White;
            this.lblExpenseDescription.Location = new System.Drawing.Point(10, 181);
            this.lblExpenseDescription.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblExpenseDescription.Name = "lblExpenseDescription";
            this.lblExpenseDescription.Size = new System.Drawing.Size(265, 42);
            this.lblExpenseDescription.TabIndex = 77;
            this.lblExpenseDescription.Text = "Please type a brief description of the expense.";
            // 
            // dtpExpenseDate
            // 
            this.dtpExpenseDate.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.dtpExpenseDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpExpenseDate.Location = new System.Drawing.Point(10, 141);
            this.dtpExpenseDate.Name = "dtpExpenseDate";
            this.dtpExpenseDate.Size = new System.Drawing.Size(124, 29);
            this.dtpExpenseDate.TabIndex = 83;
            // 
            // lblDollarAmount
            // 
            this.lblDollarAmount.AutoSize = true;
            this.lblDollarAmount.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblDollarAmount.ForeColor = System.Drawing.Color.White;
            this.lblDollarAmount.Location = new System.Drawing.Point(184, 116);
            this.lblDollarAmount.Name = "lblDollarAmount";
            this.lblDollarAmount.Size = new System.Drawing.Size(112, 21);
            this.lblDollarAmount.TabIndex = 81;
            this.lblDollarAmount.Text = "Dollar Amount";
            // 
            // txtExpenseAmount
            // 
            this.txtExpenseAmount.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExpenseAmount.Location = new System.Drawing.Point(187, 140);
            this.txtExpenseAmount.Multiline = true;
            this.txtExpenseAmount.Name = "txtExpenseAmount";
            this.txtExpenseAmount.Size = new System.Drawing.Size(108, 30);
            this.txtExpenseAmount.TabIndex = 82;
            // 
            // lblTransactionDate
            // 
            this.lblTransactionDate.AutoSize = true;
            this.lblTransactionDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblTransactionDate.ForeColor = System.Drawing.Color.White;
            this.lblTransactionDate.Location = new System.Drawing.Point(10, 117);
            this.lblTransactionDate.Name = "lblTransactionDate";
            this.lblTransactionDate.Size = new System.Drawing.Size(125, 21);
            this.lblTransactionDate.TabIndex = 79;
            this.lblTransactionDate.Text = "Transaction Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(10, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 21);
            this.label1.TabIndex = 77;
            this.label1.Text = "Where was this transaction made?";
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(10, 78);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(285, 30);
            this.textBox8.TabIndex = 78;
            // 
            // lblExpenseDetails
            // 
            this.lblExpenseDetails.AutoSize = true;
            this.lblExpenseDetails.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpenseDetails.ForeColor = System.Drawing.Color.White;
            this.lblExpenseDetails.Location = new System.Drawing.Point(95, 16);
            this.lblExpenseDetails.Name = "lblExpenseDetails";
            this.lblExpenseDetails.Size = new System.Drawing.Size(146, 25);
            this.lblExpenseDetails.TabIndex = 77;
            this.lblExpenseDetails.Text = "Expense Details";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.groupBox3.Controls.Add(this.lblLast4);
            this.groupBox3.Controls.Add(this.txtLastFourofCard);
            this.groupBox3.Controls.Add(this.btnSubmitRequest);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtCurrentBalance);
            this.groupBox3.Controls.Add(this.lblHealthcare);
            this.groupBox3.Controls.Add(this.loadmoneydescript);
            this.groupBox3.Controls.Add(this.lblProvideReasoning);
            this.groupBox3.Controls.Add(this.txtamtadd);
            this.groupBox3.Controls.Add(this.lblLoadMoney);
            this.groupBox3.Location = new System.Drawing.Point(635, 124);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(407, 450);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            // 
            // lblLast4
            // 
            this.lblLast4.AutoSize = true;
            this.lblLast4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblLast4.ForeColor = System.Drawing.Color.White;
            this.lblLast4.Location = new System.Drawing.Point(16, 69);
            this.lblLast4.Name = "lblLast4";
            this.lblLast4.Size = new System.Drawing.Size(106, 21);
            this.lblLast4.TabIndex = 87;
            this.lblLast4.Text = "Last 4 of Card";
            // 
            // txtLastFourofCard
            // 
            this.txtLastFourofCard.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastFourofCard.Location = new System.Drawing.Point(142, 66);
            this.txtLastFourofCard.Multiline = true;
            this.txtLastFourofCard.Name = "txtLastFourofCard";
            this.txtLastFourofCard.ReadOnly = true;
            this.txtLastFourofCard.Size = new System.Drawing.Size(251, 30);
            this.txtLastFourofCard.TabIndex = 88;
            // 
            // btnSubmitRequest
            // 
            this.btnSubmitRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnSubmitRequest.Font = new System.Drawing.Font("Segoe UI Semibold", 12F);
            this.btnSubmitRequest.ForeColor = System.Drawing.Color.White;
            this.btnSubmitRequest.Location = new System.Drawing.Point(125, 388);
            this.btnSubmitRequest.Name = "btnSubmitRequest";
            this.btnSubmitRequest.Size = new System.Drawing.Size(162, 49);
            this.btnSubmitRequest.TabIndex = 86;
            this.btnSubmitRequest.Text = "Submit Request";
            this.btnSubmitRequest.UseVisualStyleBackColor = false;
            this.btnSubmitRequest.Click += new System.EventHandler(this.btnSubmitRequest_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(16, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 21);
            this.label2.TabIndex = 75;
            this.label2.Text = "Current Balance";
            // 
            // txtCurrentBalance
            // 
            this.txtCurrentBalance.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrentBalance.Location = new System.Drawing.Point(158, 116);
            this.txtCurrentBalance.Multiline = true;
            this.txtCurrentBalance.Name = "txtCurrentBalance";
            this.txtCurrentBalance.ReadOnly = true;
            this.txtCurrentBalance.Size = new System.Drawing.Size(235, 30);
            this.txtCurrentBalance.TabIndex = 76;
            this.txtCurrentBalance.TextChanged += new System.EventHandler(this.txtCurrentBalance_TextChanged);
            // 
            // lblHealthcare
            // 
            this.lblHealthcare.AutoSize = true;
            this.lblHealthcare.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblHealthcare.ForeColor = System.Drawing.Color.White;
            this.lblHealthcare.Location = new System.Drawing.Point(17, 164);
            this.lblHealthcare.Name = "lblHealthcare";
            this.lblHealthcare.Size = new System.Drawing.Size(229, 21);
            this.lblHealthcare.TabIndex = 38;
            this.lblHealthcare.Text = "How much do you need added?";
            // 
            // loadmoneydescript
            // 
            this.loadmoneydescript.Font = new System.Drawing.Font("Segoe UI Semilight", 10F);
            this.loadmoneydescript.Location = new System.Drawing.Point(21, 264);
            this.loadmoneydescript.Multiline = true;
            this.loadmoneydescript.Name = "loadmoneydescript";
            this.loadmoneydescript.Size = new System.Drawing.Size(353, 76);
            this.loadmoneydescript.TabIndex = 74;
            // 
            // lblProvideReasoning
            // 
            this.lblProvideReasoning.AutoSize = true;
            this.lblProvideReasoning.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblProvideReasoning.ForeColor = System.Drawing.Color.White;
            this.lblProvideReasoning.Location = new System.Drawing.Point(17, 210);
            this.lblProvideReasoning.MaximumSize = new System.Drawing.Size(370, 0);
            this.lblProvideReasoning.Name = "lblProvideReasoning";
            this.lblProvideReasoning.Size = new System.Drawing.Size(354, 42);
            this.lblProvideReasoning.TabIndex = 73;
            this.lblProvideReasoning.Text = "Please provide reasoning for money to be loaded onto your card.";
            // 
            // txtamtadd
            // 
            this.txtamtadd.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtamtadd.Location = new System.Drawing.Point(277, 159);
            this.txtamtadd.Multiline = true;
            this.txtamtadd.Name = "txtamtadd";
            this.txtamtadd.Size = new System.Drawing.Size(116, 30);
            this.txtamtadd.TabIndex = 39;
            // 
            // lblFileExpenses
            // 
            this.lblFileExpenses.AutoSize = true;
            this.lblFileExpenses.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileExpenses.Location = new System.Drawing.Point(21, 22);
            this.lblFileExpenses.Name = "lblFileExpenses";
            this.lblFileExpenses.Size = new System.Drawing.Size(217, 47);
            this.lblFileExpenses.TabIndex = 30;
            this.lblFileExpenses.Text = "File Expenses";
            // 
            // btnUploadReceipt
            // 
            this.btnUploadReceipt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.btnUploadReceipt.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUploadReceipt.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUploadReceipt.Location = new System.Drawing.Point(29, 124);
            this.btnUploadReceipt.Name = "btnUploadReceipt";
            this.btnUploadReceipt.Size = new System.Drawing.Size(223, 450);
            this.btnUploadReceipt.TabIndex = 88;
            this.btnUploadReceipt.Text = "Upload Receipt";
            this.btnUploadReceipt.UseVisualStyleBackColor = false;
            this.btnUploadReceipt.Click += new System.EventHandler(this.btnUploadReceipt_Click);
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeID.Location = new System.Drawing.Point(89, 69);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeID.Size = new System.Drawing.Size(199, 21);
            this.lblEmployeeID.TabIndex = 91;
            this.lblEmployeeID.Text = "employee id (auto-updates)";
            this.lblEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUsernamePassed
            // 
            this.lblUsernamePassed.AutoSize = true;
            this.lblUsernamePassed.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsernamePassed.Location = new System.Drawing.Point(25, 69);
            this.lblUsernamePassed.Name = "lblUsernamePassed";
            this.lblUsernamePassed.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblUsernamePassed.Size = new System.Drawing.Size(67, 21);
            this.lblUsernamePassed.TabIndex = 90;
            this.lblUsernamePassed.Text = "User ID:";
            this.lblUsernamePassed.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.button2.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.button2.Location = new System.Drawing.Point(949, 580);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 44);
            this.button2.TabIndex = 113;
            this.button2.Text = "Home";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dateTimePickerfileexpenses
            // 
            this.dateTimePickerfileexpenses.Location = new System.Drawing.Point(29, 601);
            this.dateTimePickerfileexpenses.Name = "dateTimePickerfileexpenses";
            this.dateTimePickerfileexpenses.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerfileexpenses.TabIndex = 115;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.pictureBox6.Image = global::WindowsFormsApp1.Properties.Resources.home_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox6.Location = new System.Drawing.Point(1013, 584);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(29, 37);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 114;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.outline_file_upload_black_48dp;
            this.pictureBox1.Location = new System.Drawing.Point(95, 242);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 85);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(202)))), ((int)(((byte)(230)))));
            this.ClientSize = new System.Drawing.Size(1071, 640);
            this.Controls.Add(this.dateTimePickerfileexpenses);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lblEmployeeID);
            this.Controls.Add(this.lblUsernamePassed);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnUploadReceipt);
            this.Controls.Add(this.lblFileExpenses);
            this.Controls.Add(this.btnViewPrevious);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Name = "Form6";
            this.Text = "File Expenses";
            this.Load += new System.EventHandler(this.Form6_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnViewPrevious;
        private System.Windows.Forms.Label lblLoadMoney;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblFileExpenses;
        private System.Windows.Forms.TextBox txtamtadd;
        private System.Windows.Forms.Label lblHealthcare;
        private System.Windows.Forms.TextBox loadmoneydescript;
        private System.Windows.Forms.Label lblProvideReasoning;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCurrentBalance;
        private System.Windows.Forms.Button btnUploadReceipt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblDollarAmount;
        private System.Windows.Forms.TextBox txtExpenseAmount;
        private System.Windows.Forms.Label lblTransactionDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label lblExpenseDetails;
        private System.Windows.Forms.TextBox txtExpenseDescription;
        private System.Windows.Forms.Label lblExpenseDescription;
        private System.Windows.Forms.DateTimePicker dtpExpenseDate;
        private System.Windows.Forms.Button btnSubmitExpense;
        private System.Windows.Forms.Button btnSubmitRequest;
        private System.Windows.Forms.Label lblLast4;
        private System.Windows.Forms.TextBox txtLastFourofCard;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.Label lblUsernamePassed;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblReceiptLink;
        private System.Windows.Forms.TextBox txtReceiptLink;
        private System.Windows.Forms.DateTimePicker dateTimePickerfileexpenses;
    }
}