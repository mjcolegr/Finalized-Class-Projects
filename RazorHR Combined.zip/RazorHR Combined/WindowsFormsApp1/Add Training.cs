﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class AddTraining : Form
    {
        public static string loggedinID;


        SqlConnection con = new SqlConnection(@"data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;password=GohogsUA1;");
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public AddTraining()
        {
            InitializeComponent();
            showdata();
        }

        private void btnUpdateBenefits_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Training (Vendor_ID, Topic, Link, Start_Date, End_Date, Description) VALUES (@Vendor_ID, @Topic, @Link, @Start_Date, @End_Date, @Description)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Vendor_ID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@Topic", txtTopic.Text);
                cmd.Parameters.AddWithValue("@Link", txtLink.Text);
                cmd.Parameters.AddWithValue("@Start_Date", dtpStart.Value.ToString());
                cmd.Parameters.AddWithValue("@End_Date", dtpEnd.Value.ToString());
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully added training!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.");
            }

        }
        public void showdata()
        {
            SqlConnection con = new SqlConnection("Data Source = essql1.walton.uark.edu; Initial Catalog = ISYS4283SP22T14; User ID = ISYS4283SP22T14; Password = GohogsUA1");
            SqlCommand cmd;
            SqlDataAdapter adpt;
            DataTable dt;

            adpt = new SqlDataAdapter("SELECT Training_ID, Topic, Link, Start_Date, End_Date, Description FROM Training WHERE Assigned_Employee_ID IS NULL", con);
            dt = new DataTable();
            adpt.Fill(dt);
            dgvTrainings.DataSource = dt;
        }

        private void btnAssignTraining_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Training VALUES (@Vendor_ID, @Topic, @Link, @Start_Date, @End_Date, @Description, @Assigned_Employee_ID)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Vendor_ID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@Topic", txtTopic.Text);
                cmd.Parameters.AddWithValue("@Link", txtLink.Text);
                cmd.Parameters.AddWithValue("@Start_Date", dtpStart.Value.ToString());
                cmd.Parameters.AddWithValue("@End_Date", dtpEnd.Value.ToString());
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@Assigned_Employee_ID", lblEmployeeID.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully assigned training to user " + txtAssignedUser.Text + "!");
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvTrainings_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtTopic.Text = dgvTrainings.CurrentRow.Cells[1].Value.ToString();
            txtLink.Text = dgvTrainings.CurrentRow.Cells[2].Value.ToString();
            txtDescription.Text = dgvTrainings.CurrentRow.Cells[5].Value.ToString();
            dtpStart.Text = dgvTrainings.CurrentRow.Cells[3].Value.ToString();
            dtpEnd.Text = dgvTrainings.CurrentRow.Cells[4].Value.ToString();
        }

        private void AddTraining_Load(object sender, EventArgs e)
        {
            lblEmployeeID.Text = Form4.username1;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1";
            con.Open();
            if (lblEmployeeID.Text != "")
            {
                SqlCommand cmd = new SqlCommand("SELECT Employee_ID FROM LOGIN WHERE Username=@U", con);
                cmd.Parameters.AddWithValue("@U", lblEmployeeID.Text);
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    lblEmployeeID.Text = da.GetValue(0).ToString();
                }
                con.Close();

                loggedinID = lblEmployeeID.Text;
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var myForm = new Form4();
            myForm.Show();
            this.Hide();
        }
    }
}