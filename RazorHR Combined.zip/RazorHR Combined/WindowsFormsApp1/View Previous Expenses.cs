﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form7 : Form
    {
        SqlConnection con = new SqlConnection(@"data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;password=GohogsUA1;");
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        private void Form7_Load(object sender, EventArgs e)
        {
            
        }
        public Form7()
        {
            InitializeComponent();
            lblEmployeeID.Text = Form1.loggedinID;
            showdata();
        }
       

        public void showdata()
        {
            SqlConnection con = new SqlConnection(@"data Source = essql1.walton.uark.edu; Initial Catalog = ISYS4283SP22T14; User ID = ISYS4283SP22T14; password = GohogsUA1;");
            SqlCommand cmd;
            SqlDataAdapter adpt;
            DataTable dt;

            adpt = new SqlDataAdapter("SELECT * FROM Expenses WHERE Employee_ID = " + lblEmployeeID.Text, con);
            dt = new DataTable();
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
   
}
