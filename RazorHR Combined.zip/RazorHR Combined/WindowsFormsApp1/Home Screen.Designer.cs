﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTraining = new System.Windows.Forms.Button();
            this.btnBenefits = new System.Windows.Forms.Button();
            this.btnPayroll = new System.Windows.Forms.Button();
            this.btnFileExpenses = new System.Windows.Forms.Button();
            this.btnHiringAndFiring = new System.Windows.Forms.Button();
            this.btnBookTravel = new System.Windows.Forms.Button();
            this.lblWhatToDo = new System.Windows.Forms.Label();
            this.lblOpenTicket = new System.Windows.Forms.Label();
            this.lblUsernamePassed = new System.Windows.Forms.Label();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.lblStartTime = new System.Windows.Forms.Label();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtTimeWorked = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnTraining
            // 
            this.btnTraining.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnTraining.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTraining.Location = new System.Drawing.Point(569, 251);
            this.btnTraining.Name = "btnTraining";
            this.btnTraining.Size = new System.Drawing.Size(249, 126);
            this.btnTraining.TabIndex = 21;
            this.btnTraining.Text = "Training";
            this.btnTraining.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnTraining.UseVisualStyleBackColor = false;
            this.btnTraining.Click += new System.EventHandler(this.btnTraining_Click);
            // 
            // btnBenefits
            // 
            this.btnBenefits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.btnBenefits.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBenefits.Location = new System.Drawing.Point(297, 251);
            this.btnBenefits.Name = "btnBenefits";
            this.btnBenefits.Size = new System.Drawing.Size(249, 126);
            this.btnBenefits.TabIndex = 20;
            this.btnBenefits.Text = "Benefits";
            this.btnBenefits.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBenefits.UseVisualStyleBackColor = false;
            this.btnBenefits.Click += new System.EventHandler(this.btnBenefits_Click);
            // 
            // btnPayroll
            // 
            this.btnPayroll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.btnPayroll.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayroll.Location = new System.Drawing.Point(20, 251);
            this.btnPayroll.Name = "btnPayroll";
            this.btnPayroll.Size = new System.Drawing.Size(249, 126);
            this.btnPayroll.TabIndex = 19;
            this.btnPayroll.Text = "Payroll";
            this.btnPayroll.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPayroll.UseVisualStyleBackColor = false;
            this.btnPayroll.Click += new System.EventHandler(this.btnPayroll_Click);
            // 
            // btnFileExpenses
            // 
            this.btnFileExpenses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.btnFileExpenses.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFileExpenses.Location = new System.Drawing.Point(569, 108);
            this.btnFileExpenses.Name = "btnFileExpenses";
            this.btnFileExpenses.Size = new System.Drawing.Size(249, 126);
            this.btnFileExpenses.TabIndex = 18;
            this.btnFileExpenses.Text = "File Expenses / Load Card";
            this.btnFileExpenses.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnFileExpenses.UseVisualStyleBackColor = false;
            this.btnFileExpenses.Click += new System.EventHandler(this.btnFileExpenses_Click);
            // 
            // btnHiringAndFiring
            // 
            this.btnHiringAndFiring.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.btnHiringAndFiring.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHiringAndFiring.Location = new System.Drawing.Point(297, 108);
            this.btnHiringAndFiring.Name = "btnHiringAndFiring";
            this.btnHiringAndFiring.Size = new System.Drawing.Size(249, 126);
            this.btnHiringAndFiring.TabIndex = 17;
            this.btnHiringAndFiring.Text = "Hire or Terminate";
            this.btnHiringAndFiring.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnHiringAndFiring.UseVisualStyleBackColor = false;
            this.btnHiringAndFiring.Click += new System.EventHandler(this.btnHiringAndFiring_Click);
            // 
            // btnBookTravel
            // 
            this.btnBookTravel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnBookTravel.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBookTravel.Location = new System.Drawing.Point(20, 108);
            this.btnBookTravel.Name = "btnBookTravel";
            this.btnBookTravel.Size = new System.Drawing.Size(249, 126);
            this.btnBookTravel.TabIndex = 16;
            this.btnBookTravel.Text = "Book Travel";
            this.btnBookTravel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBookTravel.UseVisualStyleBackColor = false;
            this.btnBookTravel.Click += new System.EventHandler(this.btnBookTravel_Click);
            // 
            // lblWhatToDo
            // 
            this.lblWhatToDo.AutoSize = true;
            this.lblWhatToDo.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWhatToDo.Location = new System.Drawing.Point(16, 74);
            this.lblWhatToDo.Name = "lblWhatToDo";
            this.lblWhatToDo.Size = new System.Drawing.Size(178, 21);
            this.lblWhatToDo.TabIndex = 15;
            this.lblWhatToDo.Text = "What do you want to do?";
            // 
            // lblOpenTicket
            // 
            this.lblOpenTicket.AutoSize = true;
            this.lblOpenTicket.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpenTicket.Location = new System.Drawing.Point(12, 22);
            this.lblOpenTicket.Name = "lblOpenTicket";
            this.lblOpenTicket.Size = new System.Drawing.Size(305, 47);
            this.lblOpenTicket.TabIndex = 14;
            this.lblOpenTicket.Text = "Open a New Ticket";
            // 
            // lblUsernamePassed
            // 
            this.lblUsernamePassed.AutoSize = true;
            this.lblUsernamePassed.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsernamePassed.Location = new System.Drawing.Point(738, 10);
            this.lblUsernamePassed.Name = "lblUsernamePassed";
            this.lblUsernamePassed.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblUsernamePassed.Size = new System.Drawing.Size(185, 21);
            this.lblUsernamePassed.TabIndex = 29;
            this.lblUsernamePassed.Text = "username (auto-updates)";
            this.lblUsernamePassed.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeID.Location = new System.Drawing.Point(738, 33);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeID.Size = new System.Drawing.Size(199, 21);
            this.lblEmployeeID.TabIndex = 30;
            this.lblEmployeeID.Text = "employee id (auto-updates)";
            this.lblEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpStart
            // 
            this.dtpStart.CalendarFont = new System.Drawing.Font("Segoe UI", 11F);
            this.dtpStart.CustomFormat = "hh:mm:ss tt";
            this.dtpStart.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStart.Location = new System.Drawing.Point(687, 418);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(131, 27);
            this.dtpStart.TabIndex = 31;
            // 
            // dtpEnd
            // 
            this.dtpEnd.CalendarFont = new System.Drawing.Font("Segoe UI", 11F);
            this.dtpEnd.CustomFormat = "hh:mm:ss tt";
            this.dtpEnd.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEnd.Location = new System.Drawing.Point(687, 457);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(131, 27);
            this.dtpEnd.TabIndex = 32;
            // 
            // lblStartTime
            // 
            this.lblStartTime.AutoSize = true;
            this.lblStartTime.Font = new System.Drawing.Font("Segoe UI Semilight", 11F);
            this.lblStartTime.Location = new System.Drawing.Point(605, 421);
            this.lblStartTime.Name = "lblStartTime";
            this.lblStartTime.Size = new System.Drawing.Size(76, 20);
            this.lblStartTime.TabIndex = 33;
            this.lblStartTime.Text = "Start Time";
            // 
            // lblEndTime
            // 
            this.lblEndTime.AutoSize = true;
            this.lblEndTime.Font = new System.Drawing.Font("Segoe UI Semilight", 11F);
            this.lblEndTime.Location = new System.Drawing.Point(611, 460);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.Size = new System.Drawing.Size(70, 20);
            this.lblEndTime.TabIndex = 34;
            this.lblEndTime.Text = "End Time";
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnCalculate.Font = new System.Drawing.Font("Segoe UI Semilight", 11F);
            this.btnCalculate.Location = new System.Drawing.Point(731, 511);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(87, 32);
            this.btnCalculate.TabIndex = 35;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtTimeWorked
            // 
            this.txtTimeWorked.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtTimeWorked.Location = new System.Drawing.Point(569, 549);
            this.txtTimeWorked.Name = "txtTimeWorked";
            this.txtTimeWorked.Size = new System.Drawing.Size(156, 27);
            this.txtTimeWorked.TabIndex = 36;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnSubmit.Font = new System.Drawing.Font("Segoe UI Semilight", 11F);
            this.btnSubmit.Location = new System.Drawing.Point(731, 548);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(87, 31);
            this.btnSubmit.TabIndex = 37;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI Semilight", 11F);
            this.btnLogout.Location = new System.Drawing.Point(57, 538);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(87, 37);
            this.btnLogout.TabIndex = 39;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.pictureBox3.Image = global::WindowsFormsApp1.Properties.Resources.money;
            this.pictureBox3.Location = new System.Drawing.Point(643, 137);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(99, 94);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 24;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = global::WindowsFormsApp1.Properties.Resources.logout_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox7.Location = new System.Drawing.Point(20, 538);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(31, 38);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 38;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.pictureBox6.Image = global::WindowsFormsApp1.Properties.Resources.outline_model_training_black_48dp;
            this.pictureBox6.Location = new System.Drawing.Point(642, 282);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 84);
            this.pictureBox6.TabIndex = 27;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.pictureBox5.Image = global::WindowsFormsApp1.Properties.Resources.person;
            this.pictureBox5.Location = new System.Drawing.Point(373, 282);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(95, 84);
            this.pictureBox5.TabIndex = 26;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.pictureBox4.Image = global::WindowsFormsApp1.Properties.Resources.outline_payments_black_48dp;
            this.pictureBox4.Location = new System.Drawing.Point(96, 282);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(95, 84);
            this.pictureBox4.TabIndex = 25;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.pictureBox2.Image = global::WindowsFormsApp1.Properties.Resources.people;
            this.pictureBox2.Location = new System.Drawing.Point(373, 136);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(95, 95);
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.outline_explore_black_48dp;
            this.pictureBox1.Location = new System.Drawing.Point(96, 136);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(95, 95);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(202)))), ((int)(((byte)(230)))));
            this.ClientSize = new System.Drawing.Size(845, 609);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtTimeWorked);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblEndTime);
            this.Controls.Add(this.lblStartTime);
            this.Controls.Add(this.dtpEnd);
            this.Controls.Add(this.dtpStart);
            this.Controls.Add(this.lblEmployeeID);
            this.Controls.Add(this.lblUsernamePassed);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnTraining);
            this.Controls.Add(this.btnBenefits);
            this.Controls.Add(this.btnPayroll);
            this.Controls.Add(this.btnHiringAndFiring);
            this.Controls.Add(this.btnBookTravel);
            this.Controls.Add(this.lblWhatToDo);
            this.Controls.Add(this.lblOpenTicket);
            this.Controls.Add(this.btnFileExpenses);
            this.Name = "Form1";
            this.Text = "Open a New Ticket";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnTraining;
        private System.Windows.Forms.Button btnBenefits;
        private System.Windows.Forms.Button btnPayroll;
        private System.Windows.Forms.Button btnFileExpenses;
        private System.Windows.Forms.Button btnHiringAndFiring;
        private System.Windows.Forms.Button btnBookTravel;
        private System.Windows.Forms.Label lblWhatToDo;
        private System.Windows.Forms.Label lblOpenTicket;
        private System.Windows.Forms.Label lblUsernamePassed;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.Label lblStartTime;
        private System.Windows.Forms.Label lblEndTime;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtTimeWorked;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button btnLogout;
    }
}

