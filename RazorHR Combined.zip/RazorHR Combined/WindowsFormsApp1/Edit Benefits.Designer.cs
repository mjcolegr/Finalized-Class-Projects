﻿
namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnUpdateBenefits = new System.Windows.Forms.Button();
            this.txtSD = new System.Windows.Forms.TextBox();
            this.txtFL = new System.Windows.Forms.TextBox();
            this.txtVP = new System.Windows.Forms.TextBox();
            this.txtDental = new System.Windows.Forms.TextBox();
            this.txtHealth = new System.Windows.Forms.TextBox();
            this.lblSD = new System.Windows.Forms.Label();
            this.lblFL = new System.Windows.Forms.Label();
            this.lblVisionPlan = new System.Windows.Forms.Label();
            this.lblDental = new System.Windows.Forms.Label();
            this.lblHealthcare = new System.Windows.Forms.Label();
            this.lblViewingBenefitsForUser = new System.Windows.Forms.Label();
            this.lblEditBenefits = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.employeeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.iSYS4283SP22T14DataSet3 = new WindowsFormsApp1.ISYS4283SP22T14DataSet3();
            this.txtPTO = new System.Windows.Forms.TextBox();
            this.lblPTO = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picHealthcare = new System.Windows.Forms.PictureBox();
            this.iSYS4283SP22T14DataSet = new WindowsFormsApp1.ISYS4283SP22T14DataSet();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeTableAdapter = new WindowsFormsApp1.ISYS4283SP22T14DataSetTableAdapters.EmployeeTableAdapter();
            this.employeeTableAdapter1 = new WindowsFormsApp1.ISYS4283SP22T14DataSet3TableAdapters.EmployeeTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSYS4283SP22T14DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHealthcare)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSYS4283SP22T14DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUpdateBenefits
            // 
            this.btnUpdateBenefits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnUpdateBenefits.Font = new System.Drawing.Font("Segoe UI Semilight", 14F);
            this.btnUpdateBenefits.Location = new System.Drawing.Point(505, 547);
            this.btnUpdateBenefits.Name = "btnUpdateBenefits";
            this.btnUpdateBenefits.Size = new System.Drawing.Size(191, 37);
            this.btnUpdateBenefits.TabIndex = 47;
            this.btnUpdateBenefits.Text = "Update Benefits";
            this.btnUpdateBenefits.UseVisualStyleBackColor = false;
            this.btnUpdateBenefits.Click += new System.EventHandler(this.btnUpdateBenefits_Click);
            // 
            // txtSD
            // 
            this.txtSD.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSD.Location = new System.Drawing.Point(247, 421);
            this.txtSD.Multiline = true;
            this.txtSD.Name = "txtSD";
            this.txtSD.Size = new System.Drawing.Size(450, 29);
            this.txtSD.TabIndex = 41;
            // 
            // txtFL
            // 
            this.txtFL.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFL.Location = new System.Drawing.Point(247, 356);
            this.txtFL.Multiline = true;
            this.txtFL.Name = "txtFL";
            this.txtFL.Size = new System.Drawing.Size(450, 29);
            this.txtFL.TabIndex = 40;
            // 
            // txtVP
            // 
            this.txtVP.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVP.Location = new System.Drawing.Point(247, 285);
            this.txtVP.Multiline = true;
            this.txtVP.Name = "txtVP";
            this.txtVP.Size = new System.Drawing.Size(450, 29);
            this.txtVP.TabIndex = 39;
            // 
            // txtDental
            // 
            this.txtDental.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDental.Location = new System.Drawing.Point(247, 216);
            this.txtDental.Multiline = true;
            this.txtDental.Name = "txtDental";
            this.txtDental.Size = new System.Drawing.Size(450, 29);
            this.txtDental.TabIndex = 38;
            // 
            // txtHealth
            // 
            this.txtHealth.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHealth.Location = new System.Drawing.Point(247, 150);
            this.txtHealth.Multiline = true;
            this.txtHealth.Name = "txtHealth";
            this.txtHealth.Size = new System.Drawing.Size(450, 29);
            this.txtHealth.TabIndex = 37;
            // 
            // lblSD
            // 
            this.lblSD.AutoSize = true;
            this.lblSD.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblSD.Location = new System.Drawing.Point(120, 418);
            this.lblSD.Name = "lblSD";
            this.lblSD.Size = new System.Drawing.Size(111, 32);
            this.lblSD.TabIndex = 36;
            this.lblSD.Text = "Sick Days";
            // 
            // lblFL
            // 
            this.lblFL.AutoSize = true;
            this.lblFL.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblFL.Location = new System.Drawing.Point(88, 353);
            this.lblFL.Name = "lblFL";
            this.lblFL.Size = new System.Drawing.Size(143, 32);
            this.lblFL.TabIndex = 35;
            this.lblFL.Text = "Family Leave";
            // 
            // lblVisionPlan
            // 
            this.lblVisionPlan.AutoSize = true;
            this.lblVisionPlan.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblVisionPlan.Location = new System.Drawing.Point(104, 282);
            this.lblVisionPlan.Name = "lblVisionPlan";
            this.lblVisionPlan.Size = new System.Drawing.Size(127, 32);
            this.lblVisionPlan.TabIndex = 34;
            this.lblVisionPlan.Text = "Vision Plan";
            // 
            // lblDental
            // 
            this.lblDental.AutoSize = true;
            this.lblDental.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblDental.Location = new System.Drawing.Point(149, 214);
            this.lblDental.Name = "lblDental";
            this.lblDental.Size = new System.Drawing.Size(82, 32);
            this.lblDental.TabIndex = 33;
            this.lblDental.Text = "Dental";
            // 
            // lblHealthcare
            // 
            this.lblHealthcare.AutoSize = true;
            this.lblHealthcare.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblHealthcare.Location = new System.Drawing.Point(106, 147);
            this.lblHealthcare.Name = "lblHealthcare";
            this.lblHealthcare.Size = new System.Drawing.Size(125, 32);
            this.lblHealthcare.TabIndex = 32;
            this.lblHealthcare.Text = "Healthcare";
            // 
            // lblViewingBenefitsForUser
            // 
            this.lblViewingBenefitsForUser.AutoSize = true;
            this.lblViewingBenefitsForUser.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblViewingBenefitsForUser.Location = new System.Drawing.Point(23, 77);
            this.lblViewingBenefitsForUser.Name = "lblViewingBenefitsForUser";
            this.lblViewingBenefitsForUser.Size = new System.Drawing.Size(277, 32);
            this.lblViewingBenefitsForUser.TabIndex = 30;
            this.lblViewingBenefitsForUser.Text = "Viewing benefits for user ";
            // 
            // lblEditBenefits
            // 
            this.lblEditBenefits.AutoSize = true;
            this.lblEditBenefits.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditBenefits.Location = new System.Drawing.Point(21, 12);
            this.lblEditBenefits.Name = "lblEditBenefits";
            this.lblEditBenefits.Size = new System.Drawing.Size(205, 47);
            this.lblEditBenefits.TabIndex = 29;
            this.lblEditBenefits.Text = "Edit Benefits";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.White;
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(297, 76);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(149, 33);
            this.comboBox1.TabIndex = 48;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
            // 
            // employeeBindingSource1
            // 
            this.employeeBindingSource1.DataMember = "Employee";
            this.employeeBindingSource1.DataSource = this.iSYS4283SP22T14DataSet3;
            // 
            // iSYS4283SP22T14DataSet3
            // 
            this.iSYS4283SP22T14DataSet3.DataSetName = "ISYS4283SP22T14DataSet3";
            this.iSYS4283SP22T14DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtPTO
            // 
            this.txtPTO.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPTO.Location = new System.Drawing.Point(247, 490);
            this.txtPTO.Multiline = true;
            this.txtPTO.Name = "txtPTO";
            this.txtPTO.Size = new System.Drawing.Size(450, 29);
            this.txtPTO.TabIndex = 49;
            // 
            // lblPTO
            // 
            this.lblPTO.AutoSize = true;
            this.lblPTO.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblPTO.Location = new System.Drawing.Point(78, 487);
            this.lblPTO.Name = "lblPTO";
            this.lblPTO.Size = new System.Drawing.Size(153, 32);
            this.lblPTO.TabIndex = 50;
            this.lblPTO.Text = "Paid Time Off";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.pictureBox5.Image = global::WindowsFormsApp1.Properties.Resources.outline_bedtime_off_black_24dp;
            this.pictureBox5.Location = new System.Drawing.Point(28, 487);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(49, 42);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 55;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.pictureBox4.Image = global::WindowsFormsApp1.Properties.Resources.outline_sick_black_24dp;
            this.pictureBox4.Location = new System.Drawing.Point(28, 418);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(49, 42);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 54;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.pictureBox3.Image = global::WindowsFormsApp1.Properties.Resources.people;
            this.pictureBox3.Location = new System.Drawing.Point(28, 353);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 42);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 53;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.pictureBox2.Image = global::WindowsFormsApp1.Properties.Resources.outline_remove_red_eye_black_48dp1;
            this.pictureBox2.Location = new System.Drawing.Point(28, 282);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(49, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 52;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.outline_emoji_emotions_black_24dp;
            this.pictureBox1.Location = new System.Drawing.Point(28, 212);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 51;
            this.pictureBox1.TabStop = false;
            // 
            // picHealthcare
            // 
            this.picHealthcare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.picHealthcare.Image = global::WindowsFormsApp1.Properties.Resources.outline_health_and_safety_black_48dp;
            this.picHealthcare.Location = new System.Drawing.Point(28, 147);
            this.picHealthcare.Name = "picHealthcare";
            this.picHealthcare.Size = new System.Drawing.Size(49, 42);
            this.picHealthcare.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picHealthcare.TabIndex = 42;
            this.picHealthcare.TabStop = false;
            // 
            // iSYS4283SP22T14DataSet
            // 
            this.iSYS4283SP22T14DataSet.DataSetName = "ISYS4283SP22T14DataSet";
            this.iSYS4283SP22T14DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.iSYS4283SP22T14DataSet;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // employeeTableAdapter1
            // 
            this.employeeTableAdapter1.ClearBeforeFill = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(202)))), ((int)(((byte)(230)))));
            this.ClientSize = new System.Drawing.Size(741, 607);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblPTO);
            this.Controls.Add(this.txtPTO);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnUpdateBenefits);
            this.Controls.Add(this.picHealthcare);
            this.Controls.Add(this.txtSD);
            this.Controls.Add(this.txtFL);
            this.Controls.Add(this.txtVP);
            this.Controls.Add(this.txtDental);
            this.Controls.Add(this.txtHealth);
            this.Controls.Add(this.lblSD);
            this.Controls.Add(this.lblFL);
            this.Controls.Add(this.lblVisionPlan);
            this.Controls.Add(this.lblDental);
            this.Controls.Add(this.lblHealthcare);
            this.Controls.Add(this.lblViewingBenefitsForUser);
            this.Controls.Add(this.lblEditBenefits);
            this.Name = "Form3";
            this.Text = "Benefits";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSYS4283SP22T14DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHealthcare)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSYS4283SP22T14DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateBenefits;
        private System.Windows.Forms.PictureBox picHealthcare;
        private System.Windows.Forms.TextBox txtSD;
        private System.Windows.Forms.TextBox txtFL;
        private System.Windows.Forms.TextBox txtVP;
        private System.Windows.Forms.TextBox txtDental;
        private System.Windows.Forms.TextBox txtHealth;
        private System.Windows.Forms.Label lblSD;
        private System.Windows.Forms.Label lblFL;
        private System.Windows.Forms.Label lblVisionPlan;
        private System.Windows.Forms.Label lblDental;
        private System.Windows.Forms.Label lblHealthcare;
        private System.Windows.Forms.Label lblViewingBenefitsForUser;
        private System.Windows.Forms.Label lblEditBenefits;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txtPTO;
        private System.Windows.Forms.Label lblPTO;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private ISYS4283SP22T14DataSet iSYS4283SP22T14DataSet;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private ISYS4283SP22T14DataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private ISYS4283SP22T14DataSet3 iSYS4283SP22T14DataSet3;
        private System.Windows.Forms.BindingSource employeeBindingSource1;
        private ISYS4283SP22T14DataSet3TableAdapters.EmployeeTableAdapter employeeTableAdapter1;
    }
}