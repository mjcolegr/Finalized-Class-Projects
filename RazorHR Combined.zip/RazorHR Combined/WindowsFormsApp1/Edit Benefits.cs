﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;
        string connectionstring = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1";
        public Form3()
        {
            InitializeComponent();
        }

        


        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex > -1)
            {
                
                connection = new SqlConnection(connectionstring);
                connection.Open();
                string sql = "SELECT Employee_ID FROM Benefits";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                
                connection.Close();
                datareader.Close();
                command.Dispose();

                {
                    //selects all the attributes from our SQL table about the character that was selected from the combo box
                    connection.Open();
                    sql = "SELECT Healthcare, Dental, Vision_Plan, Family_Leave, Sick_Days, Paid_Time_Off FROM Benefits WHERE Employee_ID = ('" + comboBox1.SelectedItem.ToString() + "')";
                    command = new SqlCommand(sql, connection);
                    datareader = command.ExecuteReader();
                    while (datareader.Read())
                    {
                        txtHealth.Text = datareader[0].ToString();
                        txtDental.Text = datareader[1].ToString();
                        txtVP.Text = datareader[2].ToString();
                        txtFL.Text = datareader[3].ToString();
                        txtSD.Text = datareader[4].ToString();
                        txtPTO.Text = datareader[5].ToString();
                    }
                    connection.Close();
                    datareader.Close();
                    command.Dispose();
                }
            }
            else
            {

            }
        }

        private void btnUpdateBenefits_Click(object sender, EventArgs e)
        {
            try
            {
                connection = new SqlConnection(connectionstring);
                connection.Open();
                int answer;
                string sql = "UPDATE Benefits SET Healthcare = @HC, Vision_Plan = @VP, Dental = @Dental, Family_Leave = @FL, Sick_Days = @SD, Paid_Time_Off = @PTO WHERE Employee_ID = " + comboBox1.SelectedItem.ToString();
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@HC", txtHealth.Text);
                command.Parameters.AddWithValue("@VP", txtVP.Text);
                command.Parameters.AddWithValue("@Dental", txtDental.Text);
                command.Parameters.AddWithValue("@FL", txtFL.Text);
                command.Parameters.AddWithValue("@SD", txtSD.Text);
                command.Parameters.AddWithValue("@PTO", txtPTO.Text);

                answer = command.ExecuteNonQuery();

                connection.Close();
                connection.Dispose();
                MessageBox.Show("You have successfully updated " + answer + " in the Benefits database.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "SELECT Employee_ID FROM Benefits";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                comboBox1.Items.Add(datareader[0].ToString());
            }
            connection.Close();
            datareader.Close();
            command.Dispose();
        }
    }
}
