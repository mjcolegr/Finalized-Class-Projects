﻿
namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnSubmitHire = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtTerminateQ2 = new System.Windows.Forms.TextBox();
            this.txtTerminateQ1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTerminateQ2 = new System.Windows.Forms.Label();
            this.lblTerminateQ1 = new System.Windows.Forms.Label();
            this.txtHireQ4 = new System.Windows.Forms.TextBox();
            this.txtHireQ3 = new System.Windows.Forms.TextBox();
            this.txtHireQ2 = new System.Windows.Forms.TextBox();
            this.txtHireQ1 = new System.Windows.Forms.TextBox();
            this.lblHireQ4 = new System.Windows.Forms.Label();
            this.lblHireQ3 = new System.Windows.Forms.Label();
            this.lblHireQ2 = new System.Windows.Forms.Label();
            this.lblHireQ1 = new System.Windows.Forms.Label();
            this.lblTerminateAnEmployee = new System.Windows.Forms.Label();
            this.lblHireanEmployee = new System.Windows.Forms.Label();
            this.lblRequestHireFire = new System.Windows.Forms.Label();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.lblUsernamePassed = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(542, 481);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(226, 36);
            this.button1.TabIndex = 53;
            this.button1.Text = "Submit Termination Request";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSubmitHire
            // 
            this.btnSubmitHire.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnSubmitHire.Font = new System.Drawing.Font("Segoe UI Semibold", 12F);
            this.btnSubmitHire.ForeColor = System.Drawing.Color.White;
            this.btnSubmitHire.Location = new System.Drawing.Point(84, 481);
            this.btnSubmitHire.Name = "btnSubmitHire";
            this.btnSubmitHire.Size = new System.Drawing.Size(226, 36);
            this.btnSubmitHire.TabIndex = 52;
            this.btnSubmitHire.Text = "Submit Hiring Request";
            this.btnSubmitHire.UseVisualStyleBackColor = false;
            this.btnSubmitHire.Click += new System.EventHandler(this.btnSubmitHire_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(483, 332);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(350, 29);
            this.dateTimePicker1.TabIndex = 51;
            // 
            // txtTerminateQ2
            // 
            this.txtTerminateQ2.Location = new System.Drawing.Point(483, 250);
            this.txtTerminateQ2.Multiline = true;
            this.txtTerminateQ2.Name = "txtTerminateQ2";
            this.txtTerminateQ2.ReadOnly = true;
            this.txtTerminateQ2.Size = new System.Drawing.Size(347, 40);
            this.txtTerminateQ2.TabIndex = 47;
            // 
            // txtTerminateQ1
            // 
            this.txtTerminateQ1.Location = new System.Drawing.Point(483, 173);
            this.txtTerminateQ1.Multiline = true;
            this.txtTerminateQ1.Name = "txtTerminateQ1";
            this.txtTerminateQ1.Size = new System.Drawing.Size(347, 40);
            this.txtTerminateQ1.TabIndex = 46;
            this.txtTerminateQ1.TextChanged += new System.EventHandler(this.txtTerminateQ1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(479, 307);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 21);
            this.label3.TabIndex = 45;
            this.label3.Text = "Schedule a meeting with HR";
            // 
            // lblTerminateQ2
            // 
            this.lblTerminateQ2.AutoSize = true;
            this.lblTerminateQ2.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTerminateQ2.Location = new System.Drawing.Point(479, 226);
            this.lblTerminateQ2.Name = "lblTerminateQ2";
            this.lblTerminateQ2.Size = new System.Drawing.Size(346, 21);
            this.lblTerminateQ2.TabIndex = 44;
            this.lblTerminateQ2.Text = "Provide reasoning for terminating this employee. ";
            // 
            // lblTerminateQ1
            // 
            this.lblTerminateQ1.AutoSize = true;
            this.lblTerminateQ1.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTerminateQ1.Location = new System.Drawing.Point(479, 149);
            this.lblTerminateQ1.Name = "lblTerminateQ1";
            this.lblTerminateQ1.Size = new System.Drawing.Size(121, 21);
            this.lblTerminateQ1.TabIndex = 43;
            this.lblTerminateQ1.Text = "Employee Name";
            // 
            // txtHireQ4
            // 
            this.txtHireQ4.Location = new System.Drawing.Point(19, 409);
            this.txtHireQ4.Multiline = true;
            this.txtHireQ4.Name = "txtHireQ4";
            this.txtHireQ4.ReadOnly = true;
            this.txtHireQ4.Size = new System.Drawing.Size(373, 40);
            this.txtHireQ4.TabIndex = 39;
            // 
            // txtHireQ3
            // 
            this.txtHireQ3.Location = new System.Drawing.Point(19, 332);
            this.txtHireQ3.Multiline = true;
            this.txtHireQ3.Name = "txtHireQ3";
            this.txtHireQ3.ReadOnly = true;
            this.txtHireQ3.Size = new System.Drawing.Size(373, 40);
            this.txtHireQ3.TabIndex = 38;
            this.txtHireQ3.TextChanged += new System.EventHandler(this.txtHireQ3_TextChanged);
            // 
            // txtHireQ2
            // 
            this.txtHireQ2.Location = new System.Drawing.Point(19, 251);
            this.txtHireQ2.Multiline = true;
            this.txtHireQ2.Name = "txtHireQ2";
            this.txtHireQ2.ReadOnly = true;
            this.txtHireQ2.Size = new System.Drawing.Size(373, 40);
            this.txtHireQ2.TabIndex = 37;
            this.txtHireQ2.TextChanged += new System.EventHandler(this.txtHireQ2_TextChanged);
            // 
            // txtHireQ1
            // 
            this.txtHireQ1.Location = new System.Drawing.Point(19, 174);
            this.txtHireQ1.Multiline = true;
            this.txtHireQ1.Name = "txtHireQ1";
            this.txtHireQ1.Size = new System.Drawing.Size(373, 40);
            this.txtHireQ1.TabIndex = 36;
            this.txtHireQ1.TextChanged += new System.EventHandler(this.txtHireQ1_TextChanged);
            // 
            // lblHireQ4
            // 
            this.lblHireQ4.AutoSize = true;
            this.lblHireQ4.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHireQ4.Location = new System.Drawing.Point(15, 385);
            this.lblHireQ4.Name = "lblHireQ4";
            this.lblHireQ4.Size = new System.Drawing.Size(122, 21);
            this.lblHireQ4.TabIndex = 35;
            this.lblHireQ4.Text = "Estimated Salary";
            // 
            // lblHireQ3
            // 
            this.lblHireQ3.AutoSize = true;
            this.lblHireQ3.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHireQ3.Location = new System.Drawing.Point(15, 308);
            this.lblHireQ3.Name = "lblHireQ3";
            this.lblHireQ3.Size = new System.Drawing.Size(377, 21);
            this.lblHireQ3.TabIndex = 34;
            this.lblHireQ3.Text = "Names of prospective employees (internal or external)";
            // 
            // lblHireQ2
            // 
            this.lblHireQ2.AutoSize = true;
            this.lblHireQ2.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHireQ2.Location = new System.Drawing.Point(15, 227);
            this.lblHireQ2.Name = "lblHireQ2";
            this.lblHireQ2.Size = new System.Drawing.Size(304, 21);
            this.lblHireQ2.TabIndex = 33;
            this.lblHireQ2.Text = "Why does this team need a new employee?";
            // 
            // lblHireQ1
            // 
            this.lblHireQ1.AutoSize = true;
            this.lblHireQ1.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHireQ1.Location = new System.Drawing.Point(15, 150);
            this.lblHireQ1.Name = "lblHireQ1";
            this.lblHireQ1.Size = new System.Drawing.Size(251, 21);
            this.lblHireQ1.TabIndex = 32;
            this.lblHireQ1.Text = "What team needs a new employee?";
            // 
            // lblTerminateAnEmployee
            // 
            this.lblTerminateAnEmployee.AutoSize = true;
            this.lblTerminateAnEmployee.Font = new System.Drawing.Font("Segoe UI Semilight", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTerminateAnEmployee.Location = new System.Drawing.Point(478, 87);
            this.lblTerminateAnEmployee.Name = "lblTerminateAnEmployee";
            this.lblTerminateAnEmployee.Size = new System.Drawing.Size(229, 30);
            this.lblTerminateAnEmployee.TabIndex = 31;
            this.lblTerminateAnEmployee.Text = "Terminate an Employee";
            // 
            // lblHireanEmployee
            // 
            this.lblHireanEmployee.AutoSize = true;
            this.lblHireanEmployee.Font = new System.Drawing.Font("Segoe UI Semilight", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHireanEmployee.Location = new System.Drawing.Point(14, 87);
            this.lblHireanEmployee.Name = "lblHireanEmployee";
            this.lblHireanEmployee.Size = new System.Drawing.Size(176, 30);
            this.lblHireanEmployee.TabIndex = 30;
            this.lblHireanEmployee.Text = "Hire an Employee";
            // 
            // lblRequestHireFire
            // 
            this.lblRequestHireFire.AutoSize = true;
            this.lblRequestHireFire.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRequestHireFire.Location = new System.Drawing.Point(11, 13);
            this.lblRequestHireFire.Name = "lblRequestHireFire";
            this.lblRequestHireFire.Size = new System.Drawing.Size(655, 47);
            this.lblRequestHireFire.TabIndex = 29;
            this.lblRequestHireFire.Text = "Request to Hire or Terminate an Employee";
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeID.Location = new System.Drawing.Point(854, 554);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeID.Size = new System.Drawing.Size(199, 21);
            this.lblEmployeeID.TabIndex = 97;
            this.lblEmployeeID.Text = "employee id (auto-updates)";
            this.lblEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUsernamePassed
            // 
            this.lblUsernamePassed.AutoSize = true;
            this.lblUsernamePassed.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsernamePassed.Location = new System.Drawing.Point(790, 554);
            this.lblUsernamePassed.Name = "lblUsernamePassed";
            this.lblUsernamePassed.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblUsernamePassed.Size = new System.Drawing.Size(67, 21);
            this.lblUsernamePassed.TabIndex = 96;
            this.lblUsernamePassed.Text = "User ID:";
            this.lblUsernamePassed.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(19, 554);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 98;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.button2.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.button2.Location = new System.Drawing.Point(816, 494);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 44);
            this.button2.TabIndex = 111;
            this.button2.Text = "Home";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.pictureBox6.Image = global::WindowsFormsApp1.Properties.Resources.home_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox6.Location = new System.Drawing.Point(877, 497);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(29, 37);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 112;
            this.pictureBox6.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(202)))), ((int)(((byte)(230)))));
            this.ClientSize = new System.Drawing.Size(1066, 602);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.lblEmployeeID);
            this.Controls.Add(this.lblUsernamePassed);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSubmitHire);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtTerminateQ2);
            this.Controls.Add(this.txtTerminateQ1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblTerminateQ2);
            this.Controls.Add(this.lblTerminateQ1);
            this.Controls.Add(this.txtHireQ4);
            this.Controls.Add(this.txtHireQ3);
            this.Controls.Add(this.txtHireQ2);
            this.Controls.Add(this.txtHireQ1);
            this.Controls.Add(this.lblHireQ4);
            this.Controls.Add(this.lblHireQ3);
            this.Controls.Add(this.lblHireQ2);
            this.Controls.Add(this.lblHireQ1);
            this.Controls.Add(this.lblTerminateAnEmployee);
            this.Controls.Add(this.lblHireanEmployee);
            this.Controls.Add(this.lblRequestHireFire);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSubmitHire;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtTerminateQ2;
        private System.Windows.Forms.TextBox txtTerminateQ1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTerminateQ2;
        private System.Windows.Forms.Label lblTerminateQ1;
        private System.Windows.Forms.TextBox txtHireQ4;
        private System.Windows.Forms.TextBox txtHireQ3;
        private System.Windows.Forms.TextBox txtHireQ2;
        private System.Windows.Forms.TextBox txtHireQ1;
        private System.Windows.Forms.Label lblHireQ4;
        private System.Windows.Forms.Label lblHireQ3;
        private System.Windows.Forms.Label lblHireQ2;
        private System.Windows.Forms.Label lblHireQ1;
        private System.Windows.Forms.Label lblTerminateAnEmployee;
        private System.Windows.Forms.Label lblHireanEmployee;
        private System.Windows.Forms.Label lblRequestHireFire;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.Label lblUsernamePassed;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button button2;
    }
}