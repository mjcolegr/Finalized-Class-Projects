﻿
namespace WindowsFormsApp1
{
    partial class Training
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblPopUpTravel = new System.Windows.Forms.Label();
            this.btnSubmitRequest = new System.Windows.Forms.Button();
            this.lblTravelNeeded = new System.Windows.Forms.Label();
            this.rdoNo = new System.Windows.Forms.RadioButton();
            this.rdoYes = new System.Windows.Forms.RadioButton();
            this.txtResourcesExplain = new System.Windows.Forms.TextBox();
            this.lblResourcesExplain = new System.Windows.Forms.Label();
            this.lblRequestAdditional = new System.Windows.Forms.Label();
            this.lblAssignedTraining = new System.Windows.Forms.Label();
            this.btnAccessTraining = new System.Windows.Forms.Button();
            this.lblTraining = new System.Windows.Forms.Label();
            this.picLinkedIn = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.lblUsernamePassed = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dgvAssignedTrainings = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.picLinkedIn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssignedTrainings)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPopUpTravel
            // 
            this.lblPopUpTravel.AutoSize = true;
            this.lblPopUpTravel.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopUpTravel.Location = new System.Drawing.Point(736, 492);
            this.lblPopUpTravel.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblPopUpTravel.Name = "lblPopUpTravel";
            this.lblPopUpTravel.Size = new System.Drawing.Size(283, 63);
            this.lblPopUpTravel.TabIndex = 49;
            this.lblPopUpTravel.Text = "If travel is needed, a travel request will also need to be completed. A pop-up bo" +
    "x will appear to fill out.";
            // 
            // btnSubmitRequest
            // 
            this.btnSubmitRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btnSubmitRequest.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitRequest.Location = new System.Drawing.Point(765, 440);
            this.btnSubmitRequest.Name = "btnSubmitRequest";
            this.btnSubmitRequest.Size = new System.Drawing.Size(226, 36);
            this.btnSubmitRequest.TabIndex = 48;
            this.btnSubmitRequest.Text = "Submit Request";
            this.btnSubmitRequest.UseVisualStyleBackColor = false;
            this.btnSubmitRequest.Click += new System.EventHandler(this.btnSubmitRequest_Click);
            // 
            // lblTravelNeeded
            // 
            this.lblTravelNeeded.AutoSize = true;
            this.lblTravelNeeded.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTravelNeeded.Location = new System.Drawing.Point(702, 357);
            this.lblTravelNeeded.Name = "lblTravelNeeded";
            this.lblTravelNeeded.Size = new System.Drawing.Size(114, 21);
            this.lblTravelNeeded.TabIndex = 47;
            this.lblTravelNeeded.Text = "Travel Needed?";
            // 
            // rdoNo
            // 
            this.rdoNo.AutoSize = true;
            this.rdoNo.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoNo.Location = new System.Drawing.Point(765, 381);
            this.rdoNo.Name = "rdoNo";
            this.rdoNo.Size = new System.Drawing.Size(49, 25);
            this.rdoNo.TabIndex = 46;
            this.rdoNo.TabStop = true;
            this.rdoNo.Text = "No";
            this.rdoNo.UseVisualStyleBackColor = true;
            // 
            // rdoYes
            // 
            this.rdoYes.AutoSize = true;
            this.rdoYes.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoYes.Location = new System.Drawing.Point(708, 380);
            this.rdoYes.Name = "rdoYes";
            this.rdoYes.Size = new System.Drawing.Size(51, 25);
            this.rdoYes.TabIndex = 45;
            this.rdoYes.TabStop = true;
            this.rdoYes.Text = "Yes";
            this.rdoYes.UseVisualStyleBackColor = true;
            // 
            // txtResourcesExplain
            // 
            this.txtResourcesExplain.Location = new System.Drawing.Point(706, 248);
            this.txtResourcesExplain.Multiline = true;
            this.txtResourcesExplain.Name = "txtResourcesExplain";
            this.txtResourcesExplain.Size = new System.Drawing.Size(347, 94);
            this.txtResourcesExplain.TabIndex = 44;
            // 
            // lblResourcesExplain
            // 
            this.lblResourcesExplain.AutoSize = true;
            this.lblResourcesExplain.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResourcesExplain.Location = new System.Drawing.Point(702, 224);
            this.lblResourcesExplain.Name = "lblResourcesExplain";
            this.lblResourcesExplain.Size = new System.Drawing.Size(300, 21);
            this.lblResourcesExplain.TabIndex = 43;
            this.lblResourcesExplain.Text = "Provide explaination for resources needed:";
            // 
            // lblRequestAdditional
            // 
            this.lblRequestAdditional.AutoSize = true;
            this.lblRequestAdditional.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblRequestAdditional.Location = new System.Drawing.Point(700, 173);
            this.lblRequestAdditional.Name = "lblRequestAdditional";
            this.lblRequestAdditional.Size = new System.Drawing.Size(296, 32);
            this.lblRequestAdditional.TabIndex = 42;
            this.lblRequestAdditional.Text = "Request Additional Training";
            // 
            // lblAssignedTraining
            // 
            this.lblAssignedTraining.AutoSize = true;
            this.lblAssignedTraining.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblAssignedTraining.Location = new System.Drawing.Point(10, 113);
            this.lblAssignedTraining.Name = "lblAssignedTraining";
            this.lblAssignedTraining.Size = new System.Drawing.Size(205, 32);
            this.lblAssignedTraining.TabIndex = 40;
            this.lblAssignedTraining.Text = "Assigned Trainings";
            // 
            // btnAccessTraining
            // 
            this.btnAccessTraining.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.btnAccessTraining.Font = new System.Drawing.Font("Segoe UI Semilight", 14F);
            this.btnAccessTraining.Location = new System.Drawing.Point(114, 469);
            this.btnAccessTraining.Name = "btnAccessTraining";
            this.btnAccessTraining.Size = new System.Drawing.Size(417, 65);
            this.btnAccessTraining.TabIndex = 36;
            this.btnAccessTraining.Text = "To access more training via LinkedIn Learning, click here.";
            this.btnAccessTraining.UseVisualStyleBackColor = false;
            this.btnAccessTraining.Click += new System.EventHandler(this.btnAccessTraining_Click);
            // 
            // lblTraining
            // 
            this.lblTraining.AutoSize = true;
            this.lblTraining.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTraining.Location = new System.Drawing.Point(8, 11);
            this.lblTraining.Name = "lblTraining";
            this.lblTraining.Size = new System.Drawing.Size(139, 47);
            this.lblTraining.TabIndex = 33;
            this.lblTraining.Text = "Training";
            // 
            // picLinkedIn
            // 
            this.picLinkedIn.Image = global::WindowsFormsApp1.Properties.Resources._768px_LinkedIn_logo_initials;
            this.picLinkedIn.Location = new System.Drawing.Point(19, 469);
            this.picLinkedIn.Name = "picLinkedIn";
            this.picLinkedIn.Size = new System.Drawing.Size(69, 65);
            this.picLinkedIn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLinkedIn.TabIndex = 41;
            this.picLinkedIn.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.pictureBox6.Image = global::WindowsFormsApp1.Properties.Resources.home_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox6.Location = new System.Drawing.Point(1069, 561);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(29, 37);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 114;
            this.pictureBox6.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(183)))), ((int)(((byte)(3)))));
            this.button2.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.button2.Location = new System.Drawing.Point(1008, 558);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 44);
            this.button2.TabIndex = 113;
            this.button2.Text = "Home";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeID.Location = new System.Drawing.Point(76, 58);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeID.Size = new System.Drawing.Size(199, 21);
            this.lblEmployeeID.TabIndex = 116;
            this.lblEmployeeID.Text = "employee id (auto-updates)";
            this.lblEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUsernamePassed
            // 
            this.lblUsernamePassed.AutoSize = true;
            this.lblUsernamePassed.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsernamePassed.Location = new System.Drawing.Point(12, 58);
            this.lblUsernamePassed.Name = "lblUsernamePassed";
            this.lblUsernamePassed.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblUsernamePassed.Size = new System.Drawing.Size(67, 21);
            this.lblUsernamePassed.TabIndex = 115;
            this.lblUsernamePassed.Text = "User ID:";
            this.lblUsernamePassed.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(3000, 132);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 117;
            // 
            // dgvAssignedTrainings
            // 
            this.dgvAssignedTrainings.AllowUserToAddRows = false;
            this.dgvAssignedTrainings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvAssignedTrainings.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(48)))), ((int)(((byte)(71)))));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAssignedTrainings.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvAssignedTrainings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAssignedTrainings.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvAssignedTrainings.Location = new System.Drawing.Point(16, 158);
            this.dgvAssignedTrainings.Name = "dgvAssignedTrainings";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAssignedTrainings.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvAssignedTrainings.RowHeadersWidth = 30;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvAssignedTrainings.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvAssignedTrainings.RowTemplate.Height = 50;
            this.dgvAssignedTrainings.Size = new System.Drawing.Size(661, 305);
            this.dgvAssignedTrainings.TabIndex = 118;
            // 
            // Training
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(202)))), ((int)(((byte)(230)))));
            this.ClientSize = new System.Drawing.Size(1131, 645);
            this.Controls.Add(this.dgvAssignedTrainings);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblEmployeeID);
            this.Controls.Add(this.lblUsernamePassed);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lblPopUpTravel);
            this.Controls.Add(this.btnSubmitRequest);
            this.Controls.Add(this.lblTravelNeeded);
            this.Controls.Add(this.rdoNo);
            this.Controls.Add(this.rdoYes);
            this.Controls.Add(this.txtResourcesExplain);
            this.Controls.Add(this.lblResourcesExplain);
            this.Controls.Add(this.lblRequestAdditional);
            this.Controls.Add(this.picLinkedIn);
            this.Controls.Add(this.lblAssignedTraining);
            this.Controls.Add(this.btnAccessTraining);
            this.Controls.Add(this.lblTraining);
            this.Name = "Training";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Training_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLinkedIn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAssignedTrainings)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblPopUpTravel;
        private System.Windows.Forms.Button btnSubmitRequest;
        private System.Windows.Forms.Label lblTravelNeeded;
        private System.Windows.Forms.RadioButton rdoNo;
        private System.Windows.Forms.RadioButton rdoYes;
        private System.Windows.Forms.TextBox txtResourcesExplain;
        private System.Windows.Forms.Label lblResourcesExplain;
        private System.Windows.Forms.Label lblRequestAdditional;
        private System.Windows.Forms.PictureBox picLinkedIn;
        private System.Windows.Forms.Label lblAssignedTraining;
        private System.Windows.Forms.Button btnAccessTraining;
        private System.Windows.Forms.Label lblTraining;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.Label lblUsernamePassed;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dgvAssignedTrainings;
    }
}