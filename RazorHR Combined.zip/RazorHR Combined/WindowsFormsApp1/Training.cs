﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Training : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1;");
        SqlCommand cmd;
        SqlCommand cmd2;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public Training()
        {
            InitializeComponent();
            lblEmployeeID.Text = Form1.loggedinID;
            showdata();
            
        }

        private void btnAccessTraining_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.linkedin.com/learning/");
        }

        private void btnSubmitRequest_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Ticketing (Employee_ID, Ticket_Submission_Date, Ticket_Classification, Ticket_Description) VALUES (@Employee_ID, @SubmitDate, 'Training', @Description)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Employee_ID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@SubmitDate", dateTimePicker1.Value.ToString());
                cmd.Parameters.AddWithValue("@Description", txtResourcesExplain.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully submitted training request!", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please fill out the text box about your training request.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (rdoYes.Checked == true)
            {
                Trvlreqform F1 = new Trvlreqform();
                F1.Show();
            }
        }
            

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();
        }

        private void Training_Load(object sender, EventArgs e)
        {
            
        }
        public void showdata()
        {
            SqlConnection con = new SqlConnection("Data Source = essql1.walton.uark.edu; Initial Catalog = ISYS4283SP22T14; User ID = ISYS4283SP22T14; Password = GohogsUA1");
            SqlCommand cmd;
            SqlDataAdapter adpt;
            DataTable dt;

            adpt = new SqlDataAdapter("SELECT Topic, Link, Start_Date, End_Date, Description FROM Training WHERE Assigned_Employee_ID='" + lblEmployeeID.Text + "'", con);
            dt = new DataTable();

            adpt.Fill(dt);
            dgvAssignedTrainings.DataSource = dt;
        }
    }
}
