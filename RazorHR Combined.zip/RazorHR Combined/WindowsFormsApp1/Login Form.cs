﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        public static string username1;
        public Form4()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            username1 = txtuser.Text;
            
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1";
                con.Open();
                string username = txtuser.Text;
                string password = txtpass.Text;
                SqlCommand cmd = new SqlCommand("select Role from Login where Username='" + txtuser.Text + "' and Password='" + txtpass.Text + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                //if (dt.Rows.Count > 0)
                //{
                //    MessageBox.Show("Login Success Welcome to HR Solutions");


                //    Form1 F1 = new Form1();
                //    F1.Show();
                //    this.Hide();
                //}
                //else
                //{
                //    MessageBox.Show("Invalid Login! Please check username and password.");
                //}
                //con.Close();

                if (dt.Rows.Count == 1)
                {
                    switch (dt.Rows[0]["Role"] as string)
                    {
                        case "Admin":
                            {
                               AddEmployee ss = new AddEmployee();
                                ss.Show();
                                this.Hide();
                                break;
                            }

                        case "Vendor":
                            {
                                this.Hide();
                                AddTraining V = new AddTraining();
                                V.Show();
                                break;
                            }

                        case "HR Manager":
                            {
                                this.Hide();
                                Form5 HR = new Form5();
                                HR.Show();
                                break;
                            }

                        case "Employee":
                            {
                                this.Hide();
                                Form1 E = new Form1();
                                E.Show();
                                break;
                            }
                        default:
                            {
                                // ... handle unexpected roles here...
                                break;
                            }
                    }
                
                }
                else
                {
                    MessageBox.Show("Invalid Login! Please check username and password.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }

}

