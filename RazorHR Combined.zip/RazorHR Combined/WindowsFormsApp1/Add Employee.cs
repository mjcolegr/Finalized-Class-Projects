﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class AddEmployee : Form
    {
        SqlConnection con = new SqlConnection(@"data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22U58;User ID=ISYS4283SP22U58;password=GohogsUA1;");
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public AddEmployee()
        {
            InitializeComponent();
            showdata();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var myForm = new Form4();
            myForm.Show();
            this.Hide();
        }

        private void btnaddemployee_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Employee (Payroll_ID, Department_ID, Employee_First_Name, Employee_Last_Name, Title, Hire_Date) VALUES (@Payroll_ID, 1, @Employee_First_Name, @Employee_Last_Name, @Title, @Hire_Date)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Payroll_ID", txtpayrollid.Text);
                cmd.Parameters.AddWithValue("@Employee_First_Name", txtemployeefirst.Text);
                cmd.Parameters.AddWithValue("@Employee_Last_Name", txtlastemployee.Text);
                cmd.Parameters.AddWithValue("@Title", txtemployeetitle.Text);
                cmd.Parameters.AddWithValue("@Hire_Date", dtphire.Value.ToString());

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully added employee!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.");
            }

        }

        private void btnupdateemployee_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "UPDATE Employee SET Payroll_ID=@Payroll, Employee_First_Name=@FName, Employee_Last_Name=@LName, Title=@Title, Hire_Date=@HDate WHERE Employee_ID=@EID";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Payroll", txtpayrollid.Text);
                cmd.Parameters.AddWithValue("@FName", txtemployeefirst.Text);
                cmd.Parameters.AddWithValue("@LName", txtlastemployee.Text);
                cmd.Parameters.AddWithValue("@Title", txtemployeetitle.Text);
                cmd.Parameters.AddWithValue("@HDate", dtphire.Value.ToString());
                cmd.Parameters.AddWithValue("@EID", txtemployeeid.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully updated employee!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure the employee is selected from the grid view.");
            }
        }

        private void btndeleteemployee_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "DELETE FROM Employee WHERE Employee_ID=@EID";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@EID", txtemployeeid.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully deleted employee!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure the employee is selected from the grid view.");
            }

        }
        public void showdata()
        {
            SqlConnection con = new SqlConnection(@"data Source = essql1.walton.uark.edu; Initial Catalog = ISYS4283SP22T14; User ID = ISYS4283SP22T14; password = GohogsUA1;");
            SqlCommand cmd;
            SqlDataAdapter adpt;
            DataTable dt;

            adpt = new SqlDataAdapter("SELECT Employee_ID, Payroll_ID, Employee_First_Name AS [First Name], Employee_Last_Name AS [Last Name], Title, Hire_Date FROM Employee", con);
            dt = new DataTable();
            adpt.Fill(dt);
            dgvEmployees.DataSource = dt;
        }

        private void dgvEmployees_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                txtemployeeid.Text = dgvEmployees.CurrentRow.Cells[0].Value.ToString();
                txtpayrollid.Text = dgvEmployees.CurrentRow.Cells[1].Value.ToString();
                txtemployeefirst.Text = dgvEmployees.CurrentRow.Cells[2].Value.ToString();
                txtlastemployee.Text = dgvEmployees.CurrentRow.Cells[3].Value.ToString();
                txtemployeetitle.Text = dgvEmployees.CurrentRow.Cells[4].Value.ToString();
                dtphire.Text = dgvEmployees.CurrentRow.Cells[5].Value.ToString();
            }
        }

        private void AddEmployee_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'iSYS4283SP22T14DataSet2.LOGIN' table. You can move, or remove it, as needed.
            this.lOGINTableAdapter.Fill(this.iSYS4283SP22T14DataSet2.LOGIN);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                txtUsername.Text = dgvlogininfo.CurrentRow.Cells[0].Value.ToString();
                txtPassword.Text = dgvlogininfo.CurrentRow.Cells[1].Value.ToString();
                txtEmpID.Text = dgvlogininfo.CurrentRow.Cells[2].Value.ToString();
                txtRole.Text = dgvlogininfo.CurrentRow.Cells[3].Value.ToString();
                
            }
        }

        private void btnAddLogin_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Login VALUES (@User, @Pass, @Employee_ID, @Role)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@User", txtUsername.Text);
                cmd.Parameters.AddWithValue("@Pass", txtPassword.Text);
                cmd.Parameters.AddWithValue("@Employee_ID", txtEmpID.Text);
                cmd.Parameters.AddWithValue("@Role", txtRole.Text);
                
                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully added login!", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdateLogin_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "UPDATE Login SET Username=@User, Password=@Pass, Role=@Role WHERE Employee_ID=@EID";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@User", txtUsername.Text);
                cmd.Parameters.AddWithValue("@Pass", txtPassword.Text);
                cmd.Parameters.AddWithValue("@EID", txtEmpID.Text);
                cmd.Parameters.AddWithValue("@Role", txtRole.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully updated login!", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure the employee is selected from the grid view.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeleteLogin_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "DELETE FROM Login WHERE Employee_ID=@EID";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@EID", txtEmpID.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully deleted employee!", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure the employee is selected from the grid view.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    
}
