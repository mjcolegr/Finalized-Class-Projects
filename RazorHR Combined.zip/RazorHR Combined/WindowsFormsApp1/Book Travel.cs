﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Trvlreqform : Form
    {
        SqlConnection con = new SqlConnection(@"data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22U58;User ID=ISYS4283SP22U58;password=GohogsUA1;");
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public Trvlreqform()
        {
            InitializeComponent();
        }

        private void btnFrontier_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.flyfrontier.com");
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            lblEmployeeID.Text = Form1.loggedinID;
        }

        private void btnSubmitFlightRequest_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Airfare VALUES (@DepartDate, @ReturnDate, @DepartAirport, @ArrivalAirport, @EmployeeID, @Reasoning)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@DepartDate", dtpFlightDepart.Value.ToString());
                cmd.Parameters.AddWithValue("@ReturnDate", dtpFlightReturn.Value.ToString());
                cmd.Parameters.AddWithValue("@DepartAirport", txtDeparture.Text);
                cmd.Parameters.AddWithValue("@ArrivalAirport", txtArrival.Text);
                cmd.Parameters.AddWithValue("@EmployeeID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@Reasoning", txtReasoning.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully requested flight!", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSubmitRentalCarlRequest_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Rental_Car VALUES (@PickupDate, @ReturnDate, @PickupLocation, @ReturnLocation, @EmployeeID, @Reasoning)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@PickupDate", dtpCarPickup.Value.ToString());
                cmd.Parameters.AddWithValue("@ReturnDate", dtpCarReturn.Value.ToString());
                cmd.Parameters.AddWithValue("@PickupLocation", txtCarPickup.Text);
                cmd.Parameters.AddWithValue("@ReturnLocation", txtCarReturn.Text);
                cmd.Parameters.AddWithValue("@EmployeeID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@Reasoning", txtReasoning.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully requested rental car!", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSubmitHotelRequest_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Hotel VALUES (@ArrivalDate, @CheckoutDate, @Destination, @EmployeeID, @Reasoning)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@ArrivalDate", dtpHotelArrive.Value.ToString());
                cmd.Parameters.AddWithValue("@CheckoutDate", dtpHotelDepart.Value.ToString());
                cmd.Parameters.AddWithValue("@Destination", txtHotelDestination.Text);
                cmd.Parameters.AddWithValue("@EmployeeID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@Reasoning", txtReasoning.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully requested hotel!", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
