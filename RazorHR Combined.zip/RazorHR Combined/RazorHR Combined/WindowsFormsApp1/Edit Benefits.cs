﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;
        string connectionstring = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1";


        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql1 = "SELECT Healthcare, Vision_Plan, Dental, Family_Leave, Sick_Days, Paid_Time_Off FROM Benefits INNER JOIN EMPLOYEE ON Employee.Employee_ID = Benefits.Employee_ID WHERE Employee.Employee_ID = " + comboBox1.SelectedItem.ToString();
            command = new SqlCommand(sql1, connection);
            datareader = command.ExecuteReader();

            while (datareader.Read())
            {
                txtHealth.Text = datareader[0].ToString();
                txtDental.Text = datareader[2].ToString();
                txtVP.Text = datareader[1].ToString();
                txtFL.Text = datareader[3].ToString();
                txtSD.Text = datareader[4].ToString();
                txtPTO.Text = datareader[5].ToString();
            }
        }

        private void btnUpdateBenefits_Click(object sender, EventArgs e)
        {
            try
            {
                connection = new SqlConnection(connectionstring);
                connection.Open();
                int answer;
                string sql = "UPDATE Benefits SET Healthcare = @HC, Vision_Plan = @VP, Dental = @Dental, Family_Leave = @FL, Sick_Days = @SD, Paid_Time_Off = @PTO WHERE Employee_ID = " + comboBox1.SelectedItem.ToString();
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@HC", txtHealth.Text);
                command.Parameters.AddWithValue("@VP", txtVP.Text);
                command.Parameters.AddWithValue("@Dental", txtDental.Text);
                command.Parameters.AddWithValue("@FL", txtFL.Text);
                command.Parameters.AddWithValue("@SD", txtSD.Text);
                command.Parameters.AddWithValue("@PTO", txtPTO.Text);

                answer = command.ExecuteNonQuery();

                connection.Close();
                connection.Dispose();
                MessageBox.Show("You have successfully updated " + answer + " in the Benefits database.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! " + ex);
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'iSYS4283SP22T14DataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.iSYS4283SP22T14DataSet.Employee);

            //loads employee combobox
            string sql2 = "SELECT Employee_ID FROM EMPLOYEE";
            connection = new SqlConnection(connectionstring);
            connection.Open();
            SqlCommand cmd = new SqlCommand(sql2, connection);
            SqlDataReader DR = cmd.ExecuteReader();

            while (DR.Read())
            {
                comboBox1.Items.Add(DR[0]);
            }
            connection.Close();
        }

    }
}
