﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form6 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1;");
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public Form6()
        {
            InitializeComponent();
        }

        private void btnUploadReceipt_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://uark-my.sharepoint.com/:f:/g/personal/gerainwa_uark_edu/Ege2Ae0GVGBIu-juvruR7z8B6ygJ7SrH4Ol3FKzH4RPRTg?e=SDE5BK");
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            lblEmployeeID.Text = Form1.loggedinID;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1";
            con.Open();
            if (lblEmployeeID.Text != "")
            {
                SqlCommand cmd = new SqlCommand("SELECT Company_Card_Number, Amount_Loaded FROM Company_Card WHERE Employee_ID=@U", con);
                cmd.Parameters.AddWithValue("@U", lblEmployeeID.Text);
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    txtLastFourofCard.Text = da.GetValue(0).ToString();
                    txtCurrentBalance.Text = "$" + da.GetValue(1).ToString() + ".00";
                }
                con.Close();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();
        }

        private void btnSubmitExpense_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Expenses VALUES (@Transaction_Location, @Transaction_Date, @Transaction_Description, @Receipt_Link, @Employee_ID, @Amount)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Transaction_Location", txtExpenseDescription.Text);
                cmd.Parameters.AddWithValue("@Transaction_Date", dtpExpenseDate.Value.ToString());
                cmd.Parameters.AddWithValue("@Transaction_Description", txtExpenseDescription.Text);
                cmd.Parameters.AddWithValue("@Receipt_Link", txtReceiptLink.Text);
                cmd.Parameters.AddWithValue("@Employee_ID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@Amount", txtExpenseAmount.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully filed expense!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.");
            }
        }
    }
}
