﻿
namespace WindowsFormsApp1
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.txtlastemployee = new System.Windows.Forms.TextBox();
            this.txtemployeefirst = new System.Windows.Forms.TextBox();
            this.txtemployeetitle = new System.Windows.Forms.TextBox();
            this.txtpayrollid = new System.Windows.Forms.TextBox();
            this.txtemployeeid = new System.Windows.Forms.TextBox();
            this.lblemployeefirst = new System.Windows.Forms.Label();
            this.lblemployeelast = new System.Windows.Forms.Label();
            this.lblemployeetitle = new System.Windows.Forms.Label();
            this.lblhiredate = new System.Windows.Forms.Label();
            this.dtphire = new System.Windows.Forms.DateTimePicker();
            this.btnaddemployee = new System.Windows.Forms.Button();
            this.btnupdateemployee = new System.Windows.Forms.Button();
            this.btndeleteemployee = new System.Windows.Forms.Button();
            this.lblpayrollid = new System.Windows.Forms.Label();
            this.lblemployeeid = new System.Windows.Forms.Label();
            this.lblAddEmployee = new System.Windows.Forms.Label();
            this.dgvEmployees = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOGINBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iSYS4283SP22T14DataSet2 = new WindowsFormsApp1.ISYS4283SP22T14DataSet2();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtEmpID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUpdateLogin = new System.Windows.Forms.Button();
            this.btnAddLogin = new System.Windows.Forms.Button();
            this.lOGINTableAdapter = new WindowsFormsApp1.ISYS4283SP22T14DataSet2TableAdapters.LOGINTableAdapter();
            this.txtRole = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDeleteLogin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOGINBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSYS4283SP22T14DataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLogout
            // 
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI Semilight", 11F);
            this.btnLogout.Location = new System.Drawing.Point(1098, 28);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(87, 37);
            this.btnLogout.TabIndex = 43;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox7.Image = global::WindowsFormsApp1.Properties.Resources.logout_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox7.Location = new System.Drawing.Point(1067, 27);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(31, 38);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 42;
            this.pictureBox7.TabStop = false;
            // 
            // txtlastemployee
            // 
            this.txtlastemployee.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtlastemployee.Location = new System.Drawing.Point(181, 204);
            this.txtlastemployee.Multiline = true;
            this.txtlastemployee.Name = "txtlastemployee";
            this.txtlastemployee.Size = new System.Drawing.Size(233, 30);
            this.txtlastemployee.TabIndex = 98;
            // 
            // txtemployeefirst
            // 
            this.txtemployeefirst.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtemployeefirst.Location = new System.Drawing.Point(181, 168);
            this.txtemployeefirst.Multiline = true;
            this.txtemployeefirst.Name = "txtemployeefirst";
            this.txtemployeefirst.Size = new System.Drawing.Size(233, 30);
            this.txtemployeefirst.TabIndex = 97;
            // 
            // txtemployeetitle
            // 
            this.txtemployeetitle.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtemployeetitle.Location = new System.Drawing.Point(181, 240);
            this.txtemployeetitle.Multiline = true;
            this.txtemployeetitle.Name = "txtemployeetitle";
            this.txtemployeetitle.Size = new System.Drawing.Size(233, 30);
            this.txtemployeetitle.TabIndex = 99;
            // 
            // txtpayrollid
            // 
            this.txtpayrollid.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtpayrollid.Location = new System.Drawing.Point(181, 133);
            this.txtpayrollid.Multiline = true;
            this.txtpayrollid.Name = "txtpayrollid";
            this.txtpayrollid.Size = new System.Drawing.Size(233, 30);
            this.txtpayrollid.TabIndex = 96;
            // 
            // txtemployeeid
            // 
            this.txtemployeeid.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtemployeeid.Location = new System.Drawing.Point(181, 98);
            this.txtemployeeid.Multiline = true;
            this.txtemployeeid.Name = "txtemployeeid";
            this.txtemployeeid.ReadOnly = true;
            this.txtemployeeid.Size = new System.Drawing.Size(233, 30);
            this.txtemployeeid.TabIndex = 102;
            // 
            // lblemployeefirst
            // 
            this.lblemployeefirst.AutoSize = true;
            this.lblemployeefirst.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblemployeefirst.Location = new System.Drawing.Point(17, 168);
            this.lblemployeefirst.Name = "lblemployeefirst";
            this.lblemployeefirst.Size = new System.Drawing.Size(154, 21);
            this.lblemployeefirst.TabIndex = 48;
            this.lblemployeefirst.Text = "Employee First Name";
            // 
            // lblemployeelast
            // 
            this.lblemployeelast.AutoSize = true;
            this.lblemployeelast.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblemployeelast.Location = new System.Drawing.Point(19, 204);
            this.lblemployeelast.Name = "lblemployeelast";
            this.lblemployeelast.Size = new System.Drawing.Size(152, 21);
            this.lblemployeelast.TabIndex = 49;
            this.lblemployeelast.Text = "Employee Last Name";
            // 
            // lblemployeetitle
            // 
            this.lblemployeetitle.AutoSize = true;
            this.lblemployeetitle.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblemployeetitle.Location = new System.Drawing.Point(132, 240);
            this.lblemployeetitle.Name = "lblemployeetitle";
            this.lblemployeetitle.Size = new System.Drawing.Size(39, 21);
            this.lblemployeetitle.TabIndex = 53;
            this.lblemployeetitle.Text = "Title";
            // 
            // lblhiredate
            // 
            this.lblhiredate.AutoSize = true;
            this.lblhiredate.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblhiredate.Location = new System.Drawing.Point(97, 276);
            this.lblhiredate.Name = "lblhiredate";
            this.lblhiredate.Size = new System.Drawing.Size(74, 21);
            this.lblhiredate.TabIndex = 80;
            this.lblhiredate.Text = "Hire Date";
            // 
            // dtphire
            // 
            this.dtphire.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtphire.Location = new System.Drawing.Point(181, 275);
            this.dtphire.Name = "dtphire";
            this.dtphire.Size = new System.Drawing.Size(233, 22);
            this.dtphire.TabIndex = 100;
            // 
            // btnaddemployee
            // 
            this.btnaddemployee.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddemployee.Location = new System.Drawing.Point(50, 322);
            this.btnaddemployee.Margin = new System.Windows.Forms.Padding(2);
            this.btnaddemployee.Name = "btnaddemployee";
            this.btnaddemployee.Size = new System.Drawing.Size(109, 37);
            this.btnaddemployee.TabIndex = 101;
            this.btnaddemployee.Text = "add";
            this.btnaddemployee.UseVisualStyleBackColor = true;
            this.btnaddemployee.Click += new System.EventHandler(this.btnaddemployee_Click);
            // 
            // btnupdateemployee
            // 
            this.btnupdateemployee.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdateemployee.Location = new System.Drawing.Point(181, 322);
            this.btnupdateemployee.Margin = new System.Windows.Forms.Padding(2);
            this.btnupdateemployee.Name = "btnupdateemployee";
            this.btnupdateemployee.Size = new System.Drawing.Size(109, 37);
            this.btnupdateemployee.TabIndex = 90;
            this.btnupdateemployee.Text = "update";
            this.btnupdateemployee.UseVisualStyleBackColor = true;
            this.btnupdateemployee.Click += new System.EventHandler(this.btnupdateemployee_Click);
            // 
            // btndeleteemployee
            // 
            this.btndeleteemployee.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndeleteemployee.Location = new System.Drawing.Point(307, 322);
            this.btndeleteemployee.Margin = new System.Windows.Forms.Padding(2);
            this.btndeleteemployee.Name = "btndeleteemployee";
            this.btndeleteemployee.Size = new System.Drawing.Size(109, 37);
            this.btndeleteemployee.TabIndex = 91;
            this.btndeleteemployee.Text = "delete";
            this.btndeleteemployee.UseVisualStyleBackColor = true;
            this.btndeleteemployee.Click += new System.EventHandler(this.btndeleteemployee_Click);
            // 
            // lblpayrollid
            // 
            this.lblpayrollid.AutoSize = true;
            this.lblpayrollid.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblpayrollid.Location = new System.Drawing.Point(97, 133);
            this.lblpayrollid.Name = "lblpayrollid";
            this.lblpayrollid.Size = new System.Drawing.Size(74, 21);
            this.lblpayrollid.TabIndex = 93;
            this.lblpayrollid.Text = "Payroll ID";
            // 
            // lblemployeeid
            // 
            this.lblemployeeid.AutoSize = true;
            this.lblemployeeid.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblemployeeid.Location = new System.Drawing.Point(76, 98);
            this.lblemployeeid.Name = "lblemployeeid";
            this.lblemployeeid.Size = new System.Drawing.Size(95, 21);
            this.lblemployeeid.TabIndex = 94;
            this.lblemployeeid.Text = "Employee ID";
            // 
            // lblAddEmployee
            // 
            this.lblAddEmployee.AutoSize = true;
            this.lblAddEmployee.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEmployee.Location = new System.Drawing.Point(12, 18);
            this.lblAddEmployee.Name = "lblAddEmployee";
            this.lblAddEmployee.Size = new System.Drawing.Size(471, 47);
            this.lblAddEmployee.TabIndex = 117;
            this.lblAddEmployee.Text = "Add, update, and delete users";
            // 
            // dgvEmployees
            // 
            this.dgvEmployees.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmployees.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEmployees.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEmployees.Location = new System.Drawing.Point(430, 98);
            this.dgvEmployees.Name = "dgvEmployees";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmployees.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvEmployees.RowHeadersWidth = 82;
            this.dgvEmployees.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvEmployees.RowTemplate.Height = 30;
            this.dgvEmployees.Size = new System.Drawing.Size(750, 354);
            this.dgvEmployees.TabIndex = 120;
            this.dgvEmployees.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmployees_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 491);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(288, 47);
            this.label2.TabIndex = 121;
            this.label2.Text = "Login Information";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.usernameDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.roleDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.lOGINBindingSource;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.Location = new System.Drawing.Point(430, 569);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(750, 185);
            this.dataGridView1.TabIndex = 122;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            this.passwordDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // roleDataGridViewTextBoxColumn
            // 
            this.roleDataGridViewTextBoxColumn.DataPropertyName = "Role";
            this.roleDataGridViewTextBoxColumn.HeaderText = "Role";
            this.roleDataGridViewTextBoxColumn.Name = "roleDataGridViewTextBoxColumn";
            this.roleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lOGINBindingSource
            // 
            this.lOGINBindingSource.DataMember = "LOGIN";
            this.lOGINBindingSource.DataSource = this.iSYS4283SP22T14DataSet2;
            // 
            // iSYS4283SP22T14DataSet2
            // 
            this.iSYS4283SP22T14DataSet2.DataSetName = "ISYS4283SP22T14DataSet2";
            this.iSYS4283SP22T14DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.label3.Location = new System.Drawing.Point(97, 637);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 21);
            this.label3.TabIndex = 124;
            this.label3.Text = "Password";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtUsername
            // 
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtUsername.Location = new System.Drawing.Point(181, 602);
            this.txtUsername.Multiline = true;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(233, 30);
            this.txtUsername.TabIndex = 128;
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtPassword.Location = new System.Drawing.Point(181, 637);
            this.txtPassword.Multiline = true;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(233, 30);
            this.txtPassword.TabIndex = 126;
            // 
            // txtEmpID
            // 
            this.txtEmpID.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtEmpID.Location = new System.Drawing.Point(181, 566);
            this.txtEmpID.Multiline = true;
            this.txtEmpID.Name = "txtEmpID";
            this.txtEmpID.ReadOnly = true;
            this.txtEmpID.Size = new System.Drawing.Size(233, 30);
            this.txtEmpID.TabIndex = 127;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.label4.Location = new System.Drawing.Point(76, 566);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 21);
            this.label4.TabIndex = 123;
            this.label4.Text = "Employee ID";
            // 
            // btnUpdateLogin
            // 
            this.btnUpdateLogin.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateLogin.Location = new System.Drawing.Point(179, 717);
            this.btnUpdateLogin.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdateLogin.Name = "btnUpdateLogin";
            this.btnUpdateLogin.Size = new System.Drawing.Size(109, 37);
            this.btnUpdateLogin.TabIndex = 129;
            this.btnUpdateLogin.Text = "update";
            this.btnUpdateLogin.UseVisualStyleBackColor = true;
            this.btnUpdateLogin.Click += new System.EventHandler(this.btnUpdateLogin_Click);
            // 
            // btnAddLogin
            // 
            this.btnAddLogin.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddLogin.Location = new System.Drawing.Point(48, 717);
            this.btnAddLogin.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddLogin.Name = "btnAddLogin";
            this.btnAddLogin.Size = new System.Drawing.Size(109, 37);
            this.btnAddLogin.TabIndex = 131;
            this.btnAddLogin.Text = "add";
            this.btnAddLogin.UseVisualStyleBackColor = true;
            this.btnAddLogin.Click += new System.EventHandler(this.btnAddLogin_Click);
            // 
            // lOGINTableAdapter
            // 
            this.lOGINTableAdapter.ClearBeforeFill = true;
            // 
            // txtRole
            // 
            this.txtRole.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtRole.Location = new System.Drawing.Point(181, 675);
            this.txtRole.Multiline = true;
            this.txtRole.Name = "txtRole";
            this.txtRole.Size = new System.Drawing.Size(233, 30);
            this.txtRole.TabIndex = 133;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.label5.Location = new System.Drawing.Point(131, 675);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 21);
            this.label5.TabIndex = 132;
            this.label5.Text = "Role";
            // 
            // btnDeleteLogin
            // 
            this.btnDeleteLogin.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteLogin.Location = new System.Drawing.Point(305, 717);
            this.btnDeleteLogin.Margin = new System.Windows.Forms.Padding(2);
            this.btnDeleteLogin.Name = "btnDeleteLogin";
            this.btnDeleteLogin.Size = new System.Drawing.Size(109, 37);
            this.btnDeleteLogin.TabIndex = 130;
            this.btnDeleteLogin.Text = "delete";
            this.btnDeleteLogin.UseVisualStyleBackColor = true;
            this.btnDeleteLogin.Click += new System.EventHandler(this.btnDeleteLogin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.label1.Location = new System.Drawing.Point(92, 602);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 21);
            this.label1.TabIndex = 134;
            this.label1.Text = "Username";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 766);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRole);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnDeleteLogin);
            this.Controls.Add(this.btnUpdateLogin);
            this.Controls.Add(this.btnAddLogin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtEmpID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvEmployees);
            this.Controls.Add(this.lblAddEmployee);
            this.Controls.Add(this.btndeleteemployee);
            this.Controls.Add(this.lblemployeeid);
            this.Controls.Add(this.btnupdateemployee);
            this.Controls.Add(this.lblpayrollid);
            this.Controls.Add(this.btnaddemployee);
            this.Controls.Add(this.txtemployeeid);
            this.Controls.Add(this.txtpayrollid);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.dtphire);
            this.Controls.Add(this.lblhiredate);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.txtlastemployee);
            this.Controls.Add(this.txtemployeefirst);
            this.Controls.Add(this.txtemployeetitle);
            this.Controls.Add(this.lblemployeefirst);
            this.Controls.Add(this.lblemployeelast);
            this.Controls.Add(this.lblemployeetitle);
            this.Name = "AddEmployee";
            this.Text = "Add Employee";
            this.Load += new System.EventHandler(this.AddEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lOGINBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSYS4283SP22T14DataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TextBox txtlastemployee;
        private System.Windows.Forms.TextBox txtemployeefirst;
        private System.Windows.Forms.TextBox txtemployeetitle;
        private System.Windows.Forms.TextBox txtpayrollid;
        private System.Windows.Forms.TextBox txtemployeeid;
        private System.Windows.Forms.Label lblemployeefirst;
        private System.Windows.Forms.Label lblemployeelast;
        private System.Windows.Forms.Label lblemployeetitle;
        private System.Windows.Forms.Label lblhiredate;
        private System.Windows.Forms.DateTimePicker dtphire;
        private System.Windows.Forms.Button btnaddemployee;
        private System.Windows.Forms.Button btnupdateemployee;
        private System.Windows.Forms.Button btndeleteemployee;
        private System.Windows.Forms.Label lblpayrollid;
        private System.Windows.Forms.Label lblemployeeid;
        private System.Windows.Forms.Label lblAddEmployee;
        private System.Windows.Forms.DataGridView dgvEmployees;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtEmpID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnUpdateLogin;
        private System.Windows.Forms.Button btnAddLogin;
        private ISYS4283SP22T14DataSet2 iSYS4283SP22T14DataSet2;
        private System.Windows.Forms.BindingSource lOGINBindingSource;
        private ISYS4283SP22T14DataSet2TableAdapters.LOGINTableAdapter lOGINTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roleDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtRole;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDeleteLogin;
        private System.Windows.Forms.Label label1;
    }
}