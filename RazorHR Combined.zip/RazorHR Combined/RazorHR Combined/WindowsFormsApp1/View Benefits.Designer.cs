﻿
namespace WindowsFormsApp1
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSubmitBenefitsQuestion = new System.Windows.Forms.Button();
            this.txtBenefitsQuestion = new System.Windows.Forms.TextBox();
            this.lblQuestionsAboutBenefits = new System.Windows.Forms.Label();
            this.lblMoreHelp = new System.Windows.Forms.Label();
            this.lblViewBenefits = new System.Windows.Forms.Label();
            this.txtSickDays = new System.Windows.Forms.TextBox();
            this.txtFamilyLeave = new System.Windows.Forms.TextBox();
            this.txtVisionPlan = new System.Windows.Forms.TextBox();
            this.txtDental = new System.Windows.Forms.TextBox();
            this.txtHealthcare = new System.Windows.Forms.TextBox();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblViewingBenefitsForUser = new System.Windows.Forms.Label();
            this.lblPTO = new System.Windows.Forms.Label();
            this.lblSD = new System.Windows.Forms.Label();
            this.lblFL = new System.Windows.Forms.Label();
            this.lblVisionPlan = new System.Windows.Forms.Label();
            this.lblDental = new System.Windows.Forms.Label();
            this.lblHealthcare = new System.Windows.Forms.Label();
            this.txtPTO = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picHealthcare = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHealthcare)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSubmitBenefitsQuestion
            // 
            this.btnSubmitBenefitsQuestion.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSubmitBenefitsQuestion.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitBenefitsQuestion.Location = new System.Drawing.Point(785, 311);
            this.btnSubmitBenefitsQuestion.Name = "btnSubmitBenefitsQuestion";
            this.btnSubmitBenefitsQuestion.Size = new System.Drawing.Size(226, 36);
            this.btnSubmitBenefitsQuestion.TabIndex = 78;
            this.btnSubmitBenefitsQuestion.Text = "Submit Question";
            this.btnSubmitBenefitsQuestion.UseVisualStyleBackColor = false;
            this.btnSubmitBenefitsQuestion.Click += new System.EventHandler(this.btnSubmitBenefitsQuestion_Click);
            // 
            // txtBenefitsQuestion
            // 
            this.txtBenefitsQuestion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBenefitsQuestion.Location = new System.Drawing.Point(747, 156);
            this.txtBenefitsQuestion.Multiline = true;
            this.txtBenefitsQuestion.Name = "txtBenefitsQuestion";
            this.txtBenefitsQuestion.Size = new System.Drawing.Size(306, 126);
            this.txtBenefitsQuestion.TabIndex = 77;
            // 
            // lblQuestionsAboutBenefits
            // 
            this.lblQuestionsAboutBenefits.AutoSize = true;
            this.lblQuestionsAboutBenefits.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestionsAboutBenefits.Location = new System.Drawing.Point(743, 132);
            this.lblQuestionsAboutBenefits.Name = "lblQuestionsAboutBenefits";
            this.lblQuestionsAboutBenefits.Size = new System.Drawing.Size(268, 21);
            this.lblQuestionsAboutBenefits.TabIndex = 76;
            this.lblQuestionsAboutBenefits.Text = "Questions about Benefits? Type away!";
            // 
            // lblMoreHelp
            // 
            this.lblMoreHelp.AutoSize = true;
            this.lblMoreHelp.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblMoreHelp.Location = new System.Drawing.Point(741, 81);
            this.lblMoreHelp.Name = "lblMoreHelp";
            this.lblMoreHelp.Size = new System.Drawing.Size(125, 32);
            this.lblMoreHelp.TabIndex = 75;
            this.lblMoreHelp.Text = "More Help";
            // 
            // lblViewBenefits
            // 
            this.lblViewBenefits.AutoSize = true;
            this.lblViewBenefits.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewBenefits.Location = new System.Drawing.Point(10, 23);
            this.lblViewBenefits.Name = "lblViewBenefits";
            this.lblViewBenefits.Size = new System.Drawing.Size(219, 47);
            this.lblViewBenefits.TabIndex = 74;
            this.lblViewBenefits.Text = "View Benefits";
            // 
            // txtSickDays
            // 
            this.txtSickDays.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSickDays.Location = new System.Drawing.Point(224, 415);
            this.txtSickDays.Multiline = true;
            this.txtSickDays.Name = "txtSickDays";
            this.txtSickDays.ReadOnly = true;
            this.txtSickDays.Size = new System.Drawing.Size(450, 30);
            this.txtSickDays.TabIndex = 68;
            // 
            // txtFamilyLeave
            // 
            this.txtFamilyLeave.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFamilyLeave.Location = new System.Drawing.Point(224, 348);
            this.txtFamilyLeave.Multiline = true;
            this.txtFamilyLeave.Name = "txtFamilyLeave";
            this.txtFamilyLeave.ReadOnly = true;
            this.txtFamilyLeave.Size = new System.Drawing.Size(450, 30);
            this.txtFamilyLeave.TabIndex = 67;
            // 
            // txtVisionPlan
            // 
            this.txtVisionPlan.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVisionPlan.Location = new System.Drawing.Point(224, 277);
            this.txtVisionPlan.Multiline = true;
            this.txtVisionPlan.Name = "txtVisionPlan";
            this.txtVisionPlan.ReadOnly = true;
            this.txtVisionPlan.Size = new System.Drawing.Size(450, 30);
            this.txtVisionPlan.TabIndex = 66;
            // 
            // txtDental
            // 
            this.txtDental.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDental.Location = new System.Drawing.Point(224, 209);
            this.txtDental.Multiline = true;
            this.txtDental.Name = "txtDental";
            this.txtDental.ReadOnly = true;
            this.txtDental.Size = new System.Drawing.Size(450, 30);
            this.txtDental.TabIndex = 65;
            // 
            // txtHealthcare
            // 
            this.txtHealthcare.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHealthcare.Location = new System.Drawing.Point(224, 142);
            this.txtHealthcare.Multiline = true;
            this.txtHealthcare.Name = "txtHealthcare";
            this.txtHealthcare.ReadOnly = true;
            this.txtHealthcare.Size = new System.Drawing.Size(450, 30);
            this.txtHealthcare.TabIndex = 64;
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserID.Location = new System.Drawing.Point(303, 81);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(85, 32);
            this.lblUserID.TabIndex = 58;
            this.lblUserID.Text = "XXXXX";
            // 
            // lblViewingBenefitsForUser
            // 
            this.lblViewingBenefitsForUser.AutoSize = true;
            this.lblViewingBenefitsForUser.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblViewingBenefitsForUser.Location = new System.Drawing.Point(12, 81);
            this.lblViewingBenefitsForUser.Name = "lblViewingBenefitsForUser";
            this.lblViewingBenefitsForUser.Size = new System.Drawing.Size(307, 32);
            this.lblViewingBenefitsForUser.TabIndex = 57;
            this.lblViewingBenefitsForUser.Text = "Viewing benefits for user ID ";
            // 
            // lblPTO
            // 
            this.lblPTO.AutoSize = true;
            this.lblPTO.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblPTO.Location = new System.Drawing.Point(68, 479);
            this.lblPTO.Name = "lblPTO";
            this.lblPTO.Size = new System.Drawing.Size(153, 32);
            this.lblPTO.TabIndex = 102;
            this.lblPTO.Text = "Paid Time Off";
            // 
            // lblSD
            // 
            this.lblSD.AutoSize = true;
            this.lblSD.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblSD.Location = new System.Drawing.Point(110, 412);
            this.lblSD.Name = "lblSD";
            this.lblSD.Size = new System.Drawing.Size(111, 32);
            this.lblSD.TabIndex = 100;
            this.lblSD.Text = "Sick Days";
            // 
            // lblFL
            // 
            this.lblFL.AutoSize = true;
            this.lblFL.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblFL.Location = new System.Drawing.Point(78, 345);
            this.lblFL.Name = "lblFL";
            this.lblFL.Size = new System.Drawing.Size(143, 32);
            this.lblFL.TabIndex = 99;
            this.lblFL.Text = "Family Leave";
            // 
            // lblVisionPlan
            // 
            this.lblVisionPlan.AutoSize = true;
            this.lblVisionPlan.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblVisionPlan.Location = new System.Drawing.Point(94, 274);
            this.lblVisionPlan.Name = "lblVisionPlan";
            this.lblVisionPlan.Size = new System.Drawing.Size(127, 32);
            this.lblVisionPlan.TabIndex = 98;
            this.lblVisionPlan.Text = "Vision Plan";
            // 
            // lblDental
            // 
            this.lblDental.AutoSize = true;
            this.lblDental.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblDental.Location = new System.Drawing.Point(139, 206);
            this.lblDental.Name = "lblDental";
            this.lblDental.Size = new System.Drawing.Size(82, 32);
            this.lblDental.TabIndex = 97;
            this.lblDental.Text = "Dental";
            // 
            // lblHealthcare
            // 
            this.lblHealthcare.AutoSize = true;
            this.lblHealthcare.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblHealthcare.Location = new System.Drawing.Point(96, 139);
            this.lblHealthcare.Name = "lblHealthcare";
            this.lblHealthcare.Size = new System.Drawing.Size(125, 32);
            this.lblHealthcare.TabIndex = 96;
            this.lblHealthcare.Text = "Healthcare";
            // 
            // txtPTO
            // 
            this.txtPTO.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPTO.Location = new System.Drawing.Point(224, 482);
            this.txtPTO.Multiline = true;
            this.txtPTO.Name = "txtPTO";
            this.txtPTO.ReadOnly = true;
            this.txtPTO.Size = new System.Drawing.Size(450, 30);
            this.txtPTO.TabIndex = 108;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::WindowsFormsApp1.Properties.Resources.outline_bedtime_off_black_24dp;
            this.pictureBox5.Location = new System.Drawing.Point(18, 479);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(49, 43);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 107;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::WindowsFormsApp1.Properties.Resources.outline_sick_black_24dp;
            this.pictureBox4.Location = new System.Drawing.Point(18, 410);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(49, 43);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 106;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::WindowsFormsApp1.Properties.Resources.people;
            this.pictureBox3.Location = new System.Drawing.Point(18, 345);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 43);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 105;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApp1.Properties.Resources.outline_remove_red_eye_black_48dp1;
            this.pictureBox2.Location = new System.Drawing.Point(18, 274);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(49, 43);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 104;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.outline_emoji_emotions_black_24dp;
            this.pictureBox1.Location = new System.Drawing.Point(18, 204);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 103;
            this.pictureBox1.TabStop = false;
            // 
            // picHealthcare
            // 
            this.picHealthcare.Image = global::WindowsFormsApp1.Properties.Resources.outline_health_and_safety_black_48dp;
            this.picHealthcare.Location = new System.Drawing.Point(18, 139);
            this.picHealthcare.Name = "picHealthcare";
            this.picHealthcare.Size = new System.Drawing.Size(49, 43);
            this.picHealthcare.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picHealthcare.TabIndex = 101;
            this.picHealthcare.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1018, 552);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 56);
            this.button1.TabIndex = 109;
            this.button1.Text = "Home";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox6.Image = global::WindowsFormsApp1.Properties.Resources.home_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox6.Location = new System.Drawing.Point(1087, 562);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(39, 37);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 110;
            this.pictureBox6.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(3000, 445);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 111;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1151, 620);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtPTO);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblPTO);
            this.Controls.Add(this.picHealthcare);
            this.Controls.Add(this.lblSD);
            this.Controls.Add(this.lblFL);
            this.Controls.Add(this.lblVisionPlan);
            this.Controls.Add(this.lblDental);
            this.Controls.Add(this.lblHealthcare);
            this.Controls.Add(this.btnSubmitBenefitsQuestion);
            this.Controls.Add(this.txtBenefitsQuestion);
            this.Controls.Add(this.lblQuestionsAboutBenefits);
            this.Controls.Add(this.lblMoreHelp);
            this.Controls.Add(this.lblViewBenefits);
            this.Controls.Add(this.txtSickDays);
            this.Controls.Add(this.txtFamilyLeave);
            this.Controls.Add(this.txtVisionPlan);
            this.Controls.Add(this.txtDental);
            this.Controls.Add(this.txtHealthcare);
            this.Controls.Add(this.lblUserID);
            this.Controls.Add(this.lblViewingBenefitsForUser);
            this.Name = "Form7";
            this.Text = "Form7";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHealthcare)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSubmitBenefitsQuestion;
        private System.Windows.Forms.TextBox txtBenefitsQuestion;
        private System.Windows.Forms.Label lblQuestionsAboutBenefits;
        private System.Windows.Forms.Label lblMoreHelp;
        private System.Windows.Forms.Label lblViewBenefits;
        private System.Windows.Forms.TextBox txtSickDays;
        private System.Windows.Forms.TextBox txtFamilyLeave;
        private System.Windows.Forms.TextBox txtVisionPlan;
        private System.Windows.Forms.TextBox txtDental;
        private System.Windows.Forms.TextBox txtHealthcare;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label lblViewingBenefitsForUser;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblPTO;
        private System.Windows.Forms.PictureBox picHealthcare;
        private System.Windows.Forms.Label lblSD;
        private System.Windows.Forms.Label lblFL;
        private System.Windows.Forms.Label lblVisionPlan;
        private System.Windows.Forms.Label lblDental;
        private System.Windows.Forms.Label lblHealthcare;
        private System.Windows.Forms.TextBox txtPTO;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}