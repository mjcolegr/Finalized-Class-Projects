﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;


namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        SqlConnection con = new SqlConnection(@"data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;password=GohogsUA1;");
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public Form5()
        {
            InitializeComponent();
            showdata();
            showdata2();
            this.dgvRequests.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        }

        private void btnEditBenefits_Click(object sender, EventArgs e)
        {
            var myForm = new Form3();
            myForm.Show();
        }

        private void btnPostJobs_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.indeed.com");
        }
        public void showdata()
        {
            SqlConnection con = new SqlConnection(@"data Source = essql1.walton.uark.edu; Initial Catalog = ISYS4283SP22T14; User ID = ISYS4283SP22T14; password = GohogsUA1;");
            SqlCommand cmd;
            SqlDataAdapter adpt;
            DataTable dt;

            adpt = new SqlDataAdapter("SELECT * FROM Ticketing", con);
            dt = new DataTable();
            adpt.Fill(dt);
            dgvRequests.DataSource = dt;
        }
        public void showdata2()
        {
            SqlConnection con = new SqlConnection(@"data Source = essql1.walton.uark.edu; Initial Catalog = ISYS4283SP22T14; User ID = ISYS4283SP22T14; password = GohogsUA1;");
            SqlCommand cmd;
            SqlDataAdapter adpt;
            DataTable dt;

            adpt = new SqlDataAdapter("SELECT Employee_ID, Amount_Loaded, Cardholder_Name FROM Company_Card", con);
            dt = new DataTable();
            adpt.Fill(dt);
            dgvCorporateCard.DataSource = dt;
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            var sendTo = "gotexan20@gmail.com";
            var subj = "Your request was approved!";
            var msg = "We have approved your request pertaining to Ticket ID " + dgvRequests.CurrentCell.Value.ToString() +". " + "\n\nBest,\nRazor HR";
            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("rhrsolutions2022@gmail.com", "M@rch2o22"),
                EnableSsl = true,
            };

            smtpClient.Send("rhrsolutions2022@gmail.com", sendTo, subj, msg);
            MessageBox.Show("Email sent!");
        }

        private void btnDenyRequest_Click(object sender, EventArgs e)
        {
            var sendTo = "gotexan20@gmail.com";
            var subj = "Your request was denied.";
            var msg = "Unfortunately, we have denied your request pertaining to Ticket ID " + dgvRequests.CurrentCell.Value.ToString() + ". " + "\n\nBest,\nRazor HR";
            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("rhrsolutions2022@gmail.com", "M@rch2o22"),
                EnableSsl = true,
            };

            smtpClient.Send("rhrsolutions2022@gmail.com", sendTo, subj, msg);
            MessageBox.Show("Email sent!");
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var myForm = new Form4();
            myForm.Show();
            this.Hide();
        }

        private void btnAddMoney_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "UPDATE Company_Card SET Amount_Loaded=@RequestedMoney + Amount_Loaded WHERE Employee_ID=@Card";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@RequestedMoney", txtMoneyAdd.Text);
                cmd.Parameters.AddWithValue("@Card", dgvCorporateCard.CurrentRow.Cells[0].Value.ToString());

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully added money!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure to select a card from the grid view.");
            }
        }
    }
}
