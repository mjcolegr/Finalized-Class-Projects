﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static string loggedinID;
        public static string loggedinName;

        SqlConnection con = new SqlConnection(@"Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1;");
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;

        public Form1()
        {
            InitializeComponent();
        }
        private void btnBookTravel_Click(object sender, EventArgs e)
        {
            var myForm = new Form9();
            myForm.Show();
            this.Hide();
        }

        private void btnHiringAndFiring_Click(object sender, EventArgs e)
        {
            var myForm = new Form2();
            myForm.Show();
            this.Hide();
        }

        private void btnFileExpenses_Click(object sender, EventArgs e)
        {
            var myForm = new Form6();
            myForm.Show();
            this.Hide();
        }

        private void btnPayroll_Click(object sender, EventArgs e)
        {
            var myForm = new Payroll();
            myForm.Show();
            this.Hide();
        }

        private void btnBenefits_Click(object sender, EventArgs e)
        {
            var myForm = new Form7();
            myForm.Show();
            this.Hide();
        }

        private void btnTraining_Click(object sender, EventArgs e)
        {
            var myForm = new Training();
            myForm.Show();
            this.Hide();
        }

        private void btnViewAsHREmployee_Click(object sender, EventArgs e)
        {
            var myForm = new Form5();
            myForm.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblUsernamePassed.Text = Form4.username1;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1";
            con.Open();
            if (lblUsernamePassed.Text != "")
            {
                SqlCommand cmd = new SqlCommand("SELECT Employee_ID FROM LOGIN WHERE Username=@U", con);
                cmd.Parameters.AddWithValue("@U", lblUsernamePassed.Text);
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    lblEmployeeID.Text = da.GetValue(0).ToString();
                }
                con.Close();

                loggedinID = lblEmployeeID.Text;
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            TimeSpan result = this.dtpEnd.Value - this.dtpStart.Value;
            this.txtTimeWorked.Text = result.ToString();

            string s = txtTimeWorked.Text;
            string[] tempArry = txtTimeWorked.Text.Split('.');
            txtTimeWorked.Text = tempArry[0];
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try 
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                if (lblEmployeeID.Text != "")
                {
                    //create variables with the @ sign. just use whatever abbreviation makes sense
                    string sql = "UPDATE Payroll SET Minutes_Worked=@Minutes WHERE Employee_ID=@U";
                    int answer;
                    cmd = new SqlCommand(sql, con);

                    cmd.Parameters.AddWithValue("@Minutes", Int32.Parse(txtTimeWorked.Text));
                    cmd.Parameters.AddWithValue("@U", lblEmployeeID.Text);

                    answer = cmd.ExecuteNonQuery();

                    con.Close();
                    cmd.Dispose();
                    MessageBox.Show("Successfully logged hours!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Successfully logged hours!");
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var myForm = new Form4();
            myForm.Show();
            this.Hide();
        }

    }
    }

