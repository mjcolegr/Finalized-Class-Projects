﻿
namespace WindowsFormsApp1
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRequestMoreInfo = new System.Windows.Forms.Button();
            this.btnDeny = new System.Windows.Forms.Button();
            this.btnApprove = new System.Windows.Forms.Button();
            this.dgvRequests = new System.Windows.Forms.DataGridView();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.grpMoreFeatures = new System.Windows.Forms.GroupBox();
            this.btnPostJobs = new System.Windows.Forms.Button();
            this.btnEditBenefits = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvCorporateCard = new System.Windows.Forms.DataGridView();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.txtMoneyAdd = new System.Windows.Forms.TextBox();
            this.lblMoney = new System.Windows.Forms.Label();
            this.btnAddMoney = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).BeginInit();
            this.grpMoreFeatures.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCorporateCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRequestMoreInfo
            // 
            this.btnRequestMoreInfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRequestMoreInfo.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.btnRequestMoreInfo.Location = new System.Drawing.Point(51, 459);
            this.btnRequestMoreInfo.Name = "btnRequestMoreInfo";
            this.btnRequestMoreInfo.Size = new System.Drawing.Size(98, 43);
            this.btnRequestMoreInfo.TabIndex = 16;
            this.btnRequestMoreInfo.Text = "Request More Information";
            this.btnRequestMoreInfo.UseVisualStyleBackColor = false;
            // 
            // btnDeny
            // 
            this.btnDeny.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnDeny.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.btnDeny.Location = new System.Drawing.Point(155, 459);
            this.btnDeny.Name = "btnDeny";
            this.btnDeny.Size = new System.Drawing.Size(98, 43);
            this.btnDeny.TabIndex = 15;
            this.btnDeny.Text = "Deny Request";
            this.btnDeny.UseVisualStyleBackColor = false;
            this.btnDeny.Click += new System.EventHandler(this.btnDenyRequest_Click);
            // 
            // btnApprove
            // 
            this.btnApprove.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnApprove.Font = new System.Drawing.Font("Segoe UI Semilight", 9F);
            this.btnApprove.Location = new System.Drawing.Point(259, 459);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(98, 43);
            this.btnApprove.TabIndex = 14;
            this.btnApprove.Text = "Approve Request";
            this.btnApprove.UseVisualStyleBackColor = false;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // dgvRequests
            // 
            this.dgvRequests.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequests.Location = new System.Drawing.Point(51, 64);
            this.dgvRequests.Name = "dgvRequests";
            this.dgvRequests.RowHeadersWidth = 82;
            this.dgvRequests.RowTemplate.Height = 50;
            this.dgvRequests.Size = new System.Drawing.Size(1318, 389);
            this.dgvRequests.TabIndex = 13;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI Semilight", 18.25F);
            this.lblWelcome.Location = new System.Drawing.Point(12, 18);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(654, 35);
            this.lblWelcome.TabIndex = 17;
            this.lblWelcome.Text = "Welcome! Below are the pending requests from employees.";
            // 
            // grpMoreFeatures
            // 
            this.grpMoreFeatures.Controls.Add(this.btnPostJobs);
            this.grpMoreFeatures.Controls.Add(this.btnEditBenefits);
            this.grpMoreFeatures.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMoreFeatures.Location = new System.Drawing.Point(51, 529);
            this.grpMoreFeatures.Name = "grpMoreFeatures";
            this.grpMoreFeatures.Size = new System.Drawing.Size(822, 131);
            this.grpMoreFeatures.TabIndex = 18;
            this.grpMoreFeatures.TabStop = false;
            this.grpMoreFeatures.Text = "More Controls";
            // 
            // btnPostJobs
            // 
            this.btnPostJobs.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPostJobs.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPostJobs.Location = new System.Drawing.Point(218, 42);
            this.btnPostJobs.Name = "btnPostJobs";
            this.btnPostJobs.Size = new System.Drawing.Size(162, 60);
            this.btnPostJobs.TabIndex = 20;
            this.btnPostJobs.Text = "Post Jobs";
            this.btnPostJobs.UseVisualStyleBackColor = false;
            this.btnPostJobs.Click += new System.EventHandler(this.btnPostJobs_Click);
            // 
            // btnEditBenefits
            // 
            this.btnEditBenefits.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEditBenefits.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditBenefits.Location = new System.Drawing.Point(31, 42);
            this.btnEditBenefits.Name = "btnEditBenefits";
            this.btnEditBenefits.Size = new System.Drawing.Size(162, 60);
            this.btnEditBenefits.TabIndex = 19;
            this.btnEditBenefits.Text = "Edit Benefits";
            this.btnEditBenefits.UseVisualStyleBackColor = false;
            this.btnEditBenefits.Click += new System.EventHandler(this.btnEditBenefits_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.label1.Location = new System.Drawing.Point(954, 483);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 21);
            this.label1.TabIndex = 22;
            this.label1.Text = "Corporate Card";
            // 
            // dgvCorporateCard
            // 
            this.dgvCorporateCard.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCorporateCard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCorporateCard.Location = new System.Drawing.Point(958, 507);
            this.dgvCorporateCard.Name = "dgvCorporateCard";
            this.dgvCorporateCard.RowHeadersWidth = 82;
            this.dgvCorporateCard.RowTemplate.Height = 50;
            this.dgvCorporateCard.Size = new System.Drawing.Size(411, 184);
            this.dgvCorporateCard.TabIndex = 23;
            // 
            // btnLogout
            // 
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI Semilight", 11F);
            this.btnLogout.Location = new System.Drawing.Point(1282, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(87, 37);
            this.btnLogout.TabIndex = 41;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox7.Image = global::WindowsFormsApp1.Properties.Resources.logout_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox7.Location = new System.Drawing.Point(1251, 11);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(31, 38);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 40;
            this.pictureBox7.TabStop = false;
            // 
            // txtMoneyAdd
            // 
            this.txtMoneyAdd.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtMoneyAdd.Location = new System.Drawing.Point(1115, 699);
            this.txtMoneyAdd.Multiline = true;
            this.txtMoneyAdd.Name = "txtMoneyAdd";
            this.txtMoneyAdd.Size = new System.Drawing.Size(121, 30);
            this.txtMoneyAdd.TabIndex = 136;
            // 
            // lblMoney
            // 
            this.lblMoney.AutoSize = true;
            this.lblMoney.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblMoney.Location = new System.Drawing.Point(954, 702);
            this.lblMoney.Name = "lblMoney";
            this.lblMoney.Size = new System.Drawing.Size(155, 21);
            this.lblMoney.TabIndex = 135;
            this.lblMoney.Text = "Amount to be added:";
            // 
            // btnAddMoney
            // 
            this.btnAddMoney.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnAddMoney.Location = new System.Drawing.Point(1241, 699);
            this.btnAddMoney.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddMoney.Name = "btnAddMoney";
            this.btnAddMoney.Size = new System.Drawing.Size(128, 30);
            this.btnAddMoney.TabIndex = 134;
            this.btnAddMoney.Text = "Add Money";
            this.btnAddMoney.UseVisualStyleBackColor = true;
            this.btnAddMoney.Click += new System.EventHandler(this.btnAddMoney_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1429, 758);
            this.Controls.Add(this.txtMoneyAdd);
            this.Controls.Add(this.lblMoney);
            this.Controls.Add(this.btnAddMoney);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.dgvCorporateCard);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpMoreFeatures);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnRequestMoreInfo);
            this.Controls.Add(this.btnDeny);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.dgvRequests);
            this.Name = "Form5";
            this.Text = "Pending Requests";
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).EndInit();
            this.grpMoreFeatures.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCorporateCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRequestMoreInfo;
        private System.Windows.Forms.Button btnDeny;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.DataGridView dgvRequests;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.GroupBox grpMoreFeatures;
        private System.Windows.Forms.Button btnEditBenefits;
        private System.Windows.Forms.Button btnPostJobs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvCorporateCard;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.TextBox txtMoneyAdd;
        private System.Windows.Forms.Label lblMoney;
        private System.Windows.Forms.Button btnAddMoney;
    }
}