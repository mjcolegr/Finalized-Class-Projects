﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form7 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1;");
        SqlCommand cmd;
        SqlCommand cmd2;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            lblUserID.Text = Form1.loggedinID;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1";
            con.Open();
            if (lblUserID.Text != "")
            {
                SqlCommand cmd = new SqlCommand("SELECT Healthcare, Dental, Vision_Plan, Family_Leave, Sick_Days, Paid_Time_Off FROM BENEFITS WHERE Employee_ID=@U", con);
                cmd.Parameters.AddWithValue("@U", lblUserID.Text);
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    txtHealthcare.Text = da.GetValue(0).ToString();
                    txtDental.Text = da.GetValue(1).ToString();
                    txtVisionPlan.Text = da.GetValue(2).ToString();
                    txtFamilyLeave.Text = da.GetValue(3).ToString();
                    txtSickDays.Text = da.GetValue(4).ToString();
                    txtPTO.Text = da.GetValue(5).ToString();
                }
                con.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();
        }
        private void btnSubmitBenefitsQuestion_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Ticketing (Employee_ID, Ticket_Submission_Date, Ticket_Classification, Ticket_Description) VALUES (@Employee_ID, @SubmitDate, 'Benefits', @Description)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Employee_ID", lblUserID.Text);
                cmd.Parameters.AddWithValue("@SubmitDate", dateTimePicker1.Value.ToString());
                cmd.Parameters.AddWithValue("@Description", txtBenefitsQuestion.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully submitted benefits question!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please fill out the text box about your question.");
            }
        }
    }
}
