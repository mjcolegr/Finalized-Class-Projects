﻿
namespace WindowsFormsApp1
{
    partial class AddTraining
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblOpenTicket = new System.Windows.Forms.Label();
            this.btnUpdateBenefits = new System.Windows.Forms.Button();
            this.txtLink = new System.Windows.Forms.TextBox();
            this.txtTopic = new System.Windows.Forms.TextBox();
            this.lblVideoLink = new System.Windows.Forms.Label();
            this.lblTopic = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.gtpAddTraining = new System.Windows.Forms.GroupBox();
            this.txtAssignedUser = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAssignTraining = new System.Windows.Forms.Button();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.lblStart = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.lblVendorID = new System.Windows.Forms.Label();
            this.iSYS4283SP22T14DataSet1 = new WindowsFormsApp1.ISYS4283SP22T14DataSet1();
            this.trainingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trainingTableAdapter = new WindowsFormsApp1.ISYS4283SP22T14DataSet1TableAdapters.TrainingTableAdapter();
            this.dgvTrainings = new System.Windows.Forms.DataGridView();
            this.trainingIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.topicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.linkDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblPopUpTravel = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.gtpAddTraining.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iSYS4283SP22T14DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrainings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // lblOpenTicket
            // 
            this.lblOpenTicket.AutoSize = true;
            this.lblOpenTicket.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpenTicket.Location = new System.Drawing.Point(12, 9);
            this.lblOpenTicket.Name = "lblOpenTicket";
            this.lblOpenTicket.Size = new System.Drawing.Size(407, 47);
            this.lblOpenTicket.TabIndex = 15;
            this.lblOpenTicket.Text = "Welcome Training Vendor";
            // 
            // btnUpdateBenefits
            // 
            this.btnUpdateBenefits.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.btnUpdateBenefits.Location = new System.Drawing.Point(17, 317);
            this.btnUpdateBenefits.Name = "btnUpdateBenefits";
            this.btnUpdateBenefits.Size = new System.Drawing.Size(107, 37);
            this.btnUpdateBenefits.TabIndex = 52;
            this.btnUpdateBenefits.Text = "Add Training";
            this.btnUpdateBenefits.UseVisualStyleBackColor = true;
            this.btnUpdateBenefits.Click += new System.EventHandler(this.btnUpdateBenefits_Click);
            // 
            // txtLink
            // 
            this.txtLink.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtLink.Location = new System.Drawing.Point(158, 101);
            this.txtLink.Multiline = true;
            this.txtLink.Name = "txtLink";
            this.txtLink.Size = new System.Drawing.Size(450, 30);
            this.txtLink.TabIndex = 51;
            // 
            // txtTopic
            // 
            this.txtTopic.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtTopic.Location = new System.Drawing.Point(158, 42);
            this.txtTopic.Multiline = true;
            this.txtTopic.Name = "txtTopic";
            this.txtTopic.Size = new System.Drawing.Size(450, 30);
            this.txtTopic.TabIndex = 50;
            // 
            // lblVideoLink
            // 
            this.lblVideoLink.AutoSize = true;
            this.lblVideoLink.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblVideoLink.Location = new System.Drawing.Point(9, 101);
            this.lblVideoLink.Name = "lblVideoLink";
            this.lblVideoLink.Size = new System.Drawing.Size(115, 21);
            this.lblVideoLink.TabIndex = 49;
            this.lblVideoLink.Text = "Link to Training";
            // 
            // lblTopic
            // 
            this.lblTopic.AutoSize = true;
            this.lblTopic.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblTopic.Location = new System.Drawing.Point(9, 45);
            this.lblTopic.Name = "lblTopic";
            this.lblTopic.Size = new System.Drawing.Size(104, 21);
            this.lblTopic.TabIndex = 48;
            this.lblTopic.Text = "Training Topic";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblDescription.Location = new System.Drawing.Point(9, 159);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(88, 21);
            this.lblDescription.TabIndex = 53;
            this.lblDescription.Text = "Description";
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.txtDescription.Location = new System.Drawing.Point(158, 159);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(450, 88);
            this.txtDescription.TabIndex = 54;
            // 
            // gtpAddTraining
            // 
            this.gtpAddTraining.Controls.Add(this.txtAssignedUser);
            this.gtpAddTraining.Controls.Add(this.label1);
            this.gtpAddTraining.Controls.Add(this.btnAssignTraining);
            this.gtpAddTraining.Controls.Add(this.dtpEnd);
            this.gtpAddTraining.Controls.Add(this.dtpStart);
            this.gtpAddTraining.Controls.Add(this.btnUpdateBenefits);
            this.gtpAddTraining.Controls.Add(this.lblStart);
            this.gtpAddTraining.Controls.Add(this.lblEndDate);
            this.gtpAddTraining.Controls.Add(this.txtTopic);
            this.gtpAddTraining.Controls.Add(this.lblDescription);
            this.gtpAddTraining.Controls.Add(this.txtDescription);
            this.gtpAddTraining.Controls.Add(this.txtLink);
            this.gtpAddTraining.Controls.Add(this.lblVideoLink);
            this.gtpAddTraining.Controls.Add(this.lblTopic);
            this.gtpAddTraining.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gtpAddTraining.Location = new System.Drawing.Point(20, 105);
            this.gtpAddTraining.Name = "gtpAddTraining";
            this.gtpAddTraining.Size = new System.Drawing.Size(623, 375);
            this.gtpAddTraining.TabIndex = 55;
            this.gtpAddTraining.TabStop = false;
            this.gtpAddTraining.Text = "Add and Assign Training";
            // 
            // txtAssignedUser
            // 
            this.txtAssignedUser.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtAssignedUser.Location = new System.Drawing.Point(382, 325);
            this.txtAssignedUser.Multiline = true;
            this.txtAssignedUser.Name = "txtAssignedUser";
            this.txtAssignedUser.Size = new System.Drawing.Size(95, 29);
            this.txtAssignedUser.TabIndex = 85;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.label1.Location = new System.Drawing.Point(248, 328);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 21);
            this.label1.TabIndex = 84;
            this.label1.Text = "Assign to User ID";
            // 
            // btnAssignTraining
            // 
            this.btnAssignTraining.Font = new System.Drawing.Font("Segoe UI Semilight", 10F);
            this.btnAssignTraining.Location = new System.Drawing.Point(483, 325);
            this.btnAssignTraining.Name = "btnAssignTraining";
            this.btnAssignTraining.Size = new System.Drawing.Size(125, 29);
            this.btnAssignTraining.TabIndex = 83;
            this.btnAssignTraining.Text = "Assign Training";
            this.btnAssignTraining.UseVisualStyleBackColor = true;
            this.btnAssignTraining.Click += new System.EventHandler(this.btnAssignTraining_Click);
            // 
            // dtpEnd
            // 
            this.dtpEnd.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtpEnd.Location = new System.Drawing.Point(415, 265);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(193, 22);
            this.dtpEnd.TabIndex = 82;
            // 
            // dtpStart
            // 
            this.dtpStart.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtpStart.Location = new System.Drawing.Point(95, 266);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(193, 22);
            this.dtpStart.TabIndex = 81;
            // 
            // lblStart
            // 
            this.lblStart.AutoSize = true;
            this.lblStart.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblStart.Location = new System.Drawing.Point(9, 266);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(76, 21);
            this.lblStart.TabIndex = 80;
            this.lblStart.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.lblEndDate.Location = new System.Drawing.Point(327, 265);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(72, 21);
            this.lblEndDate.TabIndex = 79;
            this.lblEndDate.Text = "End Date";
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeID.Location = new System.Drawing.Point(100, 57);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeID.Size = new System.Drawing.Size(199, 21);
            this.lblEmployeeID.TabIndex = 95;
            this.lblEmployeeID.Text = "employee id (auto-updates)";
            this.lblEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblVendorID
            // 
            this.lblVendorID.AutoSize = true;
            this.lblVendorID.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorID.Location = new System.Drawing.Point(16, 57);
            this.lblVendorID.Name = "lblVendorID";
            this.lblVendorID.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblVendorID.Size = new System.Drawing.Size(86, 21);
            this.lblVendorID.TabIndex = 94;
            this.lblVendorID.Text = "Vendor ID:";
            this.lblVendorID.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // iSYS4283SP22T14DataSet1
            // 
            this.iSYS4283SP22T14DataSet1.DataSetName = "ISYS4283SP22T14DataSet1";
            this.iSYS4283SP22T14DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // trainingBindingSource
            // 
            this.trainingBindingSource.DataMember = "Training";
            this.trainingBindingSource.DataSource = this.iSYS4283SP22T14DataSet1;
            // 
            // trainingTableAdapter
            // 
            this.trainingTableAdapter.ClearBeforeFill = true;
            // 
            // dgvTrainings
            // 
            this.dgvTrainings.AllowUserToAddRows = false;
            this.dgvTrainings.AutoGenerateColumns = false;
            this.dgvTrainings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTrainings.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTrainings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTrainings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.trainingIDDataGridViewTextBoxColumn,
            this.topicDataGridViewTextBoxColumn,
            this.linkDataGridViewTextBoxColumn,
            this.startDateDataGridViewTextBoxColumn,
            this.endDateDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn});
            this.dgvTrainings.DataSource = this.trainingBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTrainings.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTrainings.Location = new System.Drawing.Point(655, 116);
            this.dgvTrainings.Name = "dgvTrainings";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTrainings.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvTrainings.RowHeadersWidth = 30;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvTrainings.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvTrainings.RowTemplate.Height = 50;
            this.dgvTrainings.Size = new System.Drawing.Size(661, 364);
            this.dgvTrainings.TabIndex = 96;
            this.dgvTrainings.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTrainings_CellContentClick);
            // 
            // trainingIDDataGridViewTextBoxColumn
            // 
            this.trainingIDDataGridViewTextBoxColumn.DataPropertyName = "Training_ID";
            this.trainingIDDataGridViewTextBoxColumn.HeaderText = "Training_ID";
            this.trainingIDDataGridViewTextBoxColumn.Name = "trainingIDDataGridViewTextBoxColumn";
            this.trainingIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.trainingIDDataGridViewTextBoxColumn.Width = 93;
            // 
            // topicDataGridViewTextBoxColumn
            // 
            this.topicDataGridViewTextBoxColumn.DataPropertyName = "Topic";
            this.topicDataGridViewTextBoxColumn.HeaderText = "Topic";
            this.topicDataGridViewTextBoxColumn.Name = "topicDataGridViewTextBoxColumn";
            this.topicDataGridViewTextBoxColumn.Width = 61;
            // 
            // linkDataGridViewTextBoxColumn
            // 
            this.linkDataGridViewTextBoxColumn.DataPropertyName = "Link";
            this.linkDataGridViewTextBoxColumn.HeaderText = "Link";
            this.linkDataGridViewTextBoxColumn.Name = "linkDataGridViewTextBoxColumn";
            this.linkDataGridViewTextBoxColumn.Width = 54;
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "Start_Date";
            this.startDateDataGridViewTextBoxColumn.HeaderText = "Start_Date";
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            this.startDateDataGridViewTextBoxColumn.Width = 87;
            // 
            // endDateDataGridViewTextBoxColumn
            // 
            this.endDateDataGridViewTextBoxColumn.DataPropertyName = "End_Date";
            this.endDateDataGridViewTextBoxColumn.HeaderText = "End_Date";
            this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
            this.endDateDataGridViewTextBoxColumn.Width = 82;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.Width = 93;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(618, 58);
            this.label8.MaximumSize = new System.Drawing.Size(450, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 30);
            this.label8.TabIndex = 105;
            this.label8.Text = "2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(618, 14);
            this.label7.MaximumSize = new System.Drawing.Size(450, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 30);
            this.label7.TabIndex = 104;
            this.label7.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(649, 58);
            this.label5.MaximumSize = new System.Drawing.Size(600, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(586, 42);
            this.label5.TabIndex = 103;
            this.label5.Text = "To assign a training to a user, click the training in the grid view, type in the " +
    "Employee ID next \"assign to user ID\", then click \"assign training.\"";
            // 
            // lblPopUpTravel
            // 
            this.lblPopUpTravel.AutoSize = true;
            this.lblPopUpTravel.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopUpTravel.Location = new System.Drawing.Point(649, 10);
            this.lblPopUpTravel.MaximumSize = new System.Drawing.Size(450, 0);
            this.lblPopUpTravel.Name = "lblPopUpTravel";
            this.lblPopUpTravel.Size = new System.Drawing.Size(424, 42);
            this.lblPopUpTravel.TabIndex = 102;
            this.lblPopUpTravel.Text = "To add a new training, fill out the text boxes on the left, then click \"add train" +
    "ing.\"";
            // 
            // btnLogout
            // 
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI Semilight", 11F);
            this.btnLogout.Location = new System.Drawing.Point(1218, 575);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(87, 37);
            this.btnLogout.TabIndex = 107;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox7.Image = global::WindowsFormsApp1.Properties.Resources.logout_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox7.Location = new System.Drawing.Point(1187, 574);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(31, 38);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 106;
            this.pictureBox7.TabStop = false;
            // 
            // AddTraining
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1328, 624);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblPopUpTravel);
            this.Controls.Add(this.dgvTrainings);
            this.Controls.Add(this.lblEmployeeID);
            this.Controls.Add(this.lblVendorID);
            this.Controls.Add(this.gtpAddTraining);
            this.Controls.Add(this.lblOpenTicket);
            this.Name = "AddTraining";
            this.Text = "Add Training";
            this.Load += new System.EventHandler(this.AddTraining_Load);
            this.gtpAddTraining.ResumeLayout(false);
            this.gtpAddTraining.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iSYS4283SP22T14DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrainings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOpenTicket;
        private System.Windows.Forms.Button btnUpdateBenefits;
        private System.Windows.Forms.TextBox txtLink;
        private System.Windows.Forms.TextBox txtTopic;
        private System.Windows.Forms.Label lblVideoLink;
        private System.Windows.Forms.Label lblTopic;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.GroupBox gtpAddTraining;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Label lblStart;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.Label lblVendorID;
        private ISYS4283SP22T14DataSet1 iSYS4283SP22T14DataSet1;
        private System.Windows.Forms.BindingSource trainingBindingSource;
        private ISYS4283SP22T14DataSet1TableAdapters.TrainingTableAdapter trainingTableAdapter;
        private System.Windows.Forms.DataGridView dgvTrainings;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainingIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn topicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn linkDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtAssignedUser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAssignTraining;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblPopUpTravel;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}