﻿
namespace WindowsFormsApp1
{
    partial class Payroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSubmitBenefitsQuestion = new System.Windows.Forms.Button();
            this.txtPayrollQuestion = new System.Windows.Forms.TextBox();
            this.lblQuestionsAboutPayroll = new System.Windows.Forms.Label();
            this.lblMoreHelp = new System.Windows.Forms.Label();
            this.lblPayRate = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblPopUpTravel = new System.Windows.Forms.Label();
            this.btnUpdateBankInfo = new System.Windows.Forms.Button();
            this.btnAccessTaxLibrary = new System.Windows.Forms.Button();
            this.txtBankName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAccountNum = new System.Windows.Forms.TextBox();
            this.lblAccountNum = new System.Windows.Forms.Label();
            this.txtRoutingNum = new System.Windows.Forms.TextBox();
            this.lblRoutingNum = new System.Windows.Forms.Label();
            this.lblUserLastPaycheck = new System.Windows.Forms.Label();
            this.lblLastPaycheckAmount = new System.Windows.Forms.Label();
            this.lblPayroll = new System.Windows.Forms.Label();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.lblUsernamePassed = new System.Windows.Forms.Label();
            this.picDocument = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.picDocument)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSubmitBenefitsQuestion
            // 
            this.btnSubmitBenefitsQuestion.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSubmitBenefitsQuestion.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitBenefitsQuestion.Location = new System.Drawing.Point(781, 324);
            this.btnSubmitBenefitsQuestion.Name = "btnSubmitBenefitsQuestion";
            this.btnSubmitBenefitsQuestion.Size = new System.Drawing.Size(137, 36);
            this.btnSubmitBenefitsQuestion.TabIndex = 78;
            this.btnSubmitBenefitsQuestion.Text = "Submit Question";
            this.btnSubmitBenefitsQuestion.UseVisualStyleBackColor = false;
            this.btnSubmitBenefitsQuestion.Click += new System.EventHandler(this.btnSubmitBenefitsQuestion_Click);
            // 
            // txtPayrollQuestion
            // 
            this.txtPayrollQuestion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayrollQuestion.Location = new System.Drawing.Point(664, 181);
            this.txtPayrollQuestion.Multiline = true;
            this.txtPayrollQuestion.Name = "txtPayrollQuestion";
            this.txtPayrollQuestion.Size = new System.Drawing.Size(254, 137);
            this.txtPayrollQuestion.TabIndex = 77;
            // 
            // lblQuestionsAboutPayroll
            // 
            this.lblQuestionsAboutPayroll.AutoSize = true;
            this.lblQuestionsAboutPayroll.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestionsAboutPayroll.Location = new System.Drawing.Point(660, 137);
            this.lblQuestionsAboutPayroll.Name = "lblQuestionsAboutPayroll";
            this.lblQuestionsAboutPayroll.Size = new System.Drawing.Size(258, 21);
            this.lblQuestionsAboutPayroll.TabIndex = 76;
            this.lblQuestionsAboutPayroll.Text = "Questions about Payroll? Type away!";
            // 
            // lblMoreHelp
            // 
            this.lblMoreHelp.AutoSize = true;
            this.lblMoreHelp.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblMoreHelp.Location = new System.Drawing.Point(658, 96);
            this.lblMoreHelp.Name = "lblMoreHelp";
            this.lblMoreHelp.Size = new System.Drawing.Size(125, 32);
            this.lblMoreHelp.TabIndex = 75;
            this.lblMoreHelp.Text = "More Help";
            // 
            // lblPayRate
            // 
            this.lblPayRate.AutoSize = true;
            this.lblPayRate.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPayRate.Location = new System.Drawing.Point(273, 126);
            this.lblPayRate.Name = "lblPayRate";
            this.lblPayRate.Size = new System.Drawing.Size(85, 32);
            this.lblPayRate.TabIndex = 74;
            this.lblPayRate.Text = "XXXXX";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.label3.Location = new System.Drawing.Point(17, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 32);
            this.label3.TabIndex = 73;
            this.label3.Text = "Pay Rate:";
            // 
            // lblPopUpTravel
            // 
            this.lblPopUpTravel.AutoSize = true;
            this.lblPopUpTravel.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopUpTravel.Location = new System.Drawing.Point(21, 345);
            this.lblPopUpTravel.MaximumSize = new System.Drawing.Size(400, 0);
            this.lblPopUpTravel.Name = "lblPopUpTravel";
            this.lblPopUpTravel.Size = new System.Drawing.Size(370, 42);
            this.lblPopUpTravel.TabIndex = 72;
            this.lblPopUpTravel.Text = "To update bank information, type the new details in the above boxes and click \"up" +
    "date bank information.\"";
            // 
            // btnUpdateBankInfo
            // 
            this.btnUpdateBankInfo.Font = new System.Drawing.Font("Segoe UI Semilight", 12F);
            this.btnUpdateBankInfo.Location = new System.Drawing.Point(397, 353);
            this.btnUpdateBankInfo.Name = "btnUpdateBankInfo";
            this.btnUpdateBankInfo.Size = new System.Drawing.Size(230, 34);
            this.btnUpdateBankInfo.TabIndex = 71;
            this.btnUpdateBankInfo.Text = "Update Bank Information";
            this.btnUpdateBankInfo.UseVisualStyleBackColor = true;
            this.btnUpdateBankInfo.Click += new System.EventHandler(this.btnUpdateBankInfo_Click);
            // 
            // btnAccessTaxLibrary
            // 
            this.btnAccessTaxLibrary.Font = new System.Drawing.Font("Segoe UI Semilight", 14F);
            this.btnAccessTaxLibrary.Location = new System.Drawing.Point(100, 450);
            this.btnAccessTaxLibrary.Name = "btnAccessTaxLibrary";
            this.btnAccessTaxLibrary.Size = new System.Drawing.Size(326, 65);
            this.btnAccessTaxLibrary.TabIndex = 69;
            this.btnAccessTaxLibrary.Text = "To access tax documents, click here.";
            this.btnAccessTaxLibrary.UseVisualStyleBackColor = true;
            this.btnAccessTaxLibrary.Click += new System.EventHandler(this.btnAccessTaxLibrary_Click);
            // 
            // txtBankName
            // 
            this.txtBankName.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankName.Location = new System.Drawing.Point(177, 290);
            this.txtBankName.Multiline = true;
            this.txtBankName.Name = "txtBankName";
            this.txtBankName.Size = new System.Drawing.Size(450, 30);
            this.txtBankName.TabIndex = 68;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 14F);
            this.label1.Location = new System.Drawing.Point(20, 290);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 25);
            this.label1.TabIndex = 67;
            this.label1.Text = "Name of Bank";
            // 
            // txtAccountNum
            // 
            this.txtAccountNum.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountNum.Location = new System.Drawing.Point(177, 237);
            this.txtAccountNum.Multiline = true;
            this.txtAccountNum.Name = "txtAccountNum";
            this.txtAccountNum.Size = new System.Drawing.Size(450, 30);
            this.txtAccountNum.TabIndex = 66;
            // 
            // lblAccountNum
            // 
            this.lblAccountNum.AutoSize = true;
            this.lblAccountNum.Font = new System.Drawing.Font("Segoe UI Semilight", 14F);
            this.lblAccountNum.Location = new System.Drawing.Point(20, 237);
            this.lblAccountNum.Name = "lblAccountNum";
            this.lblAccountNum.Size = new System.Drawing.Size(151, 25);
            this.lblAccountNum.TabIndex = 65;
            this.lblAccountNum.Text = "Account Number";
            // 
            // txtRoutingNum
            // 
            this.txtRoutingNum.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoutingNum.Location = new System.Drawing.Point(177, 181);
            this.txtRoutingNum.Multiline = true;
            this.txtRoutingNum.Name = "txtRoutingNum";
            this.txtRoutingNum.Size = new System.Drawing.Size(450, 30);
            this.txtRoutingNum.TabIndex = 64;
            // 
            // lblRoutingNum
            // 
            this.lblRoutingNum.AutoSize = true;
            this.lblRoutingNum.Font = new System.Drawing.Font("Segoe UI Semilight", 14F);
            this.lblRoutingNum.Location = new System.Drawing.Point(20, 184);
            this.lblRoutingNum.Name = "lblRoutingNum";
            this.lblRoutingNum.Size = new System.Drawing.Size(146, 25);
            this.lblRoutingNum.TabIndex = 63;
            this.lblRoutingNum.Text = "Routing Number";
            // 
            // lblUserLastPaycheck
            // 
            this.lblUserLastPaycheck.AutoSize = true;
            this.lblUserLastPaycheck.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserLastPaycheck.Location = new System.Drawing.Point(273, 85);
            this.lblUserLastPaycheck.Name = "lblUserLastPaycheck";
            this.lblUserLastPaycheck.Size = new System.Drawing.Size(85, 32);
            this.lblUserLastPaycheck.TabIndex = 62;
            this.lblUserLastPaycheck.Text = "XXXXX";
            // 
            // lblLastPaycheckAmount
            // 
            this.lblLastPaycheckAmount.AutoSize = true;
            this.lblLastPaycheckAmount.Font = new System.Drawing.Font("Segoe UI Semilight", 18F);
            this.lblLastPaycheckAmount.Location = new System.Drawing.Point(17, 85);
            this.lblLastPaycheckAmount.Name = "lblLastPaycheckAmount";
            this.lblLastPaycheckAmount.Size = new System.Drawing.Size(250, 32);
            this.lblLastPaycheckAmount.TabIndex = 61;
            this.lblLastPaycheckAmount.Text = "Last paycheck amount:";
            // 
            // lblPayroll
            // 
            this.lblPayroll.AutoSize = true;
            this.lblPayroll.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPayroll.Location = new System.Drawing.Point(15, 19);
            this.lblPayroll.Name = "lblPayroll";
            this.lblPayroll.Size = new System.Drawing.Size(120, 47);
            this.lblPayroll.TabIndex = 60;
            this.lblPayroll.Text = "Payroll";
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeID.Location = new System.Drawing.Point(1001, 565);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeID.Size = new System.Drawing.Size(199, 21);
            this.lblEmployeeID.TabIndex = 95;
            this.lblEmployeeID.Text = "employee id (auto-updates)";
            this.lblEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUsernamePassed
            // 
            this.lblUsernamePassed.AutoSize = true;
            this.lblUsernamePassed.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsernamePassed.Location = new System.Drawing.Point(937, 565);
            this.lblUsernamePassed.Name = "lblUsernamePassed";
            this.lblUsernamePassed.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblUsernamePassed.Size = new System.Drawing.Size(67, 21);
            this.lblUsernamePassed.TabIndex = 94;
            this.lblUsernamePassed.Text = "User ID:";
            this.lblUsernamePassed.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // picDocument
            // 
            this.picDocument.Image = global::WindowsFormsApp1.Properties.Resources.baseline_description_black_24dp1;
            this.picDocument.Location = new System.Drawing.Point(23, 450);
            this.picDocument.Name = "picDocument";
            this.picDocument.Size = new System.Drawing.Size(61, 62);
            this.picDocument.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picDocument.TabIndex = 70;
            this.picDocument.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox6.Image = global::WindowsFormsApp1.Properties.Resources.home_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox6.Location = new System.Drawing.Point(1021, 503);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(39, 37);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 112;
            this.pictureBox6.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(952, 493);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 56);
            this.button1.TabIndex = 111;
            this.button1.Text = "Home";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(3005, 450);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 113;
            // 
            // Payroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 604);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblEmployeeID);
            this.Controls.Add(this.lblUsernamePassed);
            this.Controls.Add(this.btnSubmitBenefitsQuestion);
            this.Controls.Add(this.txtPayrollQuestion);
            this.Controls.Add(this.lblQuestionsAboutPayroll);
            this.Controls.Add(this.lblMoreHelp);
            this.Controls.Add(this.lblPayRate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblPopUpTravel);
            this.Controls.Add(this.btnUpdateBankInfo);
            this.Controls.Add(this.picDocument);
            this.Controls.Add(this.btnAccessTaxLibrary);
            this.Controls.Add(this.txtBankName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAccountNum);
            this.Controls.Add(this.lblAccountNum);
            this.Controls.Add(this.txtRoutingNum);
            this.Controls.Add(this.lblRoutingNum);
            this.Controls.Add(this.lblUserLastPaycheck);
            this.Controls.Add(this.lblLastPaycheckAmount);
            this.Controls.Add(this.lblPayroll);
            this.Name = "Payroll";
            this.Text = "Form8";
            this.Load += new System.EventHandler(this.Payroll_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picDocument)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSubmitBenefitsQuestion;
        private System.Windows.Forms.TextBox txtPayrollQuestion;
        private System.Windows.Forms.Label lblQuestionsAboutPayroll;
        private System.Windows.Forms.Label lblMoreHelp;
        private System.Windows.Forms.Label lblPayRate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblPopUpTravel;
        private System.Windows.Forms.Button btnUpdateBankInfo;
        private System.Windows.Forms.PictureBox picDocument;
        private System.Windows.Forms.Button btnAccessTaxLibrary;
        private System.Windows.Forms.TextBox txtBankName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAccountNum;
        private System.Windows.Forms.Label lblAccountNum;
        private System.Windows.Forms.TextBox txtRoutingNum;
        private System.Windows.Forms.Label lblRoutingNum;
        private System.Windows.Forms.Label lblUserLastPaycheck;
        private System.Windows.Forms.Label lblLastPaycheckAmount;
        private System.Windows.Forms.Label lblPayroll;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.Label lblUsernamePassed;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}