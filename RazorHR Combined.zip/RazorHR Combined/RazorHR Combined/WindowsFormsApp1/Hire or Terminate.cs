﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1;");
        SqlCommand cmd;
        SqlCommand cmd2;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public Form2()
        {
            InitializeComponent();
        }

        private void btnSubmitHire_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Ticketing (Employee_ID, Ticket_Submission_Date, Ticket_Classification, Ticket_Description) VALUES (@Employee_ID, @SubmitDate, 'Hire', @Description)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Employee_ID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@SubmitDate", dateTimePicker2.Value.ToString());
                cmd.Parameters.AddWithValue("@Description", "Team Needed: " + txtHireQ1.Text + " Why does this team need a new employee: " + txtHireQ2.Text + " Prospective employees: " + txtHireQ3.Text + " Estimated Salary: " + txtHireQ4.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully requested new hire!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.");
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            lblEmployeeID.Text = Form1.loggedinID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Ticketing (Employee_ID, Ticket_Submission_Date, Ticket_Classification, Ticket_Description) VALUES (@Employee_ID, @SubmitDate, 'Termination', @Description)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Employee_ID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@SubmitDate", dateTimePicker2.Value.ToString());
                cmd.Parameters.AddWithValue("@Description", "Employee Name: " + txtTerminateQ1.Text + " Reasoning: " + txtHireQ2.Text + " Meeting Date with HR: " + dateTimePicker1.Value.ToString());

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully requested termination!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please make sure all text boxes are filled in.");
            }
        }

        private void txtHireQ1_TextChanged(object sender, EventArgs e)
        {
            txtHireQ2.ReadOnly = true;
            if (txtHireQ1.Text != "")
            {
                txtHireQ2.ReadOnly = false
                    ;
            }
            else { }
           
           
               
        }

        private void txtHireQ2_TextChanged(object sender, EventArgs e)
        {
            txtHireQ3.ReadOnly = true;
            if (txtHireQ2.Text != "")
            {
                txtHireQ3.ReadOnly = false;

            }
            else { }
        }

        private void txtHireQ3_TextChanged(object sender, EventArgs e)
        {
            txtHireQ4.ReadOnly = true;
            if (txtHireQ3.Text != "")
            {
                txtHireQ4.ReadOnly = false;

            }
            else { }
        }

        private void txtTerminateQ1_TextChanged(object sender, EventArgs e)
        {
            txtTerminateQ2.ReadOnly = true;
            if (txtTerminateQ1.Text != "")
            {
                txtTerminateQ2.ReadOnly = false
                    ;
            }
            else { }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();
        }
    }
}
