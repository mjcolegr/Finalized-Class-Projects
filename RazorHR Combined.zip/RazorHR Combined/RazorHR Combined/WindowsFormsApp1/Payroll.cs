﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Payroll : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1;");
        SqlCommand cmd;
        SqlCommand cmd2;
        SqlDataAdapter adpt;
        DataTable dt;
        SqlDataReader dr;
        public Payroll()
        {
            InitializeComponent();
        }

        private void btnAccessTaxLibrary_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://cash.app/taxes");
        }

        //update bank info specific to loggedin user
        private void Payroll_Load(object sender, EventArgs e)
        {
            lblEmployeeID.Text = Form1.loggedinID;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1";
            con.Open();
            if (lblEmployeeID.Text != "")
            {
                SqlCommand cmd = new SqlCommand("SELECT Account_Number, Routing_Number, Bank_Name FROM Banking WHERE EmployeeID=@U", con);
                cmd.Parameters.AddWithValue("@U", lblEmployeeID.Text);
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    txtRoutingNum.Text = da.GetValue(0).ToString();
                    txtAccountNum.Text = da.GetValue(1).ToString();
                    txtBankName.Text = da.GetValue(2).ToString();
                }
                con.Close();
            con.Open();
            if (lblEmployeeID.Text != "")
                {
                    SqlCommand cmd2 = new SqlCommand("SELECT Biweekly_Paycheck_Amount, Salary FROM Payroll WHERE Employee_ID=@U", con);
                    cmd2.Parameters.AddWithValue("@U", lblEmployeeID.Text);
                    SqlDataReader da1 = cmd2.ExecuteReader();
                    while (da1.Read())
                    {
                        lblUserLastPaycheck.Text = "$" + da1.GetValue(0).ToString() + ".00";
                        lblPayRate.Text = "$" + da1.GetValue(1).ToString() + "/year";
                    }
                }
                con.Close();
            }
        }
            


        private void btnUpdateBankInfo_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                string sql = "UPDATE Banking SET Account_Number=@AcctNum, Routing_Number=@RoutingNum, Bank_Name=@BankName WHERE EmployeeID=@EmployeeID";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@AcctNum", txtAccountNum.Text);
                cmd.Parameters.AddWithValue("@RoutingNum", txtRoutingNum.Text);
                cmd.Parameters.AddWithValue("@BankName", txtBankName.Text);
                cmd.Parameters.AddWithValue("@EmployeeID", lblEmployeeID.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully updated bank information!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Invalid Bank Info.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();
        }

        private void btnSubmitBenefitsQuestion_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=essql1.walton.uark.edu;Initial Catalog=ISYS4283SP22T14;User ID=ISYS4283SP22T14;Password=GohogsUA1");
                con.Open();
                //create variables with the @ sign. just use whatever abbreviation makes sense
                string sql = "INSERT INTO Ticketing (Employee_ID, Ticket_Submission_Date, Ticket_Classification, Ticket_Description) VALUES (@Employee_ID, @SubmitDate, 'Payroll', @Description)";
                int answer;
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@Employee_ID", lblEmployeeID.Text);
                cmd.Parameters.AddWithValue("@SubmitDate", dateTimePicker1.Value.ToString());
                cmd.Parameters.AddWithValue("@Description", txtPayrollQuestion.Text);

                answer = cmd.ExecuteNonQuery();

                con.Close();
                cmd.Dispose();
                MessageBox.Show("Successfully submitted payroll question!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! Please fill out the text box about your question.");
            }
        }
    }
}
