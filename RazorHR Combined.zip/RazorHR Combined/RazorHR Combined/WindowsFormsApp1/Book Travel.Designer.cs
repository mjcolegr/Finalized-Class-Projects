﻿
namespace WindowsFormsApp1
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProvideReasoning = new System.Windows.Forms.Label();
            this.lblDeparting = new System.Windows.Forms.Label();
            this.lblArriving = new System.Windows.Forms.Label();
            this.lblDestination = new System.Windows.Forms.Label();
            this.lblCarDate2 = new System.Windows.Forms.Label();
            this.lblCarReturnTo = new System.Windows.Forms.Label();
            this.lblCarDate1 = new System.Windows.Forms.Label();
            this.lblCarPickupFrom = new System.Windows.Forms.Label();
            this.lblLeaving = new System.Windows.Forms.Label();
            this.lblReturning = new System.Windows.Forms.Label();
            this.lblArriveAt = new System.Windows.Forms.Label();
            this.lblDepartFrom = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDeparture = new System.Windows.Forms.TextBox();
            this.txtArrival = new System.Windows.Forms.TextBox();
            this.txtCarPickup = new System.Windows.Forms.TextBox();
            this.dtpCarPickup = new System.Windows.Forms.DateTimePicker();
            this.dtpFlightDepart = new System.Windows.Forms.DateTimePicker();
            this.dtpFlightReturn = new System.Windows.Forms.DateTimePicker();
            this.dtpCarReturn = new System.Windows.Forms.DateTimePicker();
            this.txtCarReturn = new System.Windows.Forms.TextBox();
            this.dtpHotelArrive = new System.Windows.Forms.DateTimePicker();
            this.dtpHotelDepart = new System.Windows.Forms.DateTimePicker();
            this.txtHotelDestination = new System.Windows.Forms.TextBox();
            this.txtReasoning = new System.Windows.Forms.TextBox();
            this.btnSubmitFlightRequest = new System.Windows.Forms.Button();
            this.btnFrontier = new System.Windows.Forms.Button();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.lblUsernamePassed = new System.Windows.Forms.Label();
            this.btnSubmitRentalCarlRequest = new System.Windows.Forms.Button();
            this.btnSubmitHotelRequest = new System.Windows.Forms.Button();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.lblPopUpTravel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.picHotel = new System.Windows.Forms.PictureBox();
            this.picRentalCar = new System.Windows.Forms.PictureBox();
            this.picFlight = new System.Windows.Forms.PictureBox();
            this.picFrontier = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picHotel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRentalCar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFlight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFrontier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // lblProvideReasoning
            // 
            this.lblProvideReasoning.AutoSize = true;
            this.lblProvideReasoning.Font = new System.Drawing.Font("Segoe UI Semilight", 14F);
            this.lblProvideReasoning.Location = new System.Drawing.Point(316, 431);
            this.lblProvideReasoning.Name = "lblProvideReasoning";
            this.lblProvideReasoning.Size = new System.Drawing.Size(438, 25);
            this.lblProvideReasoning.TabIndex = 67;
            this.lblProvideReasoning.Text = "Please provide reasoning for the purpose of this trip.";
            // 
            // lblDeparting
            // 
            this.lblDeparting.AutoSize = true;
            this.lblDeparting.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeparting.Location = new System.Drawing.Point(719, 380);
            this.lblDeparting.Name = "lblDeparting";
            this.lblDeparting.Size = new System.Drawing.Size(94, 25);
            this.lblDeparting.TabIndex = 63;
            this.lblDeparting.Text = "Departing";
            // 
            // lblArriving
            // 
            this.lblArriving.AutoSize = true;
            this.lblArriving.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArriving.Location = new System.Drawing.Point(719, 344);
            this.lblArriving.Name = "lblArriving";
            this.lblArriving.Size = new System.Drawing.Size(74, 25);
            this.lblArriving.TabIndex = 62;
            this.lblArriving.Text = "Arriving";
            // 
            // lblDestination
            // 
            this.lblDestination.AutoSize = true;
            this.lblDestination.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestination.Location = new System.Drawing.Point(719, 242);
            this.lblDestination.Name = "lblDestination";
            this.lblDestination.Size = new System.Drawing.Size(104, 25);
            this.lblDestination.TabIndex = 61;
            this.lblDestination.Text = "Destination";
            // 
            // lblCarDate2
            // 
            this.lblCarDate2.AutoSize = true;
            this.lblCarDate2.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarDate2.Location = new System.Drawing.Point(373, 380);
            this.lblCarDate2.Name = "lblCarDate2";
            this.lblCarDate2.Size = new System.Drawing.Size(33, 25);
            this.lblCarDate2.TabIndex = 49;
            this.lblCarDate2.Text = "on";
            // 
            // lblCarReturnTo
            // 
            this.lblCarReturnTo.AutoSize = true;
            this.lblCarReturnTo.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarReturnTo.Location = new System.Drawing.Point(372, 347);
            this.lblCarReturnTo.Name = "lblCarReturnTo";
            this.lblCarReturnTo.Size = new System.Drawing.Size(86, 25);
            this.lblCarReturnTo.TabIndex = 47;
            this.lblCarReturnTo.Text = "Return to";
            // 
            // lblCarDate1
            // 
            this.lblCarDate1.AutoSize = true;
            this.lblCarDate1.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarDate1.Location = new System.Drawing.Point(373, 281);
            this.lblCarDate1.Name = "lblCarDate1";
            this.lblCarDate1.Size = new System.Drawing.Size(33, 25);
            this.lblCarDate1.TabIndex = 46;
            this.lblCarDate1.Text = "on";
            // 
            // lblCarPickupFrom
            // 
            this.lblCarPickupFrom.AutoSize = true;
            this.lblCarPickupFrom.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarPickupFrom.Location = new System.Drawing.Point(373, 245);
            this.lblCarPickupFrom.Name = "lblCarPickupFrom";
            this.lblCarPickupFrom.Size = new System.Drawing.Size(109, 25);
            this.lblCarPickupFrom.TabIndex = 45;
            this.lblCarPickupFrom.Text = "Pickup from";
            // 
            // lblLeaving
            // 
            this.lblLeaving.AutoSize = true;
            this.lblLeaving.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLeaving.Location = new System.Drawing.Point(31, 346);
            this.lblLeaving.Name = "lblLeaving";
            this.lblLeaving.Size = new System.Drawing.Size(75, 25);
            this.lblLeaving.TabIndex = 44;
            this.lblLeaving.Text = "Leaving";
            // 
            // lblReturning
            // 
            this.lblReturning.AutoSize = true;
            this.lblReturning.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturning.Location = new System.Drawing.Point(31, 380);
            this.lblReturning.Name = "lblReturning";
            this.lblReturning.Size = new System.Drawing.Size(89, 25);
            this.lblReturning.TabIndex = 43;
            this.lblReturning.Text = "Returning";
            // 
            // lblArriveAt
            // 
            this.lblArriveAt.AutoSize = true;
            this.lblArriveAt.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArriveAt.Location = new System.Drawing.Point(31, 281);
            this.lblArriveAt.Name = "lblArriveAt";
            this.lblArriveAt.Size = new System.Drawing.Size(80, 25);
            this.lblArriveAt.TabIndex = 42;
            this.lblArriveAt.Text = "Arrive at";
            // 
            // lblDepartFrom
            // 
            this.lblDepartFrom.AutoSize = true;
            this.lblDepartFrom.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartFrom.Location = new System.Drawing.Point(31, 245);
            this.lblDepartFrom.Name = "lblDepartFrom";
            this.lblDepartFrom.Size = new System.Drawing.Size(113, 25);
            this.lblDepartFrom.TabIndex = 41;
            this.lblDepartFrom.Text = "Depart from";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semilight", 15F);
            this.label4.Location = new System.Drawing.Point(502, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 28);
            this.label4.TabIndex = 40;
            this.label4.Text = "Rental Car";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semilight", 15F);
            this.label3.Location = new System.Drawing.Point(871, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 28);
            this.label3.TabIndex = 39;
            this.label3.Text = "Hotel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semilight", 15F);
            this.label2.Location = new System.Drawing.Point(150, 191);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 28);
            this.label2.TabIndex = 38;
            this.label2.Text = "Flight";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 45);
            this.label1.TabIndex = 37;
            this.label1.Text = "Travel Request";
            // 
            // txtDeparture
            // 
            this.txtDeparture.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDeparture.Location = new System.Drawing.Point(150, 245);
            this.txtDeparture.Multiline = true;
            this.txtDeparture.Name = "txtDeparture";
            this.txtDeparture.Size = new System.Drawing.Size(133, 30);
            this.txtDeparture.TabIndex = 73;
            // 
            // txtArrival
            // 
            this.txtArrival.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArrival.Location = new System.Drawing.Point(150, 281);
            this.txtArrival.Multiline = true;
            this.txtArrival.Name = "txtArrival";
            this.txtArrival.Size = new System.Drawing.Size(133, 30);
            this.txtArrival.TabIndex = 74;
            // 
            // txtCarPickup
            // 
            this.txtCarPickup.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCarPickup.Location = new System.Drawing.Point(488, 242);
            this.txtCarPickup.Multiline = true;
            this.txtCarPickup.Name = "txtCarPickup";
            this.txtCarPickup.Size = new System.Drawing.Size(193, 30);
            this.txtCarPickup.TabIndex = 75;
            // 
            // dtpCarPickup
            // 
            this.dtpCarPickup.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtpCarPickup.Location = new System.Drawing.Point(488, 282);
            this.dtpCarPickup.Name = "dtpCarPickup";
            this.dtpCarPickup.Size = new System.Drawing.Size(193, 22);
            this.dtpCarPickup.TabIndex = 76;
            // 
            // dtpFlightDepart
            // 
            this.dtpFlightDepart.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtpFlightDepart.Location = new System.Drawing.Point(150, 349);
            this.dtpFlightDepart.Name = "dtpFlightDepart";
            this.dtpFlightDepart.Size = new System.Drawing.Size(193, 22);
            this.dtpFlightDepart.TabIndex = 77;
            // 
            // dtpFlightReturn
            // 
            this.dtpFlightReturn.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtpFlightReturn.Location = new System.Drawing.Point(150, 383);
            this.dtpFlightReturn.Name = "dtpFlightReturn";
            this.dtpFlightReturn.Size = new System.Drawing.Size(193, 22);
            this.dtpFlightReturn.TabIndex = 78;
            // 
            // dtpCarReturn
            // 
            this.dtpCarReturn.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtpCarReturn.Location = new System.Drawing.Point(488, 383);
            this.dtpCarReturn.Name = "dtpCarReturn";
            this.dtpCarReturn.Size = new System.Drawing.Size(193, 22);
            this.dtpCarReturn.TabIndex = 79;
            // 
            // txtCarReturn
            // 
            this.txtCarReturn.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCarReturn.Location = new System.Drawing.Point(488, 344);
            this.txtCarReturn.Multiline = true;
            this.txtCarReturn.Name = "txtCarReturn";
            this.txtCarReturn.Size = new System.Drawing.Size(193, 30);
            this.txtCarReturn.TabIndex = 80;
            // 
            // dtpHotelArrive
            // 
            this.dtpHotelArrive.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtpHotelArrive.Location = new System.Drawing.Point(826, 346);
            this.dtpHotelArrive.Name = "dtpHotelArrive";
            this.dtpHotelArrive.Size = new System.Drawing.Size(193, 22);
            this.dtpHotelArrive.TabIndex = 81;
            // 
            // dtpHotelDepart
            // 
            this.dtpHotelDepart.Font = new System.Drawing.Font("Segoe UI Semilight", 8F);
            this.dtpHotelDepart.Location = new System.Drawing.Point(826, 383);
            this.dtpHotelDepart.Name = "dtpHotelDepart";
            this.dtpHotelDepart.Size = new System.Drawing.Size(193, 22);
            this.dtpHotelDepart.TabIndex = 82;
            // 
            // txtHotelDestination
            // 
            this.txtHotelDestination.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHotelDestination.Location = new System.Drawing.Point(826, 240);
            this.txtHotelDestination.Multiline = true;
            this.txtHotelDestination.Name = "txtHotelDestination";
            this.txtHotelDestination.Size = new System.Drawing.Size(193, 30);
            this.txtHotelDestination.TabIndex = 83;
            // 
            // txtReasoning
            // 
            this.txtReasoning.Font = new System.Drawing.Font("Segoe UI Semilight", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReasoning.Location = new System.Drawing.Point(321, 469);
            this.txtReasoning.Multiline = true;
            this.txtReasoning.Name = "txtReasoning";
            this.txtReasoning.Size = new System.Drawing.Size(433, 77);
            this.txtReasoning.TabIndex = 84;
            // 
            // btnSubmitFlightRequest
            // 
            this.btnSubmitFlightRequest.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSubmitFlightRequest.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitFlightRequest.Location = new System.Drawing.Point(105, 564);
            this.btnSubmitFlightRequest.Name = "btnSubmitFlightRequest";
            this.btnSubmitFlightRequest.Size = new System.Drawing.Size(201, 38);
            this.btnSubmitFlightRequest.TabIndex = 85;
            this.btnSubmitFlightRequest.Text = "Submit Flight Request";
            this.btnSubmitFlightRequest.UseVisualStyleBackColor = false;
            this.btnSubmitFlightRequest.Click += new System.EventHandler(this.btnSubmitFlightRequest_Click_1);
            // 
            // btnFrontier
            // 
            this.btnFrontier.Font = new System.Drawing.Font("Segoe UI Semilight", 14F);
            this.btnFrontier.Location = new System.Drawing.Point(546, 638);
            this.btnFrontier.Name = "btnFrontier";
            this.btnFrontier.Size = new System.Drawing.Size(246, 74);
            this.btnFrontier.TabIndex = 87;
            this.btnFrontier.Text = "To view more details about Frontier Airlines, click here.";
            this.btnFrontier.UseVisualStyleBackColor = true;
            this.btnFrontier.Click += new System.EventHandler(this.btnFrontier_Click);
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeID.Location = new System.Drawing.Point(979, 705);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeID.Size = new System.Drawing.Size(199, 21);
            this.lblEmployeeID.TabIndex = 93;
            this.lblEmployeeID.Text = "employee id (auto-updates)";
            this.lblEmployeeID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUsernamePassed
            // 
            this.lblUsernamePassed.AutoSize = true;
            this.lblUsernamePassed.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsernamePassed.Location = new System.Drawing.Point(915, 705);
            this.lblUsernamePassed.Name = "lblUsernamePassed";
            this.lblUsernamePassed.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblUsernamePassed.Size = new System.Drawing.Size(67, 21);
            this.lblUsernamePassed.TabIndex = 92;
            this.lblUsernamePassed.Text = "User ID:";
            this.lblUsernamePassed.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btnSubmitRentalCarlRequest
            // 
            this.btnSubmitRentalCarlRequest.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSubmitRentalCarlRequest.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitRentalCarlRequest.Location = new System.Drawing.Point(457, 564);
            this.btnSubmitRentalCarlRequest.Name = "btnSubmitRentalCarlRequest";
            this.btnSubmitRentalCarlRequest.Size = new System.Drawing.Size(201, 38);
            this.btnSubmitRentalCarlRequest.TabIndex = 94;
            this.btnSubmitRentalCarlRequest.Text = "Submit Rental Car Request";
            this.btnSubmitRentalCarlRequest.UseVisualStyleBackColor = false;
            this.btnSubmitRentalCarlRequest.Click += new System.EventHandler(this.btnSubmitRentalCarlRequest_Click);
            // 
            // btnSubmitHotelRequest
            // 
            this.btnSubmitHotelRequest.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSubmitHotelRequest.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitHotelRequest.Location = new System.Drawing.Point(804, 564);
            this.btnSubmitHotelRequest.Name = "btnSubmitHotelRequest";
            this.btnSubmitHotelRequest.Size = new System.Drawing.Size(201, 38);
            this.btnSubmitHotelRequest.TabIndex = 95;
            this.btnSubmitHotelRequest.Text = "Submit Hotel Request";
            this.btnSubmitHotelRequest.UseVisualStyleBackColor = false;
            this.btnSubmitHotelRequest.Click += new System.EventHandler(this.btnSubmitHotelRequest_Click);
            // 
            // lblInstructions
            // 
            this.lblInstructions.AutoSize = true;
            this.lblInstructions.Font = new System.Drawing.Font("Segoe UI Semilight", 15F);
            this.lblInstructions.Location = new System.Drawing.Point(526, 26);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(0, 28);
            this.lblInstructions.TabIndex = 96;
            // 
            // lblPopUpTravel
            // 
            this.lblPopUpTravel.AutoSize = true;
            this.lblPopUpTravel.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopUpTravel.Location = new System.Drawing.Point(590, 23);
            this.lblPopUpTravel.MaximumSize = new System.Drawing.Size(450, 0);
            this.lblPopUpTravel.Name = "lblPopUpTravel";
            this.lblPopUpTravel.Size = new System.Drawing.Size(438, 42);
            this.lblPopUpTravel.TabIndex = 97;
            this.lblPopUpTravel.Text = "To request travel, fill out each section to request a flight, hotel, and rental c" +
    "ar. Leave any unneeded sections blank.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(590, 78);
            this.label5.MaximumSize = new System.Drawing.Size(400, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(273, 21);
            this.label5.TabIndex = 98;
            this.label5.Text = "Provide reasoning for the trip purpose.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(590, 118);
            this.label6.MaximumSize = new System.Drawing.Size(450, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(445, 21);
            this.label6.TabIndex = 99;
            this.label6.Text = "Click each button separately to request each travel item needed.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(559, 27);
            this.label7.MaximumSize = new System.Drawing.Size(450, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 30);
            this.label7.TabIndex = 100;
            this.label7.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(559, 71);
            this.label8.MaximumSize = new System.Drawing.Size(450, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 30);
            this.label8.TabIndex = 101;
            this.label8.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(559, 113);
            this.label9.MaximumSize = new System.Drawing.Size(450, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 30);
            this.label9.TabIndex = 102;
            this.label9.Text = "3";
            // 
            // picHotel
            // 
            this.picHotel.Image = global::WindowsFormsApp1.Properties.Resources.outline_hotel_black_48dp;
            this.picHotel.Location = new System.Drawing.Point(826, 187);
            this.picHotel.Name = "picHotel";
            this.picHotel.Size = new System.Drawing.Size(39, 41);
            this.picHotel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picHotel.TabIndex = 90;
            this.picHotel.TabStop = false;
            // 
            // picRentalCar
            // 
            this.picRentalCar.Image = global::WindowsFormsApp1.Properties.Resources.outline_time_to_leave_black_48dp;
            this.picRentalCar.Location = new System.Drawing.Point(457, 187);
            this.picRentalCar.Name = "picRentalCar";
            this.picRentalCar.Size = new System.Drawing.Size(39, 41);
            this.picRentalCar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picRentalCar.TabIndex = 89;
            this.picRentalCar.TabStop = false;
            // 
            // picFlight
            // 
            this.picFlight.Image = global::WindowsFormsApp1.Properties.Resources.outline_flight_takeoff_black_48dp;
            this.picFlight.Location = new System.Drawing.Point(105, 187);
            this.picFlight.Name = "picFlight";
            this.picFlight.Size = new System.Drawing.Size(39, 41);
            this.picFlight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFlight.TabIndex = 88;
            this.picFlight.TabStop = false;
            // 
            // picFrontier
            // 
            this.picFrontier.Image = global::WindowsFormsApp1.Properties.Resources.frontier;
            this.picFrontier.Location = new System.Drawing.Point(293, 638);
            this.picFrontier.Name = "picFrontier";
            this.picFrontier.Size = new System.Drawing.Size(237, 74);
            this.picFrontier.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFrontier.TabIndex = 86;
            this.picFrontier.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox6.Image = global::WindowsFormsApp1.Properties.Resources.home_FILL0_wght400_GRAD0_opsz48;
            this.pictureBox6.Location = new System.Drawing.Point(1000, 648);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(39, 37);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 112;
            this.pictureBox6.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(931, 638);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 56);
            this.button1.TabIndex = 111;
            this.button1.Text = "Home";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1057, 741);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblPopUpTravel);
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.btnSubmitHotelRequest);
            this.Controls.Add(this.btnSubmitRentalCarlRequest);
            this.Controls.Add(this.lblEmployeeID);
            this.Controls.Add(this.lblUsernamePassed);
            this.Controls.Add(this.picHotel);
            this.Controls.Add(this.picRentalCar);
            this.Controls.Add(this.picFlight);
            this.Controls.Add(this.btnFrontier);
            this.Controls.Add(this.picFrontier);
            this.Controls.Add(this.btnSubmitFlightRequest);
            this.Controls.Add(this.txtReasoning);
            this.Controls.Add(this.txtHotelDestination);
            this.Controls.Add(this.dtpHotelDepart);
            this.Controls.Add(this.dtpHotelArrive);
            this.Controls.Add(this.txtCarReturn);
            this.Controls.Add(this.dtpCarReturn);
            this.Controls.Add(this.dtpFlightReturn);
            this.Controls.Add(this.dtpFlightDepart);
            this.Controls.Add(this.dtpCarPickup);
            this.Controls.Add(this.txtCarPickup);
            this.Controls.Add(this.txtArrival);
            this.Controls.Add(this.txtDeparture);
            this.Controls.Add(this.lblProvideReasoning);
            this.Controls.Add(this.lblDeparting);
            this.Controls.Add(this.lblArriving);
            this.Controls.Add(this.lblDestination);
            this.Controls.Add(this.lblCarDate2);
            this.Controls.Add(this.lblCarReturnTo);
            this.Controls.Add(this.lblCarDate1);
            this.Controls.Add(this.lblCarPickupFrom);
            this.Controls.Add(this.lblLeaving);
            this.Controls.Add(this.lblReturning);
            this.Controls.Add(this.lblArriveAt);
            this.Controls.Add(this.lblDepartFrom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form9";
            this.Text = "Form9";
            this.Load += new System.EventHandler(this.Form9_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picHotel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRentalCar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFlight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFrontier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblProvideReasoning;
        private System.Windows.Forms.Label lblDeparting;
        private System.Windows.Forms.Label lblArriving;
        private System.Windows.Forms.Label lblDestination;
        private System.Windows.Forms.Label lblCarDate2;
        private System.Windows.Forms.Label lblCarReturnTo;
        private System.Windows.Forms.Label lblCarDate1;
        private System.Windows.Forms.Label lblCarPickupFrom;
        private System.Windows.Forms.Label lblLeaving;
        private System.Windows.Forms.Label lblReturning;
        private System.Windows.Forms.Label lblArriveAt;
        private System.Windows.Forms.Label lblDepartFrom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDeparture;
        private System.Windows.Forms.TextBox txtArrival;
        private System.Windows.Forms.TextBox txtCarPickup;
        private System.Windows.Forms.DateTimePicker dtpCarPickup;
        private System.Windows.Forms.DateTimePicker dtpFlightDepart;
        private System.Windows.Forms.DateTimePicker dtpFlightReturn;
        private System.Windows.Forms.DateTimePicker dtpCarReturn;
        private System.Windows.Forms.TextBox txtCarReturn;
        private System.Windows.Forms.DateTimePicker dtpHotelArrive;
        private System.Windows.Forms.DateTimePicker dtpHotelDepart;
        private System.Windows.Forms.TextBox txtHotelDestination;
        private System.Windows.Forms.TextBox txtReasoning;
        private System.Windows.Forms.Button btnSubmitFlightRequest;
        private System.Windows.Forms.PictureBox picFrontier;
        private System.Windows.Forms.Button btnFrontier;
        private System.Windows.Forms.PictureBox picFlight;
        private System.Windows.Forms.PictureBox picRentalCar;
        private System.Windows.Forms.PictureBox picHotel;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.Label lblUsernamePassed;
        private System.Windows.Forms.Button btnSubmitRentalCarlRequest;
        private System.Windows.Forms.Button btnSubmitHotelRequest;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.Label lblPopUpTravel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button button1;
    }
}